# supplier

A new Flutter project.

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://flutter.dev/docs/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://flutter.dev/docs/cookbook)

For help getting started with Flutter, view our
[online documentation](https://flutter.dev/docs), which offers tutorials,
samples, guidance on mobile development, and a full API reference.

## Steps to Release the app on ios store

1. open the folder in xcode by running `open ios/Runner.xcworkspace`
2. after checking the proper version and build number in the pubspec.yaml run `flutter build ios`
3. Set up proper signing credentials in the xcode (set to auto signing)
4. In xcode go to product and make sure product>scheme>runner is selected and then in product>destination make sure "any ios device" is selected
   4.5.then in xcode click on product>Archieve
5. once the build is complete it will show in the window>organiser in the xcode then click distribute app with the default options selected

## Steps to Release the app on android store

1. make sure you have the "key.properties" file in the android folder as it is necessary for the signing of the app bundle
2. make sure the path to key.jks file has the correct path to your folder in the 'key.properties' file on your system
3. in the android/app/build.gradle file inside the buildTypes make sure that signingConfig is `signingConfigs.release`

```
    buildTypes {
    release {
       signingConfig signingConfigs.release
   }
}
```

4. update the version in pubspec.yaml

5. perform these commands to get the app bundle
   `flutter clean`
   `flutter build appbundle --release`

6. upload the app bundle to the play store

import 'package:decimal/decimal.dart';
import 'package:flutter/material.dart';
import 'package:supplier/core/constants/constants.dart';
import 'package:supplier/data/models/analytics.dart';
import 'package:supplier/data/models/grade.dart';
import 'package:supplier/data/models/grade_group.dart';

String? getErrorTextForGradePrice(
  String gradePrice,
  String lowerPriceBand,
  String upperPriceBand,
) {
  final Decimal lpowerPriceBand = Decimal.parse(lowerPriceBand);
  final Decimal rpowerPriceBand = Decimal.parse(upperPriceBand);
  try {
    if (gradePrice.isEmpty) {
      return "";
    }
    final Decimal val = Decimal.parse(gradePrice);

    if (val < lpowerPriceBand || val > rpowerPriceBand) {
      return "Please enter a price within the valid range $lpowerPriceBand to $rpowerPriceBand Rs";
    }
    return null;
  } catch (e) {
    return "Please enter a price within the valid range $lpowerPriceBand to $rpowerPriceBand Rs";
  }
}

String? getErrorTextForQuantity(
  String? val, {
  bool isBulk = false,
  String? bulkMinQuantity,
}) {
  if (val == null) return null;
  if (val.isEmpty) return '';

  try {
    final Decimal bulkVal = Decimal.parse(val);
    if (isBulk) {
      final Decimal minQuantity = Decimal.parse(bulkMinQuantity!);
      if (bulkVal < minQuantity) {
        return 'Bulk Quantity should be more than or equal to $minQuantity';
      }
    }

    return null;
  } catch (e) {
    return 'Please Enter a valid quantity';
  }
}

String? getErrorTextForBulk(
  String gradePrice,
  String? bulkPrice,
  String lowerPriceBand,
  String upperPriceBand,
) {
  if (bulkPrice == null) return null;
  final Decimal lpowerPriceBand = Decimal.parse(lowerPriceBand);
  final Decimal rpowerPriceBand = Decimal.parse(upperPriceBand);
  if (bulkPrice.isEmpty) return "";
  try {
    final Decimal bp = Decimal.parse(bulkPrice);
    final Decimal gp = Decimal.parse(gradePrice);

    if (bp < lpowerPriceBand || bp > rpowerPriceBand) {
      return "Please enter a price within the valid range $lpowerPriceBand to $rpowerPriceBand Rs";
    }
    if (bp >= gp) return "Please enter a price lower than regular offers";
    return null;
  } catch (e) {
    return "";
  }
}

List<Grade> getAllGrades(Map<String, Gradegroup> gradeGroupMap) {
  return gradeGroupMap.values.expand((group) => group.grades).toList();
}

int checkIfGradeIsPresent(List<Grade> grades, String gradeId) {
  return grades.indexWhere((g) => g.gradeId == gradeId);
}

bool checkValidityOfOffers(
    Map<String, Gradegroup> offersMap, String minimumBulkQuantity,) {
  for (final entry in offersMap.entries) {
    final Gradegroup gradeGroup = entry.value;
    for (final grade in gradeGroup.grades) {
      if (!checkValidOffer(
        grade,
        gradeGroup.lowerPriceBand,
        gradeGroup.upperPriceBand,
        minimumBulkQuantity,
      )) {
        return false;
      }
    }
  }
  return true;
}

bool checkValidOffer(
  Grade grade,
  String lowerP,
  String upperP,
  String minimumBulkQuantity,
) {
  try {
    final Decimal gradePrice = Decimal.parse(grade.price);
    final Decimal lowerPriceBand = Decimal.parse(lowerP);
    final Decimal upperPriceBand = Decimal.parse(upperP);
    if (gradePrice < lowerPriceBand || gradePrice > upperPriceBand) {
      return false;
    }
    if (!((grade.bulkPrice != null && grade.bulkQuantity != null) ||
        (grade.bulkPrice == null && grade.bulkQuantity == null))) return false;
    if (grade.bulkQuantity != null && grade.bulkPrice != null) {
      final Decimal bulkPrice = Decimal.parse(grade.bulkPrice!);
      if (Decimal.parse(grade.bulkQuantity!) <
          Decimal.parse(minimumBulkQuantity)) {
        return false;
      }
      if (bulkPrice >= gradePrice ||
          (bulkPrice < lowerPriceBand || bulkPrice > upperPriceBand)) {
        return false;
      }
    }
  } catch (e) {
    return false;
  }
  return true;
}

String formatDate(String date) {
  final List<String> dateParts = date.split('-');
  final int day = int.parse(dateParts[0]);
  final int month = int.parse(dateParts[1]);
  final int year = int.parse(dateParts[2]);

  final String formattedDate = '$day ${monthNames[month - 1]} $year';
  return formattedDate;
}

void notifySupplierAppEvent(Map data, EventType eventType) {
  try {
    SupplierAppAnalytics.instance.push(
      data,
      eventType,
    );
  } catch (e) {
    print(e);
  }
}

void onTabChangeAppEvent(int index) {
  try {
    if (index == 0) {
      SupplierAppAnalytics.instance.push({}, EventType.USER_TAPPED_MY_OFFERS);
    } else if (index == 1) {
      SupplierAppAnalytics.instance.push({}, EventType.USER_TAPPED_MY_ORDERS);
    } else if (index == 2) {
      SupplierAppAnalytics.instance.push({}, EventType.USER_TAPPED_PROFILE);
    }
  } catch (e) {
    print(e);
  }
}

String selectMessageForErrorDislay(
  String priceErrorMessage,
  String bulkPriceErrorMessage,
  String bulkQuantityMessage,
) {
  if (priceErrorMessage.isNotEmpty) {
    return priceErrorMessage;
  } else if (bulkPriceErrorMessage.isNotEmpty) {
    return bulkPriceErrorMessage;
  }
  return bulkQuantityMessage;
}

List<TextSpan> parseText(String text) {
  final List<TextSpan> spans = [];
  final pattern = RegExp(r'(\*.*?\*|_.*?_|\~.*?\~|`.*?`)');
  final matches = pattern.allMatches(text);

  int lastMatchEnd = 0;
  for (final match in matches) {
    if (match.start > lastMatchEnd) {
      spans.add(
        TextSpan(
          text: text.substring(lastMatchEnd, match.start),
        ),
      );
    }
    final matchedText = match.group(0)!;
    if (matchedText.startsWith('*') && matchedText.endsWith('*')) {
      spans.add(
        TextSpan(
          text: matchedText.replaceAll('*', ''),
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
        ),
      );
    }
    lastMatchEnd = match.end;
  }
  if (lastMatchEnd < text.length) {
    spans.add(
      TextSpan(
        text: text.substring(lastMatchEnd),
      ),
    );
  }
  return spans;
}

abstract class RouteConstants {
  static const String login = "login";
  static const String authenticateOTP = "authenticateOTP";
  static const String gradesForApp = 'gradesForApp';
  static const String locationWiseListings = "locationWiseListingsV2";
  static const String priceUpdates = "priceUpdates";
  static const String deactivateOffers = "deactivateOffers";
  static const String supplierAppLocations = "supplierAppLocations";
  static const String userProfileInfo = "userProfileInfo";
  static const String confirmedOrders = "confirmedOrders";
  static const String completedOrders = "completedOrders";
  static const String userSupplierAppInfo = "userSupplierAppInfo";
  static const String checkUserLogoutStatus = "checkUserLogoutStatus";
  static const String supplierAppEvent = 'supplierAppEvent';
  static const String supplierAppVersionCheck = "supplierAppVersionCheck";
  static const String logout = "logout";
  static const String validatePriceUpdate = 'validatePriceUpdate';
}

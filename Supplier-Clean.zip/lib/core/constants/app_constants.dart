const String uatUrl = "https://spcxuat.source.one";
const String localUrl = 'https://172.16.12.11:5001';
const String iPhoneLocalUrl = 'https://supplier.localhost:5001';
const String iUrl = 'https://localhost:5001';
const String prodUrl = "https://supplier.source.one"; //TBA

const endPoint = "/api/supplierApp/v2/";

const String apiBaseUrl = "$uatUrl$endPoint";

const double maxPhoneWidth = 600.0;
const String inActiveStatus = "INACTIVE";
const String activeStatus = "ACTIVE";

const List<String> monthNames = [
  'January',
  'February',
  'March',
  'April',
  'May',
  'June',
  'July',
  'August',
  'September',
  'October',
  'November',
  'December',
];

enum TabItem { offers, orders, profile }

enum GradeField { price, remarks, bulkQuantity, bulkPrice }

enum Status { confirmed, completed }

const String loadingAddressPending = 'Loading\nAddress\nPending';
const String loadingAddressUpdated = 'Loading\nAddress\nUpdated';
const String vehicleNotConfirmed = 'Vehicle\nnot\nconfirmed';
const String confirmingVehicle = 'Confirming\nvehicle';
const String vehicleConfirmed = 'Vehicle\nConfirmed';
const String vehicleNotReached = 'Vehicle\nNot\nreached';
const String vehicleReaching = 'Vehicle\nReaching';
const String vehicleReached = 'Vehicle\nReached';
const String vehicleNotLoaded = 'Vehicle\nnot\nLoaded';
const String loadingVehicle = 'Vehicle\nLoading';
const String vehicleLoaded = 'Vehicle\nLoaded';
const String invoiceNotRecieved = 'Invoice\nnot\nrecieved';
const String invoicePending = 'Invoice\npending';
const String invoiceReceived = 'Invoice\nreceived';

const String whatsappNumber = 'whatsappNumber';
const String sessionId = 'sessionId';
const String referenceToken = 'referenceToken';
const int resendOtpCountdownDuration = 30;
const String authFailedMessage = 'OTP AUTHENTICATION FAILED';
const String accountManager = 'accountManager';

const String loginIssuePhoneNumber = '9614063333';

import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;
import 'package:supplier/core/constants/constants.dart';
import 'package:supplier/core/service/log_service.dart';

class APIException implements http.ClientException {
  final int statusCode;
  @override
  final String message;

  APIException(this.statusCode, this.message);

  @override
  String toString() => 'ApiException: $message (Status code: $statusCode)';

  @override
  Uri? get uri => throw UnimplementedError();
}

class APIService {
  APIService(this._client);
  final http.Client _client;

  Future<http.Response> sendRequest(
    String requestURL,
    Map<String, dynamic> body,
  ) async {
    final String apiRequestURL = apiBaseUrl + requestURL;
    try {
      LogService.logDebug('Sending request with body: $body');
      return await _client.post(
        Uri.parse(apiRequestURL),
        headers: <String, String>{
          HttpHeaders.contentTypeHeader: 'application/json',
        },
        body: json.encode(body),
      );
    } catch (e, st) {
      LogService.logError('Error in sendRequest', error: e, stackTrace: st);
      rethrow;
    }
  }
}

// ignore_for_file: avoid_classes_with_only_static_members

import 'package:logger/logger.dart';

abstract class LogService {
  static final Logger _prettyLogger = Logger(
    printer: PrettyPrinter(
      errorMethodCount: 5,
      dateTimeFormat: DateTimeFormat.dateAndTime,
    ),
  );
  static final Logger _simpleLogger = Logger(printer: SimplePrinter());

  // include stackTrace to show the exact line of error
  static void logError(
    dynamic message, {
    Object? error,
    StackTrace? stackTrace,
  }) {
    _prettyLogger.e(
      message,
      error: error,
      stackTrace: stackTrace ?? StackTrace.current,
    );
  }

  static void logDebug(dynamic message) {
    _simpleLogger.log(Level.debug, message);
  }

  static void logInfo(dynamic message) {
    _simpleLogger.log(Level.info, message);
  }

  static void logWarning(dynamic message) {
    _simpleLogger.log(Level.warning, message);
  }
}

import 'package:flutter/material.dart';

ThemeData appTheme() {
  return ThemeData(
    fontFamily: 'NunitoSans',
    textTheme: appTextTheme,
    useMaterial3: true,
  );
}

const TextTheme appTextTheme = TextTheme(
  headlineLarge: TextStyle(
    letterSpacing: 0.1,
  ),
  headlineMedium: TextStyle(
    fontSize: 18,
    letterSpacing: 0.1,
    fontWeight: FontWeight.w600,
  ),
  headlineSmall: TextStyle(
    letterSpacing: 0.1,
  ),
  bodyLarge: TextStyle(
    letterSpacing: 0.1,
  ),
  bodyMedium: TextStyle(
    letterSpacing: 0.1,
  ),
  bodySmall: TextStyle(
    letterSpacing: 0.1,
  ),
  displayLarge: TextStyle(
    letterSpacing: 0.1,
  ),
  displayMedium: TextStyle(
    letterSpacing: 0.1,
    fontSize: 14,
  ),
  displaySmall: TextStyle(
    letterSpacing: 0.1,
  ),
  labelLarge: TextStyle(
    letterSpacing: 0.1,
  ),
  labelMedium: TextStyle(
    letterSpacing: 0.1,
    fontSize: 12,
  ),
  labelSmall: TextStyle(
    letterSpacing: 0.1,
  ),
);

import 'package:flutter/material.dart';

abstract class AppColors {
  // UI Colors
  static const Color uiWhite100 = Color(0xFFFFFFFF); // White $100
  static const Color uiBlack100 = Color(0xFF000000); // Black $100
  static const Color uiBlack80 = Color(0xFF333333); // Black $80
  static const Color uiBlack50 = Color(0xFF808080); // Black $50
  static const Color uiBlack25 = Color(0xFFB0B0B0); // Black $25
  static const Color uiStroke10 = Color(0xFFD9D9D9); // Stroke $10
  static const Color uiBlack3 = Color(0xFFF6F6F6); // Black $3
  static const Color uiBackground = Color(0xFFF8F8F8); // Background

  // Primary Colors
  static const Color primary100 = Color(0xFF4171DC); // Primary $100
  static const Color primary15 = Color(0xFFE3EAFA); // Primary $15

  // Secondary Colors
  static const Color secondary100 = Color(0xFFFF662E); // Secondary $100
  static const Color secondary20 = Color(0xFFF9E0D0); // Secondary $20

  // UI Green
  static const Color uiGreen100 = Color(0xFF2AA14C); // Green $100
  static const Color uiGreen10 = Color(0xFFEAF6ED); // Green $10

  // UI Red
  static const Color uiRed100 = Color(0xFFC54326); // Red $100
  static const Color uiRed10 = Color(0xFFF9ECE9); // Red $10

  // UI Moderate
  static const Color uiModerate100 = Color(0xFFE49F00); // Moderate $100
  static const Color uiModerate10 = Color(0xFFFFF7E5); // Moderate $10

  // UI Orange
  static const Color uiOrange100 = Color(0xFFF28B0C); // Orange $100
  static const Color uiOrange20 = Color(0xffFFEDD7); // Orange $20
}

import 'package:get_it/get_it.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supplier/core/service/api_service.dart';
import 'package:supplier/data/models/analytics.dart';
import 'package:supplier/data/models/ticker.dart';
import 'package:supplier/data/repositories/app_version_repository.dart';
import 'package:supplier/data/repositories/auth_repository.dart';
import 'package:supplier/data/repositories/new_offer_repository.dart';
import 'package:supplier/data/repositories/order_repository.dart';
import 'package:supplier/data/repositories/profile_repository.dart';
import 'package:supplier/data/repositories/supplier_app_event_repository.dart';
import 'package:supplier/data/repositories/supplier_screen_repository.dart';
import 'package:supplier/presentation/bloc/auth/auth_bloc.dart';
import 'package:supplier/presentation/bloc/bottom_navigation_bar/bottom_navigation_bar_bloc.dart';
import 'package:supplier/presentation/bloc/login/login_bloc.dart';
import 'package:supplier/presentation/bloc/new_offer/new_offer_bloc.dart';
import 'package:supplier/presentation/bloc/pop_up/pop_up_bloc.dart';
import 'package:supplier/presentation/bloc/profile_bloc/profile_bloc_bloc.dart';
import 'package:supplier/presentation/bloc/snack_bar/snack_bar_bloc.dart';
import 'package:supplier/presentation/bloc/supplier_order/supplier_order_bloc.dart';
import 'package:supplier/presentation/bloc/supplier_page_bloc/supplier_page_bloc_bloc.dart';

final GetIt locator = GetIt.instance;

Future<void> initialiseDependencies() async {
  final http.Client client = http.Client();
  final SharedPreferencesAsync localStorage = SharedPreferencesAsync();
  locator
    ..registerSingleton<http.Client>(client)
    ..registerSingleton<APIService>(APIService(locator()))
    ..registerSingleton<SharedPreferencesAsync>(localStorage)
    ..registerSingleton<Ticker>(const Ticker())
    ..registerSingleton<SupplierAppEventRepository>(
      SupplierAppEventRepository(locator(), locator()),
    )
    ..registerLazySingleton<SupplierAppAnalytics>(
      () => SupplierAppAnalytics.instance,
    )
    ..registerSingleton<AuthRepository>(AuthRepository(locator()))
    ..registerSingleton<NewOfferRepository>(
        NewOfferRepository(locator(), locator()),)
    ..registerSingleton<SupplierScreenRepository>(
      SupplierScreenRepository(locator(), locator()),
    )
    ..registerSingleton<ProfileRepository>(
      ProfileRepository(locator(), locator()),
    )
    ..registerSingleton<OrderRepository>(
      OrderRepository(locator(), locator()),
    )
    ..registerSingleton<AppVersionRepository>(
      AppVersionRepository(locator(), locator()),
    )
    ..registerFactory<AuthBloc>(() => AuthBloc(locator(), locator(), locator()))
    ..registerFactory<LoginBloc>(
      () => LoginBloc(
        locator(),
        locator(),
        locator(),
      ),
    )
    ..registerFactory<BottomNavigationBarBloc>(
      () => BottomNavigationBarBloc(),
    )
    ..registerFactory<PopUpBloc>(() => PopUpBloc())
    ..registerFactory<SnackBarBloc>(() => SnackBarBloc())
    ..registerFactory<NewOfferBloc>(() => NewOfferBloc(locator()))
    ..registerFactory<ProfileBloc>(() => ProfileBloc(locator()))
    ..registerFactory<SupplierOrderBloc>(
      () => SupplierOrderBloc(locator()),
    )
    ..registerFactory<SupplierPageBlocBloc>(
      () => SupplierPageBlocBloc(locator()),
    );
}

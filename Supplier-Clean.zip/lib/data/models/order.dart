import 'package:equatable/equatable.dart';
import 'package:supplier/core/constants/app_constants.dart';
import 'package:supplier/data/models/ordered_grade.dart';

class Order extends Equatable {
  final String orderNo;
  final String dispatchDate;
  final String billTo;
  final List<OrderedGrade> grades;
  final Status status;

  // Fields for completed orders
  final String? amount;
  final String? utrNo;
  final String? paymentDate;

  // Fields for confirmed orders
  final String? vehicleNumber;
  final String? driverContact;
  final String? loadingAddress;
  final String? loadingAddressUpdates;
  final String? vehicleConfirmed;
  final String? vehicleReached;
  final String? vehicleLoaded;
  final String? invoiceReceived;

  const Order({
    required this.orderNo,
    required this.dispatchDate,
    required this.billTo,
    required this.grades,
    required this.status,
    this.amount,
    this.utrNo,
    this.paymentDate,
    this.vehicleNumber,
    this.driverContact,
    this.loadingAddress,
    this.loadingAddressUpdates,
    this.vehicleConfirmed,
    this.vehicleReached,
    this.vehicleLoaded,
    this.invoiceReceived,
  });

  factory Order.fromCompletedOrderJson(Map<String, dynamic> json) {
    return Order(
      status: Status.completed,
      orderNo: json['orderNo'] as String,
      dispatchDate: json['dispatchDate'] as String,
      billTo: json['billTo'] as String,
      amount: json['payment']['amount'] as String,
      utrNo: json['utrNo'] as String,
      paymentDate: json['payment']['date'] as String,
      grades: (json['grades'] as List<dynamic>)
          .map(
            (grade) => OrderedGrade(
              product: grade['gradeName'] as String,
              quantity: grade['quantity'] as String,
              sellingPrice: grade['sellingPrice'] as String,
              billingPrice: grade['billingPrice'] as String,
            ),
          )
          .toList(),
    );
  }

  factory Order.fromConfirmedOrderJson(Map<String, dynamic> json) {
    return Order(
      status: Status.confirmed,
      orderNo: json['orderNo'] as String,
      dispatchDate: json['dispatchDate'] as String,
      billTo: json['billTo'] as String,
      vehicleNumber: json['vehicleNumber'] as String,
      driverContact: json['driverContact'] as String,
      loadingAddress: json['loadingAddress'] as String,
      loadingAddressUpdates: json['progress'][0]['date'] as String,
      vehicleConfirmed: json['progress'][1]['date'] as String,
      vehicleReached: json['progress'][2]['date'] as String,
      vehicleLoaded: json['progress'][3]['date'] as String,
      invoiceReceived: json['progress'][4]['date'] as String,
      grades: (json['grades'] as List<dynamic>)
          .map(
            (grade) => OrderedGrade(
              product: grade['gradeName'] as String,
              quantity: grade['quantity'] as String,
              sellingPrice: grade['sellingPrice'] as String,
              billingPrice: grade['billingPrice'] as String,
            ),
          )
          .toList(),
    );
  }

  @override
  List<Object?> get props => [
        orderNo,
        dispatchDate,
        billTo,
        grades,
        status,
        amount,
        utrNo,
        paymentDate,
        vehicleNumber,
        driverContact,
        loadingAddress,
        loadingAddressUpdates,
        vehicleConfirmed,
        vehicleReached,
        vehicleLoaded,
        invoiceReceived,
      ];
}

import 'package:equatable/equatable.dart';

class OrderedGrade extends Equatable {
  final String product;
  final String quantity;
  final String sellingPrice;
  final String billingPrice;

  const OrderedGrade({
    required this.product,
    required this.quantity,
    required this.sellingPrice,
    required this.billingPrice,
  });

  @override
  // TODO: implement props
  List<Object?> get props => [product, quantity, sellingPrice, billingPrice];
}

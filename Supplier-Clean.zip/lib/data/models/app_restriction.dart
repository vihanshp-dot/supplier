import 'package:equatable/equatable.dart';

class AppRestriction extends Equatable {
  const AppRestriction({
    required this.isAppAccessRestricted,
    required this.remarks,
  });

  final bool isAppAccessRestricted;
  final String remarks;

  @override
  List<Object?> get props => <Object?>[isAppAccessRestricted, remarks];

  factory AppRestriction.fromJson(Map<String, dynamic> json) {
    return AppRestriction(
      isAppAccessRestricted: json['isAppAccessRestricted'] as bool,
      remarks: json["remarks"] as String,
    );
  }
}

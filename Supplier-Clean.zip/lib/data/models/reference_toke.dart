import 'package:equatable/equatable.dart';

class ReferenceToken extends Equatable {
  final String referenceToken;
  final String message;

  const ReferenceToken({
    required this.referenceToken,
    required this.message,
  });

  factory ReferenceToken.fromJson(Map<String, dynamic> json) {
    return ReferenceToken(
      referenceToken: _convertToString(json['referenceToken']),
      message: _convertToString(json['message']),
    );
  }

  Map<String, dynamic> toJson() {
    return <String, dynamic>{
      referenceToken: '',
    };
  }

  static String _convertToString(dynamic value) {
    if (value == null) {
      return '';
    } else if (value is String) {
      return value;
    } else if (value is num) {
      return value.toString();
    } else {
      throw ArgumentError('Unsupported type');
    }
  }

  @override
  String toString() {
    return 'ReferenceToken($referenceToken, $message)';
  }

  @override
  List<Object?> get props => <Object?>[referenceToken];

  static const ReferenceToken empty = ReferenceToken(
    referenceToken: '',
    message: '',
  );

  bool get isEmpty => this == ReferenceToken.empty;
}

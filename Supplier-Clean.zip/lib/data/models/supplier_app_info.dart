import 'package:equatable/equatable.dart';

class SupplierAppInfo extends Equatable {
  final String accountManager;
  final bool isBulkOfferAllowed;
  final String defaultQuantity;
  final String minimumBulkQuantity;
  const SupplierAppInfo(
      {required this.accountManager,
      required this.isBulkOfferAllowed,
      required this.defaultQuantity,
      required this.minimumBulkQuantity,});

  @override
  List<Object?> get props =>
      [accountManager, isBulkOfferAllowed, defaultQuantity];
  factory SupplierAppInfo.fromJson(Map<String, dynamic> json) {
    return SupplierAppInfo(
      accountManager: json['accountManager'] as String,
      isBulkOfferAllowed: json['bulkOffersInfo']['isAllowed'] as bool,
      defaultQuantity: json['bulkOffersInfo']['defaultQuantity'].toString(),
      minimumBulkQuantity:
          json['bulkOffersInfo']['minimumBulkQuantityAllowed'].toString(),
    );
  }
}

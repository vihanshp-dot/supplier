import 'package:equatable/equatable.dart';

class GradeDropDownOption extends Equatable {
  const GradeDropDownOption({
    required this.gradeGroupId,
    required this.gradeGroupName,
    required this.displayName,
    required this.dropdownDisplayName,
    required this.gradeId,
    required this.lowerPriceBand,
    required this.upperPriceBand,
    required this.gradeRemarks,
  });

  final String gradeGroupId;
  final String gradeGroupName;
  final String displayName;
  final String gradeId;
  final String dropdownDisplayName;
  final String lowerPriceBand;
  final String upperPriceBand;
  final String? gradeRemarks;

  factory GradeDropDownOption.fromJson(Map<String, dynamic> json) {
    return GradeDropDownOption(
      gradeGroupId: json['gradeGroupId'] as String,
      gradeGroupName: json['gradeGroupName'] as String,
      displayName: json['displayName'] as String,
      dropdownDisplayName: json['dropdownDisplayName'] as String,
      lowerPriceBand: ((json['lowerPriceBand'] as num) / 100).toString(),
      upperPriceBand: ((json['upperPriceBand'] as num) / 100).toString(),
      gradeId: json['gradeId'] as String,
      gradeRemarks: json['gradeRemarks'] as String?,
    );
  }

  @override
  List<Object?> get props => <Object?>[
        gradeGroupId,
        gradeGroupName,
        lowerPriceBand,
        upperPriceBand,
        displayName,
        dropdownDisplayName,
        lowerPriceBand,
        upperPriceBand,
        gradeRemarks,
      ];
}

// ignore_for_file: constant_identifier_names

import 'dart:io';

import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:get_it/get_it.dart';
import 'package:supplier/data/repositories/supplier_app_event_repository.dart';

enum EventType {
  ACCESSED_HOMESCREEN,
  SUBMITTED_OFFERS,
  USER_TAPPED_MY_OFFERS,
  USER_TAPPED_MY_ORDERS,
  USER_TAPPED_PROFILE,
  USER_CHANGED_LOCATION,
  USER_TAPPED_CALL_BUTTON,
  USER_CHOSE_GRADE,
  USER_TAPPED_DEACTIVATE_OFFERS,
  PRICE_UPDATED_POPUP_ALERT
}

class SupplierAppAnalytics {
  SupplierAppAnalytics._privateConstructor(this._supplierAppEventRepository);

  final SupplierAppEventRepository _supplierAppEventRepository;

  static final SupplierAppAnalytics _instance =
      SupplierAppAnalytics._privateConstructor(
    GetIt.instance<SupplierAppEventRepository>(),
  );

  static SupplierAppAnalytics get instance => _instance;

  Future<String> getDeviceId() async {
    String deviceId = '';
    try {
      final DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
      if (Platform.isAndroid) {
        const channel = MethodChannel('com.analytics.getID');
        final String? androidId = await channel.invokeMethod('getDeviceId');
        deviceId = androidId ?? "";
      } else if (Platform.isIOS) {
        final IosDeviceInfo iosInfo = await deviceInfo.iosInfo;

        deviceId = iosInfo.identifierForVendor ?? "";
      } else {
        final WebBrowserInfo webBrowserInfo = await deviceInfo.webBrowserInfo;
        deviceId = webBrowserInfo.userAgent ?? '';
      }
    } catch (e) {
      if (kDebugMode) {
        print(e);
        print("Error in getting device id");
      }
    }
    return deviceId;
  }

  Future<void> push(Map data, EventType eventType) async {
    final int timestamp = DateTime.now().millisecondsSinceEpoch;
    data['deviceId'] = await getDeviceId();
    await _supplierAppEventRepository.sendSupplierAppEvent(
      data,
      eventType,
      timestamp,
    );
  }
}

class AnalyticsEvent {
  final String eventType;
  final Map data;
  final int timestamp;

  AnalyticsEvent(this.eventType, this.data, this.timestamp);
}

import 'package:equatable/equatable.dart';
import 'package:supplier/data/models/grade.dart';

class Gradegroup extends Equatable {
  const Gradegroup({
    required this.gradeGroupId,
    required this.gradeGroupName,
    required this.lowerPriceBand,
    required this.upperPriceBand,
    required this.grades,
  });

  final String gradeGroupId;
  final String gradeGroupName;

  final String lowerPriceBand;
  final String upperPriceBand;
  final List<Grade> grades;

  @override
  List<Object?> get props => <Object?>[
        gradeGroupId,
        gradeGroupName,
        lowerPriceBand,
        upperPriceBand,
        grades,
      ];

  factory Gradegroup.fromJson(Map<String, dynamic> json) {
    return Gradegroup(
      gradeGroupId: json['gradeGroupId'] as String,
      gradeGroupName: json['gradeGroupName'] as String,
      lowerPriceBand: ((json['lowerPriceBand'] as num) / 100).toString(),
      upperPriceBand: ((json['upperPriceBand'] as num) / 100).toString(),
      grades: (json['gradeGroupListings'] as List<dynamic>?)
              ?.map((dynamic e) => Grade.fromJson(e as Map<String, dynamic>))
              .toList() ??
          <Grade>[],
    );
  }
}

import 'package:equatable/equatable.dart';
import 'package:supplier/data/models/field.dart';

class Profile extends Equatable {
  final String sectionName;
  final String icon;
  final List<Field> fields;

  const Profile({
    required this.sectionName,
    required this.icon,
    required this.fields,
  });
  @override
  List<Object?> get props => <Object?>[sectionName, icon, fields];

  factory Profile.fromJson(Map<String, dynamic> json) {
    return Profile(
      sectionName: json['sectionName'] as String,
      icon: json["icon"] as String,
      fields: (json['fields'] as List<dynamic>)
          .map(
            (field) => Field(
              label: field['label'].toString(),
              labelTextColor: field['labelTextColor'] as String,
              value: field['value'] as String,
              valueTextColor: field['valueTextColor'] as String,
            ),
          )
          .toList(),
    );
  }
}

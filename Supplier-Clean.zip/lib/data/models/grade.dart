import 'package:decimal/decimal.dart';
import 'package:equatable/equatable.dart';

class Grade extends Equatable {
  const Grade({
    required this.gradeId,
    required this.price,
    required this.displayName,
    this.qtyRemarks,
    this.bulkPrice,
    this.bulkQuantity,
    this.gradeRemarks,
  });

  final String gradeId;
  final String price;
  final String displayName;
  final String? qtyRemarks;
  final String? bulkQuantity;
  final String? bulkPrice;
  final String? gradeRemarks;

  @override
  List<Object?> get props => <Object?>[
        gradeId,
        price,
        displayName,
        qtyRemarks,
        bulkPrice,
        bulkQuantity,
        gradeRemarks,
      ];

  factory Grade.fromJson(Map<String, dynamic> json) {
    return Grade(
      gradeId: json['gradeId'] as String,
      displayName: json["displayName"] as String,
      price: ((json["price"] as num) / 100).toString(),
      qtyRemarks: json["qtyRemarks"]?.toString(),
      bulkPrice: json['bulkOffer']?["price"] != null
          ? ((json['bulkOffer']["price"] as num) / 100).toString()
          : null,
      bulkQuantity: json['bulkOffer']?["quantity"]?.toString(),
      gradeRemarks: json['gradeRemarks']?.toString(),
    );
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = {
      "gradeId": gradeId,
      "price": (Decimal.parse(price) * Decimal.parse('100')).toBigInt().toInt(),
      "remarks": qtyRemarks ?? '',
    };

    if (bulkPrice != null && bulkQuantity != null) {
      data["bulkOffer"] = {
        "price": (Decimal.parse(bulkPrice!) * Decimal.parse('100')).toBigInt().toInt(),
        "quantity": bulkQuantity,
      };
    }

    return data;
  }
}

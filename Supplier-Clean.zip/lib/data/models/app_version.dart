import 'package:equatable/equatable.dart';

class AppVersion extends Equatable {
  final bool isUpdateRequired;
  final String messageForUser;
  final String supplierAppLink;

  const AppVersion({
    required this.isUpdateRequired,
    required this.messageForUser,
    required this.supplierAppLink,
  });
  @override
  List<Object?> get props =>
      <Object?>[isUpdateRequired, messageForUser, supplierAppLink];

  factory AppVersion.fromJson(Map<String, dynamic> json) {
    return AppVersion(
      isUpdateRequired: json['isUpdateRequired'] as bool,
      messageForUser: json['messageForUser']?.toString() ?? "",
      supplierAppLink: json['supplierAppLink']?.toString() ?? "",
    );
  }
}

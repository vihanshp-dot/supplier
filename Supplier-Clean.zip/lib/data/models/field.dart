import 'package:equatable/equatable.dart';

class Field extends Equatable {
  final String label;
  final String labelTextColor;
  final String value;
  final String valueTextColor;

  const Field({
    required this.label,
    required this.labelTextColor,
    required this.value,
    required this.valueTextColor,
  });

  @override
  List<Object?> get props =>
      <Object?>[label, value, valueTextColor, labelTextColor];
}

import 'package:equatable/equatable.dart';
import 'package:supplier/data/models/grade_group.dart';

class LocationWiseGGInfo extends Equatable {
  const LocationWiseGGInfo({
    required this.gradeGroups,
    required this.lastUpdatedAt,
    required this.message,
  });

  final List<Gradegroup> gradeGroups;
  final int lastUpdatedAt;
  final String message;

  @override
  List<Object?> get props => <Object?>[gradeGroups, lastUpdatedAt, message];
}

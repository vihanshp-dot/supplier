import 'package:equatable/equatable.dart';

class Location extends Equatable {
  const Location({
    required this.name,
    required this.state,
    required this.locationId,
    required this.deactivated,
    required this.lastUpdated,
    required this.lastUpdatedTimestamp,
    required this.status,
  });

  final String name;
  final String state;
  final String locationId;
  final bool deactivated;
  final String lastUpdated;
  final String lastUpdatedTimestamp;
  final String status;

  @override
  List<Object?> get props => <Object?>[
        name,
        state,
        locationId,
        deactivated,
        lastUpdated,
        lastUpdatedTimestamp,
        status,
      ];

  factory Location.fromJson(Map<String, dynamic> json) {
    return Location(
        name: json['name'].toString(),
        state: json['state'].toString(),
        locationId: json['locationId'].toString(),
        deactivated: json['deactivated'] as bool,
        lastUpdated: json['lastUpdated'].toString(),
        lastUpdatedTimestamp: json['lastUpdatedTimestamp'].toString(),
        status: json['status'].toString(),);
  }
}

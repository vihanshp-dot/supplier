import 'package:equatable/equatable.dart';

class User extends Equatable {
  final String sessionId;
  final String name;
  final String whatsappNumber;
  final bool isPersonAppAllowed;
  final String message;
  final String buttonCTA;
  final String buttonText;
  final String accountManager;

  const User({
    required this.sessionId,
    required this.name,
    required this.whatsappNumber,
    required this.isPersonAppAllowed,
    required this.message,
    required this.buttonCTA,
    required this.buttonText,
    required this.accountManager,
  });

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      sessionId: _convertToString(json['sessionId']),
      name: _convertToString(json['name']),
      whatsappNumber: _convertToString(json['whatsappNumber']),
      isPersonAppAllowed: _convertToBool(json['isPersonAppAllowed']),
      message: _convertToString(json['message']),
      buttonCTA: _convertToString(json['buttonCTA']),
      buttonText: _convertToString(json['buttonText']),
      accountManager: _convertToString(json['accountManager']),
    );
  }

  Map<String, dynamic> toJson() {
    return <String, dynamic>{
      'sessionId': sessionId,
      'name': name,
      'whatsappNumber': whatsappNumber,
      'isPersonAppAllowed': isPersonAppAllowed,
      'message': message,
      'buttonCTA': buttonCTA,
      'buttonText': buttonText,
    };
  }

  static String _convertToString(dynamic value) {
    if (value == null) {
      return '';
    } else if (value is String) {
      return value;
    } else if (value is num) {
      return value.toString();
    } else {
      throw ArgumentError('Unsupported type');
    }
  }

  static bool _convertToBool(dynamic value) {
    if (value == null) return false;
    if (value is bool) return value;
    if (value is int) return value == 1;
    if (value is String) return value.toLowerCase() == 'true';
    throw Exception('Invalid boolean value');
  }

  @override
  String toString() {
    return 'User($sessionId, $name, $whatsappNumber, $isPersonAppAllowed, $message, $buttonCTA, $buttonText)';
  }

  @override
  List<Object?> get props => <Object?>[
        sessionId,
        name,
        whatsappNumber,
        isPersonAppAllowed,
        message,
        buttonCTA,
        buttonText,
      ];

  static const User empty = User(
      sessionId: '',
      name: '',
      whatsappNumber: '',
      isPersonAppAllowed: false,
      message: '',
      buttonCTA: '',
      buttonText: '',
      accountManager: '',);

  bool get isEmpty => this == User.empty;
}

import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';
import 'package:supplier/core/constants/constants.dart';
import 'package:supplier/core/service/api_service.dart';
import 'package:supplier/data/models/profile.dart';

class ProfileRepository {
  ProfileRepository(this._apiService, this._localStorage);

  final APIService _apiService;
  final SharedPreferencesAsync _localStorage;

  Future<List<Profile>> fetchUserData() async {
    try {
      final String? number = await _localStorage.getString(whatsappNumber);
      final String? session = await _localStorage.getString(sessionId);
      final response = await _apiService.sendRequest(
        RouteConstants.userProfileInfo,
        {
          "whatsappNumber": number,
          "sessionId": session,
        },
      );
      final List<dynamic> decodedResponse =
          json.decode(response.body) as List<dynamic>;
      final List<Profile> gradeOptions = decodedResponse
          .map(
            (item) => Profile.fromJson(
              Map<String, dynamic>.from(item as Map<dynamic, dynamic>),
            ),
          )
          .toList();

      return gradeOptions;
    } catch (e) {
      rethrow;
    }
  }
}

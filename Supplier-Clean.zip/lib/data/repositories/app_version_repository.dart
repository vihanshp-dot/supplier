import 'dart:convert';
import 'dart:io';

import 'package:package_info_plus/package_info_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supplier/core/constants/constants.dart';
import 'package:supplier/core/service/api_service.dart';
import 'package:supplier/data/models/app_version.dart';

class AppVersionRepository {
  AppVersionRepository(this._apiService, this._localStorage);
  final APIService _apiService;
  final SharedPreferencesAsync _localStorage;

  Future<AppVersion> checkAppVersion() async {
    try {
      final PackageInfo packageInfo = await PackageInfo.fromPlatform();
      final String version = packageInfo.version;
      final String device = Platform.isAndroid ? "android" : "ios";
      final String? session = await _localStorage.getString(sessionId);
      final String? number = await _localStorage.getString(whatsappNumber);
      final response = await _apiService.sendRequest(
        RouteConstants.supplierAppVersionCheck,
        {
          "appVersion": version,
          "device": device,
          "sessionId": session,
          "whatsappNumber": number,
        },
      );
      final Map<String, dynamic> decodedResponse =
          json.decode(response.body) as Map<String, dynamic>;
      final AppVersion appVersion = AppVersion.fromJson(decodedResponse);
      return appVersion;
    } catch (e) {
      rethrow;
    }
  }
}

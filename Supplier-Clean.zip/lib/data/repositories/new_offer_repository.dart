import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supplier/core/constants/app_constants.dart';
import 'package:supplier/core/constants/route_constants.dart';
import 'package:supplier/core/service/api_service.dart';
import 'package:supplier/data/models/grade_drop_down_options.dart';

class NewOfferRepository {
  NewOfferRepository(this._apiService, this._localStorage);

  final APIService _apiService;
  final SharedPreferencesAsync _localStorage;

  Future<List<GradeDropDownOption>> getGradeOptions(String params) async {
    try {
      final String? number = await _localStorage.getString(whatsappNumber);
      final String? session = await _localStorage.getString(sessionId);
      final http.Response response = await _apiService.sendRequest(
        RouteConstants.gradesForApp,
        {
          "query": params,
          "sessionId": session,
          "whatsappNumber": number,
        },
      );
      final List<dynamic> decodedResponse =
          json.decode(response.body) as List<dynamic>;
      final List<GradeDropDownOption> gradeOptions = decodedResponse
          .map(
            (item) => GradeDropDownOption.fromJson(
              Map<String, dynamic>.from(item as Map<dynamic, dynamic>),
            ),
          )
          .toList();

      return gradeOptions;
    } catch (e) {
      rethrow;
    }
  }
}

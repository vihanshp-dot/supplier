import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supplier/core/constants/app_constants.dart';
import 'package:supplier/core/constants/route_constants.dart';
import 'package:supplier/core/service/api_service.dart';
import 'package:supplier/data/models/app_restriction.dart';
import 'package:supplier/data/models/grade.dart';
import 'package:supplier/data/models/grade_group.dart';
import 'package:supplier/data/models/location.dart';
import 'package:supplier/data/models/location_wise_gg_info.dart';
import 'package:supplier/data/models/supplier_app_info.dart';

class SupplierScreenRepository {
  SupplierScreenRepository(this._apiService, this._localStorage);

  final APIService _apiService;
  final SharedPreferencesAsync _localStorage;

  Future<LocationWiseGGInfo> getLocationWiseListings(String locationId) async {
    try {
      final String? number = await _localStorage.getString(whatsappNumber);
      final String? session = await _localStorage.getString(sessionId);
      final http.Response response = await _apiService.sendRequest(
        RouteConstants.locationWiseListings,
        {
          "locationId": locationId,
          "sessionId": session,
          "whatsappNumber": number,
        },
      );
      final dynamic decodedResponse = json.decode(response.body);

      final int lastUpdatedAt = decodedResponse['lastUpdatedAt'] as int;
      final String message = decodedResponse['message'] as String;

      final List<Gradegroup> gradeOptions =
          (decodedResponse['listings'] as List<dynamic>)
              .map(
                (item) => Gradegroup.fromJson(
                  Map<String, dynamic>.from(item as Map<dynamic, dynamic>),
                ),
              )
              .toList();

      return LocationWiseGGInfo(
        gradeGroups: gradeOptions,
        lastUpdatedAt: lastUpdatedAt,
        message: message,
      );
    } catch (e) {
      rethrow;
    }
  }

  Future<String> activateOffers(
    String locationId,
    List<Grade> gradePrices,
  ) async {
    try {
      final String? number = await _localStorage.getString(whatsappNumber);
      final String? session = await _localStorage.getString(sessionId);
      final http.Response response = await _apiService.sendRequest(
        RouteConstants.priceUpdates,
        {
          "locationId": locationId,
          "sessionId": session,
          "whatsappNumber": number,
          "gradePrices": gradePrices
              .map(
                (g) => g.toJson(),
              )
              .toList(),
        },
      );
      final Map<String, dynamic> decodedResponse =
          json.decode(response.body) as Map<String, dynamic>;
      if (decodedResponse.containsKey("message")) {
        final String response = decodedResponse["message"] as String;
        if (response.contains("Updated and activated all grade offers")) {
          return response;
        }
      }
      throw response.toString();
    } catch (e) {
      rethrow;
    }
  }

  Future<String> deActivateOffers(
    String locationId,
  ) async {
    try {
      final String? number = await _localStorage.getString(whatsappNumber);
      final String? session = await _localStorage.getString(sessionId);
      final http.Response response = await _apiService.sendRequest(
        RouteConstants.deactivateOffers,
        {
          "locationId": locationId,
          "sessionId": session,
          "whatsappNumber": number,
        },
      );
      final Map<String, dynamic> decodedResponse =
          json.decode(response.body) as Map<String, dynamic>;
      if (decodedResponse.containsKey("message")) {
        final String message = decodedResponse["message"] as String;
        if (message.contains("Deactivated all grade offers for location")) {
          return message;
        }
      }
      throw response.toString();
    } catch (e) {
      rethrow;
    }
  }

  Future<List<Location>> getSupplierLocations() async {
    try {
      final String? number = await _localStorage.getString(whatsappNumber);
      final String? session = await _localStorage.getString(sessionId);
      final http.Response response = await _apiService.sendRequest(
        RouteConstants.supplierAppLocations,
        {
          "sessionId": session,
          "whatsappNumber": number,
        },
      );
      final List<dynamic> decodedResponse =
          json.decode(response.body) as List<dynamic>;

      final List<Location> supplierLocations = decodedResponse
          .map(
            (item) => Location.fromJson(item as Map<String, dynamic>),
          )
          .toList();

      return supplierLocations;
    } catch (e) {
      rethrow;
    }
  }

  Future<SupplierAppInfo> getSupplierAppInfo() async {
    final String? number = await _localStorage.getString(whatsappNumber);
    final String? session = await _localStorage.getString(sessionId);
    final http.Response response = await _apiService.sendRequest(
      RouteConstants.userSupplierAppInfo,
      {
        "sessionId": session,
        "whatsappNumber": number,
      },
    );
    final dynamic decodedResponse = json.decode(response.body);
    final SupplierAppInfo supplierAppInfo =
        SupplierAppInfo.fromJson(decodedResponse as Map<String, dynamic>);
    return supplierAppInfo;
  }

  Future<AppRestriction> getSupplierLogStatus() async {
    final String? number = await _localStorage.getString(whatsappNumber);
    final String? session = await _localStorage.getString(sessionId);
    final http.Response response = await _apiService.sendRequest(
      RouteConstants.checkUserLogoutStatus,
      {
        "sessionId": session,
        "whatsappNumber": number,
      },
    );
    final dynamic decodedResponse = json.decode(response.body);
    final AppRestriction appRestriction =
        AppRestriction.fromJson(decodedResponse as Map<String, dynamic>);

    return appRestriction;
  }

  Future<String?> checkRecentUpdate(
    String locationId,
    int lastUpdatedAt,
  ) async {
    final String? number = await _localStorage.getString(whatsappNumber);
    final String? session = await _localStorage.getString(sessionId);
    final http.Response response = await _apiService.sendRequest(
      RouteConstants.validatePriceUpdate,
      {
        'locationId': locationId,
        "lastUpdatedAt": lastUpdatedAt,
        "whatsappNumber": number,
        "sessionId": session,
      },
    );

    final dynamic decodedResponse = json.decode(response.body);

    if (decodedResponse['isValid'] as bool) {
      return null;
    }
    return decodedResponse['message'] as String;
  }
}

import 'package:shared_preferences/shared_preferences.dart';
import 'package:supplier/core/constants/constants.dart';
import 'package:supplier/core/service/api_service.dart';
import 'package:supplier/data/models/analytics.dart';

class SupplierAppEventRepository {
  SupplierAppEventRepository(this._apiService, this._localStorage);

  final APIService _apiService;
  final SharedPreferencesAsync _localStorage;

  Future<void> sendSupplierAppEvent(
    Map meta,
    EventType eventType,
    int timestamp,
  ) async {
    try {
      final String? number = await _localStorage.getString(whatsappNumber);
      final String? session = await _localStorage.getString(sessionId);
      await _apiService.sendRequest(
        RouteConstants.supplierAppEvent,
        {
          "meta": meta,
          "sessionId": session,
          "whatsappNumber": number,
          "eventType": eventType.name,
          "timestamp": timestamp,
        },
      );
    } catch (e) {
      rethrow;
    }
  }
}

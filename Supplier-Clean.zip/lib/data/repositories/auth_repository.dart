import 'dart:convert';

import 'package:supplier/core/constants/constants.dart';
import 'package:supplier/core/service/api_service.dart';
import 'package:supplier/data/models/reference_toke.dart';
import 'package:supplier/data/models/user.dart';

class AuthRepository {
  AuthRepository(this._apiService);
  final APIService _apiService;

  Future<ReferenceToken> login(String whatsappNumber) async {
    try {
      final requestBody = {'whatsappNumber': whatsappNumber};
      final response = await _apiService.sendRequest(
        RouteConstants.login,
        requestBody,
      );

      final Map<String, dynamic> decodedResponse =
          json.decode(response.body) as Map<String, dynamic>;
      final ReferenceToken referenceToken =
          ReferenceToken.fromJson(decodedResponse);
      return referenceToken;
    } catch (e) {
      rethrow;
    }
  }

  Future<User> authOtp(
    String whatsappNumber,
    String referenceToken,
    String otp,
  ) async {
    try {
      final requestBody = {
        'whatsappNumber': whatsappNumber,
        'referenceToken': referenceToken,
        'otp': otp,
      };
      final response = await _apiService.sendRequest(
        RouteConstants.authenticateOTP,
        requestBody,
      );
      final Map<String, dynamic> decodedResponse =
          json.decode(response.body) as Map<String, dynamic>;
      final User user = User.fromJson(decodedResponse);

      return user;
    } catch (e) {
      rethrow;
    }
  }

  Future<void> logOut(
    String whatsappNumber,
    String sessionId,
  ) async {
    try {
      final requestBody = {
        'whatsappNumber': whatsappNumber,
        'sessionId': sessionId,
      };
      await _apiService.sendRequest(
        RouteConstants.logout,
        requestBody,
      );
    } catch (e) {}
  }
}

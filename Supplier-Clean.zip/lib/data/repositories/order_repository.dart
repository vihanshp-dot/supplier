import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';
import 'package:supplier/core/constants/constants.dart';
import 'package:supplier/core/service/api_service.dart';
import 'package:supplier/data/models/order.dart';

class OrderRepository {
  OrderRepository(this._apiService, this._localStorage);

  final APIService _apiService;
  final SharedPreferencesAsync _localStorage;

  Future<List<Order>> fetchConfirmedOrders() async {
    try {
      final String? number = await _localStorage.getString(whatsappNumber);
      final String? session = await _localStorage.getString(sessionId);
      final response = await _apiService.sendRequest(
        RouteConstants.confirmedOrders,
        {
          "whatsappNumber": number,
          "sessionId": session,
        },
      );
      final List<dynamic> decodedResponse =
          json.decode(response.body) as List<dynamic>;
      final List<Order> orders = decodedResponse
          .map(
            (item) => Order.fromConfirmedOrderJson(
              Map<String, dynamic>.from(item as Map<dynamic, dynamic>),
            ),
          )
          .toList();
      return orders;
    } catch (e) {
      rethrow;
    }
  }

  Future<List<Order>> fetchCompletedOrders(String filterVal) async {
    try {
      final String? number = await _localStorage.getString(whatsappNumber);
      final String? session = await _localStorage.getString(sessionId);
      final response = await _apiService.sendRequest(
        RouteConstants.completedOrders,
        {
          "whatsappNumber": number,
          "sessionId": session,
          "selectedFilter": filterVal,
        },
      );
      final List<dynamic> decodedResponse =
          json.decode(response.body) as List<dynamic>;
      final List<Order> orders = decodedResponse
          .map(
            (item) => Order.fromCompletedOrderJson(
              Map<String, dynamic>.from(item as Map<dynamic, dynamic>),
            ),
          )
          .toList();
      return orders;
    } catch (e) {
      rethrow;
    }
  }
}

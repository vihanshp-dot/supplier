import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:supplier/config/theme/app_colors.dart';
import 'package:supplier/core/constants/app_constants.dart';
import 'package:supplier/presentation/bloc/login/login_bloc.dart';

class ResendOtpButton extends StatelessWidget {
  final String whatsappNumber;

  const ResendOtpButton({required this.whatsappNumber});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<LoginBloc, LoginState>(
      buildWhen: (previous, current) =>
          current is TimerInitial ||
          current is TimerRunComplete ||
          current is TimerRunInProgress,
      builder: (context, state) {
        if (state is PhoneNumberInitial) {
          context.read<LoginBloc>().add(TimerStarted(state.duration));
        }
        if (state is ReceivedReferenceToken) {
          context
              .read<LoginBloc>()
              .add(const TimerStarted(resendOtpCountdownDuration));
        }
        return Align(
          alignment: Alignment.centerLeft,
          child: RichText(
            text: TextSpan(
              children: [
                const TextSpan(
                  text: "Didn't receive OTP? ",
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 15,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                WidgetSpan(
                  alignment: PlaceholderAlignment.baseline,
                  baseline: TextBaseline.alphabetic,
                  child: GestureDetector(
                    key: const Key('ResendOtpButton'),
                    child: Text(
                      'Resend OTP',
                      style: TextStyle(
                        color: state is TimerRunInProgress
                            ? AppColors.uiBlack50
                            : AppColors.primary100,
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                      ),
                    ),
                    onTap: () {
                      if (state is PhoneNumberInitial) {
                        context
                            .read<LoginBloc>()
                            .add(TimerStarted(state.duration));

                        context.read<LoginBloc>().add(
                              PhoneNumberSubmitted(
                                phoneNumber: whatsappNumber,
                              ),
                            );
                      }
                      if (state is TimerRunComplete) {
                        context
                            .read<LoginBloc>()
                            .add(TimerStarted(state.duration));
                        context.read<LoginBloc>().add(
                              PhoneNumberSubmitted(
                                phoneNumber: whatsappNumber,
                              ),
                            );
                      }
                      if (state is ReceivedReferenceToken) {
                        context.read<LoginBloc>().add(
                              const TimerStarted(
                                resendOtpCountdownDuration,
                              ),
                            );
                        context.read<LoginBloc>().add(
                              PhoneNumberSubmitted(
                                phoneNumber: whatsappNumber,
                              ),
                            );
                      }
                    },
                  ),
                ),
                TextSpan(
                  text: state is TimerRunInProgress
                      ? ' in ${_getTimerDuration(state, context)} seconds'
                      : '',
                  style: const TextStyle(
                    color: Colors.black,
                    fontSize: 15,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  String _getTimerDuration(LoginState state, BuildContext context) {
    if (state is TimerRunInProgress) {
      return '${state.duration}';
    }
    return '';
  }
}

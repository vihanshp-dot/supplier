import 'package:flutter/material.dart';

import 'package:supplier/config/theme/app_colors.dart';
import 'package:supplier/core/constants/app_constants.dart';

import 'package:url_launcher/url_launcher.dart';

class BottomText extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Align(
        alignment: Alignment.bottomCenter,
        child: Container(
          key: const Key('BottomText'),
          constraints: const BoxConstraints(maxWidth: 500),
          decoration: BoxDecoration(
            color: const Color.fromARGB(125, 235, 235, 235),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: AppColors.uiStroke10),
            boxShadow: const [
              BoxShadow(
                color: Color.fromARGB(255, 233, 230, 230),
                blurRadius: 5,
                offset: Offset(5, 5),
              ),
            ],
          ),
          child: Padding(
            padding: const EdgeInsets.all(10.0),
            child: RichText(
              text: TextSpan(
                children: [
                  const TextSpan(
                    text:
                        'If you are unable to login, call your Account Manager or Call on ',
                    style: TextStyle(color: Colors.black, fontSize: 17),
                  ),
                  WidgetSpan(
                    alignment: PlaceholderAlignment.baseline,
                    baseline: TextBaseline.alphabetic,
                    child: GestureDetector(
                      key: const Key('AccountManagerNumberButton'),
                      child: const Text(
                        loginIssuePhoneNumber,
                        style: TextStyle(
                          color: Color.fromARGB(255, 65, 113, 220),
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                      onTap: () async {
                        final url = Uri.parse('tel:$loginIssuePhoneNumber');
                        if (await canLaunchUrl(url)) {
                          await launchUrl(url);
                        } else {
                          throw 'Could not launch $url';
                        }
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:pinput/pinput.dart';
import 'package:smart_auth/smart_auth.dart';
import 'package:supplier/config/theme/app_colors.dart';
import 'package:supplier/injection_container.dart';
import 'package:supplier/presentation/bloc/auth/auth_bloc.dart';
import 'package:supplier/presentation/bloc/bottom_navigation_bar/bottom_navigation_bar_bloc.dart';
import 'package:supplier/presentation/bloc/login/login_bloc.dart';
import 'package:supplier/presentation/bloc/pop_up/pop_up_bloc.dart';
import 'package:supplier/presentation/bloc/snack_bar/snack_bar_bloc.dart';
import 'package:supplier/presentation/pages/home_screen.dart';
import 'package:supplier/presentation/pages/login_screen.dart';
import 'package:supplier/presentation/widgets/resend_otp.dart';
import 'package:supplier/presentation/widgets/screen_pop_up.dart';
import 'package:supplier/presentation/widgets/sms_retriever.dart';
import 'package:supplier/presentation/widgets/snack_bar.dart';
import 'package:url_launcher/url_launcher.dart';

class OtpForm extends StatelessWidget {
  final String whatsappNumber;
  final FocusNode _focusNode = FocusNode();

  OtpForm({required this.whatsappNumber});

  @override
  Widget build(BuildContext formcontext) {
    return BlocConsumer<LoginBloc, LoginState>(
      listener: (context, state) {
        if (state is OtpValid) {
          Navigator.pushAndRemoveUntil(
            context,
            MaterialPageRoute(
              builder: (context) => MultiBlocProvider(
                providers: [
                  BlocProvider<BottomNavigationBarBloc>(
                    create: (_) => locator<BottomNavigationBarBloc>(),
                  ),
                  BlocProvider<SnackBarBloc>(
                    create: (_) => locator<SnackBarBloc>(),
                  ),
                  BlocProvider<PopUpBloc>(
                    create: (_) => locator<PopUpBloc>(),
                  ),
                  BlocProvider<AuthBloc>(create: (_) => locator<AuthBloc>()),
                ],
                child: MultiBlocListener(
                  listeners: [
                    initialisePopUpListener(context),
                    initialiseSnackBarListener(context),
                  ],
                  child: HomeScreen(
                    accountManager: state.accountManager,
                  ),
                ),
              ),
            ),
            (Route<dynamic> route) => false,
          );
        }
        if (state is UserAppNotAllowed) {
          _dialogBuilder(
            context,
            state.message,
            state.buttonCTA,
            state.buttonText,
          );
        }
      },
      buildWhen: (previous, current) =>
          current is OtpCompleted ||
          current is PhoneNumberValid ||
          current is PhoneNumberSubmitted ||
          current is OtpIncomplete ||
          current is OtpInvalid ||
          current is ApiRequestFailed ||
          current is DataLoadingState,
      builder: (context, state) {
        return Column(
          children: [
            Container(
              margin: const EdgeInsets.only(top: 30, bottom: 10),
              child: SizedBox(
                width: MediaQuery.of(context).size.width,
                child: Pinput(
                  key: const Key('OtpInputField'),
                  separatorBuilder: (context) => const SizedBox(
                    width: 15,
                  ),
                  onChanged: (otp) {
                    context.read<LoginBloc>().add(OtpChanged(otp));
                  },
                  onCompleted: (otp) {
                    if (Platform.isIOS) {
                      _focusNode.unfocus();
                    }
                  },
                  autofocus: true,
                  hapticFeedbackType: HapticFeedbackType.lightImpact,
                  focusNode: _focusNode,
                  smsRetriever: SmsRetrieverImpl(SmartAuth()),
                  defaultPinTheme: PinTheme(
                    width: 100,
                    height: 50,
                    decoration: BoxDecoration(
                      border: Border.all(
                        color: AppColors.uiStroke10,
                      ),
                      borderRadius: BorderRadius.circular(7),
                    ),
                  ),
                ),
              ),
            ),
            _resendOtpContainer(state),
            _getVerifyButton(context, state),
          ],
        );
      },
    );
  }

  Widget _resendOtpContainer(LoginState state) {
    return Column(
      children: [
        _incorrectOtpText(state),
        const SizedBox(
          height: 20,
        ),
        ResendOtpButton(
          whatsappNumber: whatsappNumber,
        ),
      ],
    );
  }

  Widget _incorrectOtpText(LoginState state) {
    if (state is OtpInvalid) {
      return const Align(
        key: Key('incorrectOtpText'),
        alignment: Alignment.centerLeft,
        child: Column(
          children: [
            Row(
              children: [
                Icon(Icons.warning_amber, color: AppColors.uiRed100, size: 16),
                Text(
                  'You have entered a wrong OTP',
                  style: TextStyle(
                    color: AppColors.uiRed100,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ],
        ),
      );
    } else if (state is ApiRequestFailed) {
      return const Align(
        key: Key('RequestFailed'),
        alignment: Alignment.centerLeft,
        child: Column(
          children: [
            Row(
              children: [
                Icon(Icons.warning_amber, color: AppColors.uiRed100, size: 16),
                Text(
                  'Please check your internet connection!',
                  style: TextStyle(
                    color: AppColors.uiRed100,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ],
        ),
      );
    }
    return const SizedBox(
      height: 0,
    );
  }

  Widget _getVerifyButton(BuildContext context, LoginState state) {
    return Column(
      children: [
        _sizedBox(25),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton(
            key: const Key('VerifyButton'),
            onPressed: () {
              if (state is OtpCompleted) {
                context.read<LoginBloc>().add(VerifyOtp(state.otp));
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: state is OtpCompleted
                  ? AppColors.primary100
                  : AppColors.uiBlack25,
              foregroundColor: Colors.white,
              shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.all(
                  Radius.circular(5),
                ),
              ),
            ),
            child: const Text('Verify and Login'),
          ),
        ),
      ],
    );
  }

  Widget _sizedBox(double height) {
    return SizedBox(
      height: height,
    );
  }

  Future<void> _dialogBuilder(
    BuildContext popUpContext,
    String message,
    String buttonCTA,
    String buttonText,
  ) {
    return showDialog<void>(
      context: popUpContext,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: AppColors.uiBackground,
          title: const Icon(
            Icons.info,
            size: 65,
            color: AppColors.uiRed100,
          ),
          content: Text(
            message,
            style: const TextStyle(fontSize: 14),
            textAlign: TextAlign.center,
          ),
          actions: <Widget>[
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                elevation: 0,
                backgroundColor: AppColors.uiBackground,
                side: const BorderSide(width: 0.5, color: AppColors.uiBlack25),
              ),
              onPressed: () {
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const SupplierAppLogin(),
                  ),
                  (Route<dynamic> route) => false,
                );
              },
              child: const Text(
                'Close',
                style: TextStyle(color: AppColors.uiBlack100),
              ),
            ),
            ElevatedButton(
              onPressed: () async {
                final url = Uri.parse('tel:$buttonCTA');
                if (await canLaunchUrl(url)) {
                  await launchUrl(url);
                } else {
                  throw 'Could not launch $url';
                }
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color.fromARGB(255, 65, 114, 220),
                foregroundColor: Colors.white,
              ),
              child: Text(buttonText),
            ),
          ],
        );
      },
    ).then((_) {
      Navigator.pushAndRemoveUntil(
        popUpContext,
        MaterialPageRoute(
          builder: (context) => const SupplierAppLogin(),
        ),
        (Route<dynamic> route) => false,
      );
    });
  }
}

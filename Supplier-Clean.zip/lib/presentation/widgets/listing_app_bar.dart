import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';
import 'package:supplier/config/theme/app_colors.dart';
import 'package:supplier/core/utils/utils.dart';
import 'package:supplier/data/models/analytics.dart';
import 'package:supplier/presentation/bloc/pop_up/pop_up_bloc.dart';
import 'package:supplier/presentation/bloc/supplier_page_bloc/supplier_page_bloc_bloc.dart';
import 'package:url_launcher/url_launcher.dart';

class ListingAppBar extends StatelessWidget implements PreferredSizeWidget {
  const ListingAppBar({super.key});

  Future<void> _launchPhoneDialer(String phoneNumber) async {
    final Uri phoneUri = Uri(scheme: 'tel', path: phoneNumber);
    notifySupplierAppEvent({}, EventType.USER_TAPPED_CALL_BUTTON);

    if (await canLaunchUrl(phoneUri)) {
      await launchUrl(phoneUri);
    } else {
      throw 'Could not launch $phoneUri';
    }
  }

  @override
  Widget build(BuildContext context) {
    final double screenWidth = MediaQuery.of(context).size.width;

    return Container(
      color: AppColors.uiWhite100,
      child: Center(
        child: Container(
          width: 1200,
          color: AppColors.uiWhite100,
          child: BlocBuilder<SupplierPageBlocBloc, SupplierPageBlocState>(
            builder: (BuildContext context, SupplierPageBlocState state) {
              if (state is SupplierPageOffersBlocState) {
                return AppBar(
                  backgroundColor: AppColors.uiWhite100,
                  leading: Container(
                    margin: const EdgeInsets.symmetric(horizontal: 10),
                    child: Padding(
                      padding: const EdgeInsets.only(left: 14),
                      child: InkWell(
                        onTap: () {
                          FocusScope.of(context).unfocus();
                          if (!state.isEdited) {
                            context.read<PopUpBloc>().add(
                                  SelectLocationPopUpEvent(
                                    'Select Location',
                                    context,
                                    state.allLocations,
                                    state.selectedLocation,
                                  ),
                                );
                            return;
                          }
                          showDialog(
                            context: context,
                            builder: (BuildContext alertContext) {
                              return AlertDialog(
                                title: const Text('Confirm'),
                                content: const Text(
                                  'You have unsaved offers. Do you wish to proceed?',
                                ),
                                actions: <Widget>[
                                  TextButton(
                                    onPressed: () {
                                      Navigator.of(alertContext).pop();
                                      context.read<PopUpBloc>().add(
                                            SelectLocationPopUpEvent(
                                              'Select Location',
                                              context,
                                              state.allLocations,
                                              state.selectedLocation,
                                            ),
                                          );
                                    },
                                    style: ButtonStyle(
                                      backgroundColor: WidgetStateProperty.all(
                                        AppColors.uiRed100,
                                      ),
                                      foregroundColor: WidgetStateProperty.all(
                                        AppColors.uiWhite100,
                                      ),
                                    ),
                                    child: Container(
                                      margin: const EdgeInsets.symmetric(
                                        horizontal: 5,
                                      ),
                                      child: const Text(
                                        'Discard Changes',
                                        style: TextStyle(
                                          fontSize: 12,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                  ),
                                  TextButton(
                                    onPressed: () {
                                      Navigator.of(alertContext).pop();
                                    },
                                    style: ButtonStyle(
                                      backgroundColor: WidgetStateProperty.all(
                                        AppColors.primary100,
                                      ),
                                      foregroundColor: WidgetStateProperty.all(
                                        AppColors.uiWhite100,
                                      ),
                                    ),
                                    child: Container(
                                      margin: const EdgeInsets.symmetric(
                                        horizontal: 5,
                                      ),
                                      child: const Text(
                                        'Yes',
                                        style: TextStyle(
                                          fontSize: 12,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              );
                            },
                          );
                        },
                        child: Row(
                          children: [
                            SvgPicture.asset(
                              'assets/ICON_PIN_BOLD.svg',
                              height: 20,
                              width: 15,
                            ),
                            const SizedBox(width: 5),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const Row(
                                  children: [
                                    Text(
                                      'Location',
                                      style: TextStyle(
                                        fontSize: 12,
                                        color: AppColors.uiBlack100,
                                      ),
                                    ),
                                    Icon(
                                      Icons.keyboard_arrow_down,
                                      color: AppColors.uiBlack100,
                                      size: 16,
                                    ),
                                  ],
                                ),
                                Row(
                                  children: [
                                    Text(
                                      state.selectedLocation.name,
                                      style: const TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 14,
                                      ),
                                    ),
                                    Container(
                                      margin: const EdgeInsets.only(left: 4),
                                      padding: const EdgeInsets.symmetric(
                                        vertical: 2,
                                        horizontal: 2,
                                      ),
                                      decoration: BoxDecoration(
                                        border: Border.all(
                                          color: state.selectedLocation
                                                      .deactivated ||
                                                  state.selectedLocation
                                                          .status ==
                                                      "INACTIVE"
                                              ? AppColors.uiRed100
                                              : AppColors.uiGreen100,
                                        ),
                                        borderRadius: BorderRadius.circular(4),
                                        color: state.selectedLocation
                                                    .deactivated ||
                                                state.selectedLocation.status ==
                                                    "INACTIVE"
                                            ? AppColors.uiRed10
                                            : AppColors.uiGreen10,
                                      ),
                                      child: Text(
                                        state.selectedLocation.status,
                                        style: TextStyle(
                                          color: state.selectedLocation
                                                      .deactivated ||
                                                  state.selectedLocation
                                                          .status ==
                                                      "INACTIVE"
                                              ? AppColors.uiRed100
                                              : AppColors.uiGreen100,
                                          fontSize: 10,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  leadingWidth: 200,
                  // Modified actions for phone display similar to AppBarWidget
                  actions: screenWidth <= 580
                      ? [
                          GestureDetector(
                            onTap: () {
                              _launchPhoneDialer(
                                state.supplierAppInfo.accountManager,
                              );
                            },
                            child: Container(
                              width: 40,
                              height: 45,
                              padding: const EdgeInsets.all(5),
                              child: SvgPicture.asset(
                                'assets/ICON_PHONE.svg',
                              ),
                            ),
                          ),
                        ]
                      : [
                          Row(
                            children: [
                              SvgPicture.asset(
                                'assets/ICON_PHONE.svg',
                                height: 25,
                                width: 20,
                              ),
                              Text(
                                state.supplierAppInfo.accountManager,
                                style: const TextStyle(
                                  fontSize: 10,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              if (screenWidth <= 1200)
                                const SizedBox(width: 20)
                              else
                                const SizedBox(
                                  width: 10,
                                ),
                            ],
                          ),
                        ],
                );
              }
              return const SizedBox(height: 10);
            },
          ),
        ),
      ),
    );
  }

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight + 5);
}

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:supplier/config/theme/app_colors.dart';
import 'package:supplier/data/models/profile.dart';

class ProfileDetailsCard extends StatelessWidget {
  const ProfileDetailsCard({
    super.key,
    required this.section,
  });

  final Profile section;

  String capitalize(String word) {
    List<String> words = word.split(" ");
    if (words.isEmpty) {
      return word;
    }
    words = words
        .map((word) =>
            (word.isNotEmpty ? word[0].toUpperCase() : "") +
            (word.isNotEmpty ? word.substring(1).toLowerCase() : ''),)
        .toList();
    return words.join(' ');
  }

  @override
  Widget build(BuildContext context) {
    final double screenWidth = MediaQuery.of(context).size.width;

    Widget cardContent() {
      return Column(
        children: [
          ...section.fields.map(
            (detail) => Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      section.sectionName == 'Location & Decision Maker'
                          ? capitalize(detail.label)
                          : detail.label,
                      style: TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                        color: detail.labelTextColor == '#333333'
                            ? AppColors.uiBlack50
                            : detail.labelTextColor == '#C54326'
                                ? AppColors.uiRed100
                                : AppColors.uiGreen100,
                      ),
                    ),
                    Text(
                      section.sectionName == 'Location & Decision Maker'
                          ? capitalize(detail.value)
                          : detail.value,
                      style: TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                        color: detail.labelTextColor == '#333333'
                            ? AppColors.uiBlack100
                            : detail.labelTextColor == '#C54326'
                                ? AppColors.uiRed100
                                : AppColors.uiGreen100,
                      ),
                    ),
                  ],
                ),
                const SizedBox(
                  height: 5,
                ),
              ],
            ),
          ),
        ],
      );
    }

    return Container(
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 14),
      margin: const EdgeInsets.symmetric(vertical: 5),
      decoration: BoxDecoration(
        boxShadow: const [
          BoxShadow(
            color: AppColors.uiBlack25,
            blurRadius: 2.0,
          ),
        ],
        color: AppColors.uiWhite100,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        children: [
          Row(
            children: [
              SvgPicture.asset('assets/${section.icon}'),
              const SizedBox(
                width: 10,
              ),
              Text(
                section.sectionName,
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: AppColors.uiBlack80,
                ),
              ),
            ],
          ),
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 5),
            child: Divider(
              color: AppColors.uiStroke10,
            ),
          ),
          if (screenWidth > 610)
            Flexible(
              child: SingleChildScrollView(
                child: cardContent(),
              ),
            )
          else
            cardContent(),
        ],
      ),
    );
  }
}

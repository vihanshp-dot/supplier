import 'package:flutter/material.dart';

class EllipsizedTextWithTooltip extends StatelessWidget {
  final String text;
  final TextStyle? style;
  final int? maxLines;

  const EllipsizedTextWithTooltip({
    super.key,
    required this.text,
    this.style,
    this.maxLines = 1,
  });

  void _showTooltip(BuildContext context, TapDownDetails details) {
    final overlay = Overlay.of(context, rootOverlay: true);

    OverlayEntry? tooltipEntry;
    OverlayEntry? backdropEntry;

    void removeEntries() {
      tooltipEntry?.remove();
      backdropEntry?.remove();
      tooltipEntry = null;
      backdropEntry = null;
    }

    backdropEntry = OverlayEntry(
      builder: (context) => Positioned.fill(
        child: GestureDetector(
          behavior: HitTestBehavior.translucent,
          onTap: removeEntries,
        ),
      ),
    );

    tooltipEntry = OverlayEntry(
      builder: (context) => TooltipOverlayEntry(
        text: text,
        position: details.globalPosition,
      ),
    );

    overlay.insert(backdropEntry!);
    overlay.insert(tooltipEntry!);
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (details) => _showTooltip(context, details),
      child: Text(
        text,
        style: style,
        maxLines: maxLines,
        overflow: TextOverflow.ellipsis,
      ),
    );
  }
}

class TooltipOverlayEntry extends StatelessWidget {
  final String text;
  final Offset position;

  const TooltipOverlayEntry({
    super.key,
    required this.text,
    required this.position,
  });

  @override
  Widget build(BuildContext context) {
    return Positioned(
      left: position.dx - 20,
      top: position.dy + 20,
      child: Material(
        child: Container(
          constraints: BoxConstraints(
            maxWidth: MediaQuery.of(context).size.width * 0.5,
          ),
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: Colors.black87,
            borderRadius: BorderRadius.circular(4),
            boxShadow: const [
              BoxShadow(
                color: Colors.black26,
                blurRadius: 4,
                offset: Offset(0, 2),
              ),
            ],
          ),
          child: Text(
            text,
            style: const TextStyle(color: Colors.white),
          ),
        ),
      ),
    );
  }
}

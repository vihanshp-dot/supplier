import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:supplier/config/theme/app_colors.dart';
import 'package:supplier/core/constants/app_constants.dart';
import 'package:supplier/core/utils/utils.dart';
import 'package:supplier/data/models/order.dart';
import 'package:supplier/presentation/widgets/order_card_middle_content.dart';

class CompletedCartItem extends StatelessWidget {
  const CompletedCartItem({super.key, required this.order});

  final Order order;

  @override
  Widget build(BuildContext context) {
    final double screenWidth = MediaQuery.of(context).size.width;

    return Card(
      color: AppColors.uiWhite100,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 14),
        child: Column(
          children: [
            Row(
              children: [
                SvgPicture.asset(
                  'assets/box.svg',
                  height: 20.0,
                  width: 20.0,
                ),
                const SizedBox(
                  width: 5,
                ),
                Text(
                  order.orderNo,
                  style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const Spacer(),
                const Text(
                  'Dispatch: ',
                  style: TextStyle(
                    color: AppColors.uiBlack50,
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                Text(
                  formatDate(order.dispatchDate),
                  style: const TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
            const Divider(
              color: AppColors.uiStroke10,
              thickness: 1,
            ),
            if (screenWidth > maxPhoneWidth)
              Flexible(
                child: SingleChildScrollView(
                  child: OrderCardMiddleContent(
                    order: order,
                  ),
                ),
              )
            else
              OrderCardMiddleContent(
                order: order,
              ),
          ],
        ),
      ),
    );
  }
}

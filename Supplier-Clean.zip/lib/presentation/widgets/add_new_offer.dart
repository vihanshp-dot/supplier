import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:supplier/data/models/supplier_app_info.dart';
import 'package:supplier/injection_container.dart';
import 'package:supplier/presentation/bloc/new_offer/new_offer_bloc.dart';
import 'package:supplier/presentation/widgets/new_offer.dart';

class AddNewOffer extends StatelessWidget {
  const AddNewOffer(
      {super.key, required this.topKey, required this.supplierAppInfo,});
  final Key topKey;
  final SupplierAppInfo supplierAppInfo;

  @override
  Widget build(BuildContext context) {
    return BlocProvider<NewOfferBloc>(
      create: (_) =>
          locator<NewOfferBloc>()..add(const IntializeNewOfferEvent()),
      child: NewOffer(
        key: topKey,
        supplierAppInfo: supplierAppInfo,
      ),
    );
  }
}

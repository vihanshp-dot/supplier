import 'package:flutter/material.dart';
import 'package:supplier/core/constants/app_constants.dart';
import 'package:supplier/data/models/order.dart';
import 'package:supplier/presentation/widgets/completed_order_card.dart';
import 'package:supplier/presentation/widgets/confirmed_order_card.dart';

class OrderCardList extends StatelessWidget {
  const OrderCardList({
    super.key,
    required this.orders,
  });

  final List<Order> orders;

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;

    int calculateCrossAxisCount() {
      if (orders.isEmpty || orders[0].status == Status.completed) {
        // Logic for completed orders
        return (screenWidth / 300).floor() < 4
            ? (screenWidth / 300).floor()
            : 4;
      } else {
        // Logic for confirmed orders
        if (screenWidth > maxPhoneWidth && screenWidth <= 960) {
          return 2;
        } else if (screenWidth > 960 && screenWidth <= 1200) {
          return 3;
        } else {
          return 4;
        }
      }
    }

    double getMainAxisExtent() {
      return orders.isEmpty || orders[0].status == Status.completed ? 230 : 340;
    }

    EdgeInsets getPadding() {
      if (screenWidth <= 600) {
        return orders.isEmpty || orders[0].status == Status.completed
            ? const EdgeInsets.symmetric(horizontal: 16)
            : const EdgeInsets.all(10);
      } else {
        return orders.isEmpty || orders[0].status == Status.completed
            ? EdgeInsets.zero
            : const EdgeInsets.fromLTRB(0, 20, 0, 0);
      }
    }

    Widget buildCard(Order order) {
      return order.status == Status.completed
          ? CompletedCartItem(order: order)
          : ConfirmedCardItem(order: order);
    }

    if (screenWidth <= 600) {
      return SingleChildScrollView(
        child: Padding(
          padding: getPadding(),
          child: ListView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: orders.length,
            itemBuilder: (context, index) => buildCard(orders[index]),
          ),
        ),
      );
    } else {
      return GridView.builder(
        padding: getPadding(),
        shrinkWrap: true,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          mainAxisExtent: getMainAxisExtent(),
          crossAxisCount: calculateCrossAxisCount(),
          crossAxisSpacing: 5.0,
          mainAxisSpacing: 5.0,
        ),
        itemCount: orders.length,
        itemBuilder: (context, index) => buildCard(orders[index]),
      );
    }
  }
}

import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:supplier/config/theme/app_colors.dart';
import 'package:supplier/presentation/bloc/login/login_bloc.dart';
import 'package:supplier/presentation/widgets/custom_loader.dart';

class LoginForm extends StatelessWidget {
  final FocusNode _focusNode = FocusNode();

  LoginForm({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<LoginBloc, LoginState>(
      buildWhen: (previous, current) =>
          current is UserAppNotAllowed ||
          current is PhoneNumberValid ||
          current is DidNotReceiveReferenceToken ||
          current is PhoneNumberInvalid ||
          current is ApiRequestFailed ||
          current is DataLoadingState,
      builder: (context, state) {
        return Column(
          children: [
            Container(
              margin: const EdgeInsets.only(top: 35, bottom: 20),
              child: TextFormField(
                key: const Key('PhoneNumberField'),
                focusNode: _focusNode,
                onChanged: (value) {
                  context.read<LoginBloc>().add(PhoneNumberChanged(value));
                },
                onTapOutside: (event) {
                  if (Platform.isIOS) {
                    _focusNode.unfocus();
                  }
                },
                maxLength: 10,
                autofocus: true,
                keyboardType: TextInputType.number,
                inputFormatters: [
                  FilteringTextInputFormatter.digitsOnly,
                ],
                decoration: InputDecoration(
                  label: const Text(
                    "Mobile No",
                    style: TextStyle(color: Colors.black),
                  ),
                  hintText: 'Type 10 digit mobile number',
                  hintStyle: const TextStyle(
                    color: AppColors.uiStroke10,
                    fontSize: 14.0,
                  ),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10.0),
                    borderSide: const BorderSide(width: 30),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: const BorderSide(color: AppColors.uiStroke10),
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  floatingLabelBehavior: FloatingLabelBehavior.always,
                ),
              ),
            ),
            if (state is DataLoadingState)
              Container(
                padding: const EdgeInsets.all(10),
                child: const CustomLoader(),
              )
            else
              _getOtpButton(context, state),
          ],
        );
      },
    );
  }

  Widget _getOtpButton(BuildContext context, LoginState state) {
    return Column(
      children: [
        _errorText(
          context,
          state,
        ),
        const SizedBox(
          height: 10,
        ),
        SizedBox(
          width: double.infinity,
          height: 40,
          child: ElevatedButton(
            key: const Key('OtpButton'),
            onPressed: () async {
              if (state is PhoneNumberValid) {
                final phoneNumber = state.phoneNumber;
                context.read<LoginBloc>().add(
                      PhoneNumberSubmitted(
                        phoneNumber: phoneNumber,
                      ),
                    );
              } else if (state is UserAppNotAllowed) {
                final phoneNumber = state.phoneNumber;
                context.read<LoginBloc>().add(
                      PhoneNumberSubmitted(
                        phoneNumber: phoneNumber,
                      ),
                    );
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor:
                  (state is PhoneNumberValid || state is UserAppNotAllowed)
                      ? AppColors.primary100
                      : AppColors.uiBlack25,
              foregroundColor: Colors.white,
              shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.all(
                  Radius.circular(5),
                ),
              ),
            ),
            child: const Text(
              'Get OTP ',
              // '${context.read<LoginBloc>().state}',
              style: TextStyle(fontSize: 16),
            ),
          ),
        ),
      ],
    );
  }

  Widget _errorText(BuildContext context, LoginState state) {
    if (state is DidNotReceiveReferenceToken) {
      final String message = state.referenceToken.message;
      return Align(
        key: const Key('errorText'),
        alignment: Alignment.centerLeft,
        child: Column(
          children: [
            Wrap(
              children: [
                Text(
                  message,
                  overflow: TextOverflow.clip,
                  style: const TextStyle(
                    color: AppColors.uiRed100,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
            const SizedBox(
              height: 20,
            ),
          ],
        ),
      );
    } else if (state is ApiRequestFailed) {
      return const Align(
        key: Key('errorText'),
        alignment: Alignment.centerLeft,
        child: Column(
          children: [
            Wrap(
              children: [
                Text(
                  'Please check your internet connection!',
                  overflow: TextOverflow.clip,
                  style: TextStyle(
                    color: AppColors.uiRed100,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
            SizedBox(
              height: 20,
            ),
          ],
        ),
      );
    }
    return const SizedBox(
      height: 0,
    );
  }
}

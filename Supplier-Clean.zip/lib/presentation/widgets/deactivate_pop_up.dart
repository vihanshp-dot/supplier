import 'package:flutter/material.dart';
import 'package:supplier/config/theme/app_colors.dart';

class DeactivatePopUp extends StatelessWidget {
  const DeactivatePopUp({
    super.key,
    required this.onCancel,
    required this.onDeactivate,
    required this.currentLocationName,
  });

  final VoidCallback onCancel;
  final VoidCallback onDeactivate;
  final String currentLocationName;

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Deactivate offers'),
      content: RichText(
        text: TextSpan(
          style: const TextStyle(
            fontSize: 16,
            color: Colors.black, // Default text color
          ),
          children: [
            const TextSpan(
              text: 'Do you want to ',
            ),
            const TextSpan(
              text: 'deactivate', // Only this word will be red
              style: TextStyle(
                color: Colors.red,
                fontWeight: FontWeight.bold,
              ),
            ),
            TextSpan(
              text:
                  ' all offers for the location $currentLocationName\n'
                  "You won't receive any orders for this location once deactivated",
            ),
          ],
        ),
      ),
      actions: <Widget>[
        Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            TextButton(
              onPressed: () {
                onCancel();
              },
              style: const ButtonStyle(
                padding: WidgetStatePropertyAll(
                  EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 10,
                  ),
                ),
              ),
              child: const Text(
                'Cancel',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                  color: Colors.grey,
                ),
              ),
            ),
            const SizedBox(width: 8),
            TextButton(
              onPressed: () {
                onDeactivate();
              },
              style: const ButtonStyle(
                backgroundColor: WidgetStatePropertyAll(
                  AppColors.primary100,
                ),
                foregroundColor: WidgetStatePropertyAll(
                  AppColors.uiWhite100,
                ),
                padding: WidgetStatePropertyAll(
                  EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 10,
                  ),
                ),
              ),
              child: const Text(
                'Deactivate',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
      ],
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      contentPadding: const EdgeInsets.fromLTRB(
        24,
        24,
        24,
        0,
      ),
      actionsPadding: const EdgeInsets.fromLTRB(
        16,
        0,
        16,
        16,
      ),
    );
  }
}

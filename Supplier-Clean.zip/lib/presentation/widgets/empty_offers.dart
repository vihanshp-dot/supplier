import 'package:flutter/material.dart';

class EmptyList extends StatelessWidget {
  const EmptyList({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Image.asset(
              'assets/NO_ORDER.png',
              height: 64,
            ),
            const SizedBox(
              height: 10,
            ),
            const Text(
              'No Offers Added',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 24.0),
            ),
            const SizedBox(
              height: 5,
            ),
            const Text(
              'Currently you have added no offers for this location.\n Please add offers to get orders.',
              style: TextStyle(fontWeight: FontWeight.w300, fontSize: 14.0),
            ),
          ],
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:supplier/config/theme/app_colors.dart';

class TabContainer extends StatelessWidget {
  const TabContainer({
    super.key,
    required this.activeIndex,
    required this.filterVal,
    required this.onTabChange,
    required this.currentActiveIndex,
    required this.label,
  });

  final int activeIndex;
  final String filterVal;
  final Function(int, String) onTabChange;
  final int currentActiveIndex;
  final String label;

  @override
  Widget build(BuildContext context) {
    final double screenWidth = MediaQuery.of(context).size.width;
    return InkWell(
      onTap: () {
        onTabChange(activeIndex, filterVal);
      },
      child: Container(
        height: 48,
        width: screenWidth < 580 ? (screenWidth / 2) - 25 : 150,
        alignment: Alignment.center,
        padding: const EdgeInsets.symmetric(vertical: 16.0),
        decoration: activeIndex == currentActiveIndex
            ? const BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    AppColors.uiWhite100,
                    AppColors.primary15,
                  ],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
                border: Border(
                  bottom: BorderSide(
                    color: AppColors.primary100,
                    width: 2.0,
                  ),
                ),
              )
            : const BoxDecoration(
                border: Border(
                  bottom: BorderSide(
                    
                  ),
                ),
              ),
        child: Text(
          label,
          style: const TextStyle(
            color: AppColors.uiBlack100,
            fontWeight: FontWeight.w600,
            fontSize: 10,
          ),
        ),
      ),
    );
  }
}

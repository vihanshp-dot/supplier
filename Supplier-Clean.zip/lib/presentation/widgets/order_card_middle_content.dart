import 'package:flutter/material.dart';
import 'package:supplier/core/constants/constants.dart';
import 'package:supplier/core/utils/utils.dart';
import 'package:supplier/data/models/order.dart';
import 'package:supplier/presentation/widgets/order_detail.dart';

class OrderCardMiddleContent extends StatelessWidget {
  const OrderCardMiddleContent({
    super.key,
    required this.order,
  });

  final Order order;

  @override
  Widget build(BuildContext context) {
    // Use LayoutBuilder instead of MediaQuery for more precise control
    return LayoutBuilder(
      builder: (context, constraints) {
        final double availableWidth = constraints.maxWidth;
        // Calculate dynamic widths based on available space
        final double detailWidth =
            availableWidth < 350 ? availableWidth * 0.4 : 125.0;
        final double addressWidth = availableWidth - 32; // Account for padding

        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Common Grades Section with better spacing
              ...order.grades.map((grade) => Padding(
                    padding: const EdgeInsets.only(bottom: 16.0),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              child: OrderDetail(
                                label: 'Product',
                                content: grade.product,
                                width: detailWidth,
                              ),
                            ),
                            const SizedBox(width: 8),
                            OrderDetail(
                              label: 'Quantity',
                              content: grade.quantity,
                              width: detailWidth,
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              child: OrderDetail(
                                label: 'Sold At',
                                content: grade.sellingPrice,
                                width: detailWidth,
                              ),
                            ),
                            const SizedBox(width: 8),
                            OrderDetail(
                              label: 'Billed At',
                              content: grade.billingPrice,
                              width: detailWidth,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),),

              // Conditional Content Based on Order Status
              if (order.status == Status.completed) ...[
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: OrderDetail(
                        label: 'Payment Date',
                        content: order.paymentDate == 'NA'
                            ? 'NA'
                            : formatDate(order.paymentDate!),
                        width: detailWidth,
                      ),
                    ),
                    const SizedBox(width: 8),
                    OrderDetail(
                      label: 'UTR Number',
                      content: order.utrNo!,
                      width: detailWidth,
                      hoverRequired: true,
                    ),
                  ],
                ),
                const SizedBox(height: 12),
              ],

              if (order.status == Status.confirmed) ...[
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: OrderDetail(
                        label: 'Vehicle Number',
                        content: order.vehicleNumber!,
                        width: detailWidth,
                      ),
                    ),
                    const SizedBox(width: 8),
                    OrderDetail(
                      label: 'Driver Contact',
                      content: order.driverContact!,
                      width: detailWidth,
                    ),
                  ],
                ),
                const SizedBox(height: 12),
              ],

              // Billed To Section with proper width handling
              OrderDetail(
                label: 'Billed To',
                content: order.billTo,
                width: addressWidth,
              ),

              // Loading Address with proper width and wrapping
              if (order.status == Status.confirmed) ...[
                const SizedBox(height: 12),
                OrderDetail(
                  label: 'Loading Address',
                  content: order.loadingAddress!,
                  width: addressWidth,
                ),
              ],
            ],
          ),
        );
      },
    );
  }
}

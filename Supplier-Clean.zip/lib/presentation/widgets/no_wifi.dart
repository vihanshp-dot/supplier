import 'package:flutter/material.dart';

class NoWifi extends StatelessWidget {
  const NoWifi({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Image.asset(
              'assets/WIFI.png',
              height: 64,
            ),
            const SizedBox(
              height: 10,
            ),
            const Text(
              'Oops! No Internet',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 24.0),
            ),
            const SizedBox(
              height: 5,
            ),
            const Text(
              "You're offline.Check your connection and try again.",
              style: TextStyle(fontWeight: FontWeight.w300, fontSize: 14.0),
            ),
          ],
        ),
      ),
    );
  }
}

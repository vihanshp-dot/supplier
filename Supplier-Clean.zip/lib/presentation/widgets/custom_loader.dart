import 'package:flutter/material.dart';
import 'package:supplier/config/theme/app_colors.dart';

class CustomLoader extends StatelessWidget {
  const CustomLoader({super.key});
  @override
  Widget build(BuildContext context) {
    return const CircularProgressIndicator(
      color: AppColors.primary100,
      strokeCap: StrokeCap.round,
      strokeWidth: 5,
    );
  }
}

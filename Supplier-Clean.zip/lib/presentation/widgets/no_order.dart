import 'package:flutter/material.dart';

class NoOrder extends StatelessWidget {
  const NoOrder({super.key});

  @override
  Widget build(BuildContext context) {
    final double screenHeight = MediaQuery.of(context).size.height;
    return Container(
      margin: EdgeInsets.only(top: screenHeight / 4.5),
      child: Column(
        children: [
          Image.asset(
            'assets/NO_ORDER.png',
            height: 200,
            width: 200,
          ),
          const Text('No orders have been placed'),
        ],
      ),
    );
  }
}

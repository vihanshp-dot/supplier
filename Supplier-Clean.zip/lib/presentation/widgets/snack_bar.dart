import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:supplier/config/theme/app_colors.dart';
import 'package:supplier/presentation/bloc/snack_bar/snack_bar_bloc.dart';

// import '../../config/theme/app_colors.dart';

BlocListener<SnackBarBloc, SnackBarState> initialiseSnackBarListener(
  BuildContext context,
) {
  return BlocListener<SnackBarBloc, SnackBarState>(
    listener: (BuildContext context, SnackBarState state) {
      if (state is SnackBarShow) {
        Color backgroundColor;
        Color contentColor;

        if (state.type == SnackType.error) {
          backgroundColor = AppColors.uiRed100;
          contentColor = AppColors.uiRed10;
        } else {
          backgroundColor = AppColors.uiGreen100;
          contentColor = AppColors.uiGreen10;
        }

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: _buildContent(state.title, contentColor, state.message),
            showCloseIcon: true,
            duration: const Duration(seconds: 3),
            backgroundColor: backgroundColor,
            closeIconColor: contentColor,
            shape: RoundedRectangleBorder(
              side: BorderSide(color: contentColor),
              borderRadius: BorderRadius.circular(8),
            ),
          ),
        );
      }
    },
  );
}

Widget _buildContent(String title, Color titleColor, String? message) {
  final Text titleWidget = Text(
    title,
    style: TextStyle(
      fontWeight: FontWeight.w600,
      color: titleColor,
    ),
  );
  if (message != null) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        titleWidget,
        Text(
          message,
          style: const TextStyle(fontSize: 12),
        ),
      ],
    );
  } else {
    return titleWidget;
  }
}

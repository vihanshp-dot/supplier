import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:supplier/config/theme/app_colors.dart';
import 'package:url_launcher/url_launcher.dart';

class AppBarWidget extends StatelessWidget implements PreferredSizeWidget {
  final String accountManager;
  const AppBarWidget({super.key, required this.accountManager});

  Future<void> _launchPhoneDialer(String phoneNumber) async {
    final Uri phoneUri = Uri(scheme: 'tel', path: phoneNumber);

    if (await canLaunchUrl(phoneUri)) {
      await launchUrl(phoneUri);
    } else {
      throw 'Could not launch $phoneUri';
    }
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;

    return Container(
      color: AppColors.uiWhite100,
      child: Center(
        child: Container(
          width: 1200,
          color: AppColors.uiWhite100,
          child: AppBar(
            backgroundColor: AppColors.uiWhite100,
            leading: Container(
              margin: const EdgeInsets.symmetric(horizontal: 10),
              child: Padding(
                padding: const EdgeInsets.only(left: 14),
                child: Image.asset(
                  'assets/LOGO@4x.png',
                  fit: BoxFit.contain,
                  height: 30,
                  width: 105,
                ),
              ),
            ),
            leadingWidth: 200,
            actions: screenWidth <= 580
                ? [
                    GestureDetector(
                      onTap: () {
                        _launchPhoneDialer(accountManager);
                      },
                      child: Container(
                        width: 40,
                        height: 45,
                        padding: const EdgeInsets.all(5),
                        child: SvgPicture.asset(
                          'assets/ICON_PHONE.svg',
                        ),
                      ),
                    ),
                  ]
                : [
                    Row(
                      children: [
                        SvgPicture.asset(
                          'assets/ICON_PHONE.svg',
                          height: 25,
                          width: 20,
                        ),
                        Text(
                          accountManager,
                          style: const TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        if (screenWidth <= 1200)
                          const SizedBox(width: 20)
                        else
                          const SizedBox(
                            width: 0,
                          ),
                      ],
                    ),
                  ],
          ),
        ),
      ),
    );
  }

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight + 5);
}

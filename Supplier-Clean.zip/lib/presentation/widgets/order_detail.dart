import 'package:flutter/material.dart';
import 'package:supplier/config/theme/app_colors.dart';
import 'package:supplier/presentation/widgets/elliipsezied_text_tooltip.dart';

class OrderDetail extends StatelessWidget {
  const OrderDetail({
    required this.label,
    required this.content,
    super.key,
    this.width = 125,
    this.hoverRequired = false,
  });

  final String label;
  final String content;
  final double width;
  final bool hoverRequired;

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: BoxConstraints(maxWidth: width),
      width: width,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: const TextStyle(
              color: AppColors.uiBlack50,
              fontWeight: FontWeight.w600,
              fontSize: 12, // Increased for better readability
            ),
          ),
          const SizedBox(height: 4), // Increased spacing
          if (hoverRequired)
            EllipsizedTextWithTooltip(
              text: content,
              style: const TextStyle(
                fontSize: 12, // Increased for better readability
                fontWeight: FontWeight.w600,
              ),
            )
          else
            Text(
              content,
              style: const TextStyle(
                fontSize: 12, // Increased for better readability
                fontWeight: FontWeight.w600,
              ),
              overflow: TextOverflow.ellipsis,
              maxLines: label == 'Loading Address' || label == 'Billed To' ? 2 : 1,
            ),
        ],
      ),
    );
  }
}
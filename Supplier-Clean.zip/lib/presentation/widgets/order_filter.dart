import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:supplier/config/theme/app_colors.dart';

class OrderFilter extends StatelessWidget {
  const OrderFilter(
      {super.key, required this.filterVal, required this.setFiltervalue,});

  final String filterVal;
  final Function(String) setFiltervalue;

  static List<String> dropdownItems = [
    'Last 30 days',
    'Last 3 months',
    'Last 6 months',
    'FY ${DateTime.now().year - 1} - ${DateTime.now().year.toString().substring(2)}',
    'FY ${DateTime.now().year - 2} - ${(DateTime.now().year - 1).toString().substring(2)}',
    'FY ${DateTime.now().year - 3} - ${(DateTime.now().year - 2).toString().substring(2)}',
    'FY ${DateTime.now().year - 4} - ${(DateTime.now().year - 3).toString().substring(2)}',
  ];

  @override
  Widget build(BuildContext context) {
    return DropdownMenu(
      width: 175,
      leadingIcon: Padding(
        padding: const EdgeInsets.all(12),
        child: SvgPicture.asset(
          'assets/ICON_ORDER_TIME.svg',
          height: 12.0,
          width: 12.0,
        ),
      ),
      initialSelection: filterVal,
      textStyle: const TextStyle(
        fontSize: 10,
        fontWeight: FontWeight.w600,
      ),
      menuStyle: MenuStyle(
        backgroundColor: WidgetStateProperty.all(AppColors.uiWhite100),
      ),
      trailingIcon: const Icon(Icons.keyboard_arrow_down),
      dropdownMenuEntries: dropdownItems.map((item) {
        return DropdownMenuEntry(
          value: item,
          label: item,
          leadingIcon: filterVal == item
              ? const Icon(
                  Icons.radio_button_checked,
                  color: AppColors.primary100,
                )
              : const Icon(Icons.radio_button_unchecked),
          style: const ButtonStyle(
            minimumSize: WidgetStatePropertyAll(
              Size(170, 40),
            ),
            textStyle: WidgetStatePropertyAll(TextStyle(fontSize: 10)),
          ),
        );
      }).toList(),
      onSelected: (value) {
        setFiltervalue(value!);
      },
    );
  }
}

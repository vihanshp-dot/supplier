import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'package:flutter_svg/svg.dart';
import 'package:supplier/config/theme/app_colors.dart';
import 'package:supplier/core/constants/app_constants.dart';
import 'package:supplier/core/utils/utils.dart';
import 'package:supplier/data/models/grade.dart';

import 'package:supplier/data/models/grade_drop_down_options.dart';
import 'package:supplier/data/models/grade_group.dart';
import 'package:supplier/data/models/supplier_app_info.dart';
import 'package:supplier/presentation/bloc/new_offer/new_offer_bloc.dart';
import 'package:supplier/presentation/bloc/snack_bar/snack_bar_bloc.dart';
import 'package:supplier/presentation/bloc/supplier_page_bloc/supplier_page_bloc_bloc.dart';
import 'package:supplier/presentation/widgets/error_banner.dart';
import 'package:supplier/presentation/widgets/info_card.dart';

class NewOffer extends StatelessWidget {
  const NewOffer({super.key, required this.supplierAppInfo});
  final SupplierAppInfo supplierAppInfo;

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<NewOfferBloc, NewOfferState>(
      builder: (BuildContext context, NewOfferState state) {
        if (state is NewOfferFormState) {
          final List<GradeDropDownOption> dropdownItems =
              state.gradeOptions ?? [];
          final screenWidth = MediaQuery.of(context).size.width;

          final String? priceErrorMessage = state.selectedGrade != null
              ? getErrorTextForGradePrice(
                  state.selectedGrade!.price,
                  state.lowerPriceBand!,
                  state.upperPriceBand!,
                )
              : null;
          final String? bulkQuantityErrorMessage =
              state.selectedGrade != null &&
                      state.selectedGrade!.bulkQuantity != null
                  ? getErrorTextForQuantity(
                      state.selectedGrade!.bulkQuantity,
                      isBulk: true,
                      bulkMinQuantity: supplierAppInfo.minimumBulkQuantity,
                    )
                  : null;
          final String? bulkPriceErrorMessage = state.selectedGrade != null &&
                  state.selectedGrade!.bulkQuantity != null
              ? getErrorTextForBulk(
                  state.selectedGrade!.price,
                  state.selectedGrade?.bulkPrice,
                  state.lowerPriceBand!,
                  state.upperPriceBand!,
                )
              : null;

          return screenWidth > maxPhoneWidth
              ? _buildWebNewOffer(
                  context,
                  screenWidth,
                  state,
                  priceErrorMessage,
                  bulkPriceErrorMessage,
                  bulkQuantityErrorMessage,
                )
              : Card(
                  color: AppColors.uiWhite100,
                  margin:
                      const EdgeInsets.symmetric(vertical: 12, horizontal: 4),
                  child: Column(
                    children: [
                      const SizedBox(
                        height: 8,
                      ),
                      _buildDropDownMenu(
                        context,
                        dropdownItems,
                        state.selectedGrade,
                      ),
                      const SizedBox(
                        height: 4,
                      ),
                      _buildPriceSection(context, state),
                      const SizedBox(
                        height: 4,
                      ),
                      if (state.selectedGrade != null &&
                          state.selectedGrade!.qtyRemarks != null)
                        _buildRemarksSectionForGrade(context, state),
                      if (state.selectedGrade != null &&
                          state.selectedGrade!.bulkQuantity != null)
                        _buildBulkPriceFields(context, state),
                      if (state.selectedGrade != null &&
                          state.selectedGrade!.gradeRemarks != null &&
                          state.selectedGrade!.gradeRemarks!.trim().isNotEmpty)
                        InfoCard(
                          message: state.selectedGrade!.gradeRemarks!,
                          gradeId: state.selectedGrade!.gradeId,
                          margin: const EdgeInsets.only(
                            bottom: 10,
                            left: 10,
                            right: 10,
                          ),
                        ),
                      _buildButtonSection(
                        context,
                        state,
                        supplierAppInfo,
                        priceErrorMessage != null ||
                            bulkPriceErrorMessage != null ||
                            bulkQuantityErrorMessage != null,
                      ),
                      if ((priceErrorMessage != null &&
                              priceErrorMessage.isNotEmpty) ||
                          (bulkPriceErrorMessage != null &&
                              bulkPriceErrorMessage.isNotEmpty) ||
                          (bulkQuantityErrorMessage != null &&
                              bulkQuantityErrorMessage.isNotEmpty))
                        ErrorBanner(
                          message: selectMessageForErrorDislay(
                            priceErrorMessage ?? '',
                            bulkPriceErrorMessage ?? '',
                            bulkQuantityErrorMessage ?? '',
                          ),
                        ),
                    ],
                  ),
                );
        }
        return const Center(child: CircularProgressIndicator());
      },
    );
  }

  Widget _buildRemarksSectionForGrade(
    BuildContext context,
    NewOfferFormState state,
  ) {
    Widget buildTextField() {
      return TextField(
        controller: TextEditingController(
          text: state.selectedGrade != null
              ? state.selectedGrade!.qtyRemarks
              : '',
        )..selection = TextSelection.fromPosition(
            TextPosition(
              offset: state.selectedGrade != null
                  ? state.selectedGrade!.qtyRemarks != null
                      ? state.selectedGrade!.qtyRemarks!.length
                      : 0
                  : 0,
            ),
          ),
        readOnly: state.selectedGrade == null,
        inputFormatters: [LengthLimitingTextInputFormatter(50)],
        onChanged: (value) {
          context.read<NewOfferBloc>().add(
                UpdateGradeEvent(
                  field: GradeField.remarks,
                  value: value,
                ),
              );
        },
        decoration: InputDecoration(
          labelStyle:
              const TextStyle(color: AppColors.uiBlack100, fontSize: 10),
          isDense: true,
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 12,
            vertical: 12,
          ),
          hintStyle: const TextStyle(
            color: AppColors.uiBlack25,
            fontSize: 12,
            fontWeight: FontWeight.w600,
          ),
          labelText: 'Remark',
          hintText: 'Add Remark',
          floatingLabelBehavior: FloatingLabelBehavior.always,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: const BorderSide(
              color: AppColors.uiStroke10,
            ),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: const BorderSide(color: AppColors.primary100),
          ),
        ),
        style: const TextStyle(
          fontWeight: FontWeight.w600,
          fontSize: 12,
        ),
        keyboardType: TextInputType.text,
      );
    }

    return MediaQuery.of(context).size.width > maxPhoneWidth
        ? SizedBox(
            width: 160,
            child: buildTextField(),
          )
        : Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
            child: SizedBox(height: 40, child: buildTextField()),
          );
  }

  Widget _buildPriceSection(BuildContext context, NewOfferFormState state) {
    final String? priceError = state.selectedGrade != null
        ? getErrorTextForGradePrice(
            state.selectedGrade!.price,
            state.lowerPriceBand!,
            state.upperPriceBand!,
          )
        : null;
    Widget buildTextField() {
      return TextField(
        controller: TextEditingController(
          text: state.selectedGrade != null ? state.selectedGrade!.price : '',
        )..selection = TextSelection.fromPosition(
            TextPosition(
              offset: state.selectedGrade != null
                  ? state.selectedGrade!.price.length
                  : 0,
            ),
          ),
        decoration: InputDecoration(
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: BorderSide(
              color:
                  priceError != null ? AppColors.uiRed100 : AppColors.uiBlack25,
            ),
          ),
          labelStyle:
              const TextStyle(color: AppColors.uiBlack100, fontSize: 10),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: BorderSide(
              color:
                  priceError != null ? AppColors.uiRed100 : AppColors.uiBlack25,
            ),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: BorderSide(
              color: priceError != null
                  ? AppColors.uiRed100
                  : AppColors.primary100,
              width: 2,
            ),
          ),
          labelText: 'Price',
          hintText: 'Enter Price',
          errorText: priceError != null ? null : null,
          isDense: true,
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 12,
            vertical: 12,
          ),
          errorStyle: const TextStyle(
            color: AppColors.uiRed100,
            fontSize: 9,
            height: 0.8,
          ),
          hintStyle: TextStyle(
            color: MediaQuery.of(context).size.width > maxPhoneWidth
                ? AppColors.uiBlack25
                : AppColors.uiStroke10,
            fontSize: 12,
            fontWeight: MediaQuery.of(context).size.width > maxPhoneWidth
                ? FontWeight.w600
                : FontWeight.normal,
          ),
          floatingLabelBehavior: FloatingLabelBehavior.always,
        ),
        onChanged: (value) {
          context.read<NewOfferBloc>().add(
                UpdateGradeEvent(
                  field: GradeField.price,
                  value: value,
                ),
              );
        },
        readOnly: state.selectedGrade == null,
        inputFormatters: <TextInputFormatter>[
          FilteringTextInputFormatter.allow(
            RegExp(r'^\d*\.?\d{0,2}'),
          ),
        ],
        keyboardType: const TextInputType.numberWithOptions(
          decimal: true,
          signed: true,
        ),
        style: const TextStyle(
          fontWeight: FontWeight.w600,
          fontSize: 12,
        ),
      );
    }

    return MediaQuery.of(context).size.width > maxPhoneWidth
        ? SizedBox(
            width: 160,
            child: buildTextField(),
          )
        : Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 0),
            child: SizedBox(height: 40, child: buildTextField()),
          );
  }

  Widget _buildButtonSection(
    BuildContext context,
    NewOfferFormState state,
    SupplierAppInfo supplierAppInfo,
    bool errorMessagePresent,
  ) {
    // Common Add Offer button content
    Widget buildAddOfferButton() {
      return TextButton(
        onPressed: () {
          FocusScope.of(context).unfocus();
          if (state.selectedGrade == null) {
            BlocProvider.of<SnackBarBloc>(context).add(
              SnackBarDisplayed(
                'Please select a grade',
                type: SnackType.error,
              ),
            );
            return;
          }
          if (state.selectedGrade != null) {
            final bool validOffer = checkValidOffer(
              state.selectedGrade!,
              state.lowerPriceBand!,
              state.upperPriceBand!,
              supplierAppInfo.minimumBulkQuantity,
            );
            if (validOffer) {
              try {
                context.read<SupplierPageBlocBloc>().add(
                      AddGradeToListingEvent(
                        grade: state.selectedGrade!,
                        gradegroup: Gradegroup(
                          gradeGroupId: state.gradeGroupId!,
                          gradeGroupName: state.gradeGroupName!,
                          lowerPriceBand: state.lowerPriceBand!,
                          upperPriceBand: state.upperPriceBand!,
                          grades: const [],
                        ),
                      ),
                    );
                BlocProvider.of<SnackBarBloc>(context).add(
                  SnackBarDisplayed(
                    'Grade added successfully',
                  ),
                );
                context
                    .read<NewOfferBloc>()
                    .add(const IntializeNewOfferEvent());
              } catch (e) {
                BlocProvider.of<SnackBarBloc>(context).add(
                  SnackBarDisplayed(
                    e.toString(),
                    type: SnackType.error,
                  ),
                );
              }
            } else {
              BlocProvider.of<SnackBarBloc>(context).add(
                SnackBarDisplayed(
                  'Invalid Inputs, please check again',
                  type: SnackType.error,
                ),
              );
            }
          }
        },
        child: const Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.add,
              color: AppColors.uiWhite100,
            ),
            SizedBox(width: 5),
            Text(
              'Add Offer',
              softWrap: true,
              style: TextStyle(
                color: AppColors.uiWhite100,
                fontWeight: FontWeight.w600,
                fontSize: 10,
              ),
            ),
          ],
        ),
      );
    }

    final double width = MediaQuery.of(context).size.width;
    if (width > maxPhoneWidth) {
      return Container(
        width: 100,
        padding: const EdgeInsets.symmetric(vertical: 15),
        decoration: const BoxDecoration(
          borderRadius: BorderRadius.only(
            bottomRight: Radius.circular(10),
            topRight: Radius.circular(10),
          ),
          color: AppColors.primary100,
        ),
        child: buildAddOfferButton(),
      );
    }

    return Container(
      child: Row(
        children: [
          Container(
            width: (MediaQuery.of(context).size.width - 28) / 3,
            height: 40,
            decoration: const BoxDecoration(
              border: Border(
                top: BorderSide(color: AppColors.uiStroke10),
                right: BorderSide(color: AppColors.uiStroke10),
              ),
            ),
            child: TextButton(
              onPressed: state.selectedGrade == null ||
                      (state.selectedGrade!.bulkPrice != null ||
                          !supplierAppInfo.isBulkOfferAllowed)
                  ? null
                  : () {
                      context.read<NewOfferBloc>().add(
                            AddBulkOffersEvent(
                              defaultBulkQuantity:
                                  supplierAppInfo.defaultQuantity,
                            ),
                          );
                      FocusScope.of(context).unfocus();
                    },
              child: const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.add_circle_outline,
                    color: AppColors.primary100,
                  ),
                  SizedBox(width: 5),
                  Text(
                    'Add Bulk price',
                    style: TextStyle(
                      color: AppColors.primary100,
                      fontWeight: FontWeight.w600,
                      fontSize: 8,
                    ),
                  ),
                ],
              ),
            ),
          ),
          Container(
            width: (MediaQuery.of(context).size.width - 28) / 3,
            height: 40,
            decoration: const BoxDecoration(
              border: Border(
                top: BorderSide(color: AppColors.uiStroke10),
                right: BorderSide(color: AppColors.uiStroke10),
              ),
            ),
            child: TextButton(
              onPressed: (state.selectedGrade == null ||
                      state.selectedGrade!.qtyRemarks != null)
                  ? null
                  : () {
                      context.read<NewOfferBloc>().add(
                            const UpdateGradeEvent(
                              field: GradeField.remarks,
                              value: '',
                            ),
                          );
                      FocusScope.of(context).unfocus();
                    },
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SvgPicture.asset(
                    'assets/ICON_PEN.svg',
                    height: 15,
                    width: 15,
                    colorFilter: ColorFilter.mode(
                      state.selectedGrade != null &&
                              state.selectedGrade!.qtyRemarks != null
                          ? AppColors.primary100
                          : AppColors.uiBlack25,
                      BlendMode.srcIn,
                    ),
                  ),
                  const SizedBox(width: 5),
                  const Text(
                    'Add Remark',
                    style: TextStyle(
                      color: AppColors.uiBlack25,
                      fontWeight: FontWeight.w600,
                      fontSize: 10,
                    ),
                  ),
                ],
              ),
            ),
          ),
          Container(
            width: (MediaQuery.of(context).size.width - 28) / 3,
            height: 40,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.only(
                bottomRight: Radius.circular(errorMessagePresent ? 0 : 10),
              ),
              color: AppColors.primary100,
            ),
            child: buildAddOfferButton(),
          ),
        ],
      ),
    );
  }

  Widget _buildBulkPriceFields(BuildContext context, NewOfferFormState state) {
    return Container(
      padding: const EdgeInsets.all(14),
      height: 70,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: _buildBulkQuantityField(context, state),
          ),
          const SizedBox(width: 10),
          SizedBox(
            width: 95,
            height: 40,
            child: _buildBulkPriceField(context, state),
          ),
          const SizedBox(width: 8),
          SizedBox(height: 40, child: _buildBulkDeleteButton(context)),
        ],
      ),
    );
  }

  Widget _buildBulkQuantityField(
    BuildContext context,
    NewOfferFormState state,
  ) {
    final String? bulkQuantityError = getErrorTextForQuantity(
      state.selectedGrade?.bulkQuantity,
      isBulk: true,
      bulkMinQuantity: supplierAppInfo.minimumBulkQuantity,
    );

    return TextFormField(
      initialValue: state.selectedGrade?.bulkQuantity,
      onChanged: (value) {
        context.read<NewOfferBloc>().add(
              UpdateBulkOffersEvent(
                gradeField: GradeField.bulkQuantity,
                value: value,
              ),
            );
      },
      style: const TextStyle(
        fontWeight: FontWeight.w600,
        fontSize: 12,
      ),
      readOnly: state.selectedGrade == null,
      decoration: InputDecoration(
        floatingLabelBehavior: FloatingLabelBehavior.always,
        isDense: true,
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 10,
          vertical: 10,
        ),
        labelText: 'Bulk Quantity',
        hintText: 'Quantity in MT',
        errorText: bulkQuantityError != null ? null : null,
        labelStyle: const TextStyle(color: AppColors.uiBlack100, fontSize: 8),
        hintStyle: const TextStyle(
          color: AppColors.uiBlack25,
          fontSize: 8,
          fontWeight: FontWeight.w600,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(
            color: bulkQuantityError != null ? Colors.red : AppColors.uiBlack25,
          ),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(
            color: bulkQuantityError != null ? Colors.red : AppColors.uiBlack25,
          ),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(
            color:
                bulkQuantityError != null ? Colors.red : AppColors.primary100,
            width: 2,
          ),
        ),
      ),
      inputFormatters: <TextInputFormatter>[
        FilteringTextInputFormatter.allow(
          RegExp(r'^\d*\.?\d{0,2}'),
        ),
      ],
      keyboardType: const TextInputType.numberWithOptions(
        decimal: true,
        signed: true,
      ),
    );
  }

  Widget _buildBulkPriceField(BuildContext context, NewOfferFormState state) {
    final String? bulkPriceError = getErrorTextForBulk(
      state.selectedGrade!.price,
      state.selectedGrade?.bulkPrice,
      state.lowerPriceBand!,
      state.upperPriceBand!,
    );

    return TextFormField(
      onChanged: (value) {
        context.read<NewOfferBloc>().add(
              UpdateBulkOffersEvent(
                gradeField: GradeField.bulkPrice,
                value: value,
              ),
            );
      },
      style: const TextStyle(
        fontWeight: FontWeight.w600,
        fontSize: 12,
      ),
      readOnly: state.selectedGrade == null,
      decoration: InputDecoration(
        labelStyle: const TextStyle(color: AppColors.uiBlack100, fontSize: 8),
        floatingLabelBehavior: FloatingLabelBehavior.always,
        isDense: true,
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 12,
          vertical: 10,
        ),
        labelText: 'Price',
        hintText: 'Price in ₹',
        errorText: state.selectedGrade == null
            ? null
            : bulkPriceError != null
                ? null
                : null,
        hintStyle: const TextStyle(
          color: AppColors.uiBlack25,
          fontSize: 12,
          fontWeight: FontWeight.w600,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(
            color: bulkPriceError != null
                ? AppColors.uiRed100
                : AppColors.uiBlack25,
          ),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(
            color: bulkPriceError != null
                ? AppColors.uiRed100
                : AppColors.uiBlack25,
          ),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(
            color: bulkPriceError != null
                ? AppColors.uiRed100
                : AppColors.primary100,
            width: 2,
          ),
        ),
      ),
      inputFormatters: <TextInputFormatter>[
        FilteringTextInputFormatter.allow(
          RegExp(r'^\d*\.?\d{0,2}'),
        ),
      ],
      keyboardType: const TextInputType.numberWithOptions(
        decimal: true,
        signed: true,
      ),
    );
  }

  Widget _buildBulkDeleteButton(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        border: Border.all(color: AppColors.uiBlack25),
        borderRadius: BorderRadius.circular(8),
      ),
      child: IconButton(
        onPressed: () {
          FocusScope.of(context).unfocus();
          context.read<NewOfferBloc>().add(
                const DeleteBulkOffersEvent(),
              );
        },
        icon: SvgPicture.asset(
          'assets/ICON_DELETE.svg',
          height: 15,
          width: 20,
          colorFilter: const ColorFilter.mode(
            AppColors.uiRed100,
            BlendMode.srcIn,
          ),
        ),
        padding: const EdgeInsets.all(8),
        constraints: const BoxConstraints(),
      ),
    );
  }

  Widget _buildDropDownMenu(
    BuildContext context,
    List<GradeDropDownOption> dropdownItems,
    Grade? selectedGrade,
  ) {
    final double width = MediaQuery.of(context).size.width;
    final focusNode = context.read<NewOfferBloc>().gradeDropdownFocusNode;
    return BlocSelector<SupplierPageBlocBloc, SupplierPageBlocState,
        Map<String, Gradegroup>>(
      selector: (state) {
        return state is SupplierPageOffersBlocState ? state.gradeGroupMap : {};
      },
      builder: (BuildContext context, Map<String, Gradegroup> gradeGroups) {
        final List<Grade> currentGrades = getAllGrades(gradeGroups);
        return Padding(
          padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 4),
          child: DropdownMenu(
            requestFocusOnTap: true,
            focusNode: focusNode,
            menuHeight: 150,
            width: MediaQuery.of(context).size.width > maxPhoneWidth
                ? 220
                : MediaQuery.of(context).size.width - 56,
            hintText: 'Choose a Grade ',
            textStyle: const TextStyle(
              fontSize: 10,
              color: AppColors.uiBlack100,
              fontWeight: FontWeight.w500,
            ),
            menuStyle: MenuStyle(
              backgroundColor: WidgetStateProperty.all(AppColors.uiWhite100),
              padding: WidgetStateProperty.all(EdgeInsets.zero),
              elevation: WidgetStateProperty.all(2),
              shape: WidgetStateProperty.all(
                RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
            ),
            inputDecorationTheme: InputDecorationTheme(
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: const BorderSide(color: AppColors.uiStroke10),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: const BorderSide(color: AppColors.uiStroke10),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: const BorderSide(color: AppColors.primary100),
              ),
              contentPadding:
                  const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              constraints: BoxConstraints.tight(
                Size.fromHeight(width > maxPhoneWidth ? 35 : 40),
              ),
            ),
            trailingIcon: Transform.translate(
              offset: Offset(0, width > maxPhoneWidth ? -6 : -4),
              child: GestureDetector(
                  onTap: () {
                    focusNode.requestFocus();
                  },
                  child: const Icon(Icons.keyboard_arrow_down)),
            ),
            dropdownMenuEntries: _buildDropDownMenuOptions(
              context,
              dropdownItems,
              currentGrades,
            ),
            initialSelection: selectedGrade,
            onSelected: (value) {
              if (value != null) {
                final selectedItem = dropdownItems.firstWhere(
                  (item) => item.gradeId == value,
                );
                context.read<NewOfferBloc>().add(
                      AddNewGradeEvent(
                        grade: Grade(
                          gradeId: value.toString(),
                          price: '',
                          displayName: selectedItem.displayName,
                          qtyRemarks: kIsWeb ? '' : null,
                          gradeRemarks: selectedItem.gradeRemarks,
                        ),
                        gradeGroupId: selectedItem.gradeGroupId,
                        lowerPriceBand: selectedItem.lowerPriceBand,
                        upperPriceBand: selectedItem.upperPriceBand,
                        gradeGroupName: selectedItem.gradeGroupName,
                      ),
                    );
              }
            },
            searchCallback: (
              List<DropdownMenuEntry> entries,
              String query,
            ) {
              if (query.trim().length >= 2) {
                final isExistingSelection = dropdownItems.any(
                  (item) =>
                      item.dropdownDisplayName.toLowerCase() ==
                      query.trim().toLowerCase(),
                );
                if (!isExistingSelection) {
                  context.read<NewOfferBloc>().add(
                        GetGradesListForDropDownEvent(value: query),
                      );
                }
              }
              return null;
            },
          ),
        );
      },
    );
  }

  List<DropdownMenuEntry> _buildDropDownMenuOptions(
    BuildContext context,
    List<GradeDropDownOption> dropdownItems,
    List<Grade> presentGrades,
  ) {
    if (dropdownItems.isEmpty) {
      return [
        DropdownMenuEntry(
          value: null,
          label: '',
          enabled: false,
          style: ButtonStyle(
            backgroundColor: WidgetStateProperty.all(AppColors.uiWhite100),
            minimumSize: const WidgetStatePropertyAll(
              Size.fromHeight(40),
            ),
            padding: const WidgetStatePropertyAll(
              EdgeInsets.symmetric(horizontal: 12),
            ),
            textStyle: const WidgetStatePropertyAll(
              TextStyle(
                fontSize: 12,
                color: AppColors.uiBlack100,
              ),
            ),
          ),
        ),
      ];
    }

    return dropdownItems.map((item) {
      final int index = checkIfGradeIsPresent(presentGrades, item.gradeId);
      final bool isSelected = index != -1;
      return DropdownMenuEntry(
        value: index == -1 ? item.gradeId : null,
        label: item.dropdownDisplayName,
        trailingIcon: isSelected
            ? const Icon(Icons.check, color: AppColors.uiGreen100)
            : null,
        enabled: !isSelected,
        style: ButtonStyle(
          backgroundColor: WidgetStateProperty.resolveWith((states) {
            if (states.contains(WidgetState.hovered)) {
              return AppColors.uiStroke10.withOpacity(0.1);
            }
            return AppColors.uiWhite100;
          }),
          minimumSize: const WidgetStatePropertyAll(
            Size.fromHeight(40),
          ),
          padding: const WidgetStatePropertyAll(
            EdgeInsets.symmetric(horizontal: 12),
          ),
          textStyle: WidgetStateProperty.resolveWith((states) {
            return TextStyle(
              fontSize: 12,
              color: isSelected ? AppColors.uiBlack25 : AppColors.uiBlack50,
              fontWeight: FontWeight.w400,
            );
          }),
        ),
      );
    }).toList();
  }

  Widget _buildWebNewOffer(
    BuildContext context,
    double screenWidth,
    NewOfferFormState state,
    String? priceErrorMessage,
    String? bulkPriceErrorMessage,
    String? bulkQuantityErrorMessage,
  ) {
    return Card(
      color: AppColors.uiWhite100,
      margin: const EdgeInsets.symmetric(
        vertical: 8,
      ),
      child: SizedBox(
        width: (state.selectedGrade == null ||
                state.selectedGrade!.bulkQuantity == null)
            ? 828
            : 1035,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 600,
                  padding: const EdgeInsets.symmetric(horizontal: 2),
                  child: Row(
                    children: [
                      _buildDropDownMenu(
                        context,
                        state.gradeOptions ?? [],
                        state.selectedGrade,
                      ),
                      const SizedBox(
                        width: 5,
                      ),
                      _buildPriceSection(context, state),
                      const SizedBox(
                        width: 5,
                      ),
                      _buildRemarksSectionForGrade(context, state),
                      const SizedBox(
                        width: 5,
                      ),
                    ],
                  ),
                ),
                if (state.selectedGrade == null ||
                    state.selectedGrade!.bulkQuantity == null)
                  Container(
                    color: AppColors.primary15,
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    child: TextButton.icon(
                      onPressed: state.selectedGrade == null ||
                              (state.selectedGrade!.bulkPrice != null ||
                                  !supplierAppInfo.isBulkOfferAllowed)
                          ? null
                          : () {
                              context.read<NewOfferBloc>().add(
                                    AddBulkOffersEvent(
                                      defaultBulkQuantity:
                                          supplierAppInfo.defaultQuantity,
                                    ),
                                  );
                              FocusScope.of(context).unfocus();
                            },
                      icon: const Icon(
                        Icons.add_circle_outline,
                        color: AppColors.primary100,
                        size: 16,
                      ),
                      label: const Text(
                        'Add Bulk price',
                        style: TextStyle(
                          color: AppColors.primary100,
                          fontWeight: FontWeight.w600,
                          fontSize: 12,
                        ),
                      ),
                    ),
                  ),
                if (state.selectedGrade != null &&
                    state.selectedGrade!.bulkQuantity != null &&
                    supplierAppInfo.isBulkOfferAllowed)
                  Container(
                    padding: const EdgeInsets.symmetric(vertical: 6),
                    width: 1200 * 0.28,
                    color: AppColors.primary15,
                    child: Row(
                      children: [
                        SizedBox(
                          width: 120,
                          child: _buildBulkQuantityField(context, state),
                        ),
                        const SizedBox(
                          width: 10,
                        ),
                        SizedBox(
                          width: 120,
                          child: _buildBulkPriceField(context, state),
                        ),
                        const SizedBox(
                          width: 10,
                        ),
                        _buildBulkDeleteButton(context),
                      ],
                    ),
                  ),
                Container(
                  padding: const EdgeInsets.symmetric(
                    vertical: 8,
                  ),
                  decoration: const BoxDecoration(
                    borderRadius: BorderRadius.only(
                      bottomRight: Radius.circular(10),
                      topRight: Radius.circular(10),
                    ),
                    color: AppColors.primary100,
                  ),
                  child: TextButton(
                    onPressed: () {
                      FocusScope.of(context).unfocus();
                      if (state.selectedGrade == null) {
                        BlocProvider.of<SnackBarBloc>(context).add(
                          SnackBarDisplayed(
                            'Please select a grade',
                            type: SnackType.error,
                          ),
                        );
                        return;
                      }
                      if (state.selectedGrade != null) {
                        final bool validOffer = checkValidOffer(
                          state.selectedGrade!,
                          state.lowerPriceBand!,
                          state.upperPriceBand!,
                          supplierAppInfo.minimumBulkQuantity,
                        );
                        if (validOffer) {
                          try {
                            context.read<SupplierPageBlocBloc>().add(
                                  AddGradeToListingEvent(
                                    grade: state.selectedGrade!,
                                    gradegroup: Gradegroup(
                                      gradeGroupId: state.gradeGroupId!,
                                      gradeGroupName: state.gradeGroupName!,
                                      lowerPriceBand: state.lowerPriceBand!,
                                      upperPriceBand: state.upperPriceBand!,
                                      grades: const [],
                                    ),
                                  ),
                                );
                            BlocProvider.of<SnackBarBloc>(context).add(
                              SnackBarDisplayed(
                                'Grade added successfully',
                              ),
                            );
                            context
                                .read<NewOfferBloc>()
                                .add(const IntializeNewOfferEvent());
                          } catch (e) {
                            BlocProvider.of<SnackBarBloc>(context).add(
                              SnackBarDisplayed(
                                e.toString(),
                                type: SnackType.error,
                              ),
                            );
                          }
                        } else {
                          BlocProvider.of<SnackBarBloc>(context).add(
                            SnackBarDisplayed(
                              'Invalid Inputs, please check again',
                              type: SnackType.error,
                            ),
                          );
                        }
                      }
                    },
                    child: const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.add,
                          color: AppColors.uiWhite100,
                        ),
                        SizedBox(
                          width: 5,
                        ),
                        Text(
                          'Add Offer',
                          softWrap: true,
                          style: TextStyle(
                            color: AppColors.uiWhite100,
                            fontWeight: FontWeight.w600,
                            fontSize: 10,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            if (state.selectedGrade != null &&
                state.selectedGrade!.gradeRemarks != null &&
                state.selectedGrade!.gradeRemarks!.trim().isNotEmpty)
              SizedBox(
                width: 600,
                child: InfoCard(
                  message: state.selectedGrade!.gradeRemarks!,
                  gradeId: state.selectedGrade!.gradeId,
                ),
              ),
            if ((priceErrorMessage != null && priceErrorMessage.isNotEmpty) ||
                (bulkPriceErrorMessage != null &&
                    bulkPriceErrorMessage.isNotEmpty) ||
                (bulkQuantityErrorMessage != null &&
                    bulkQuantityErrorMessage.isNotEmpty))
              SizedBox(
                child: ErrorBanner(
                  message: selectMessageForErrorDislay(
                    priceErrorMessage ?? '',
                    bulkPriceErrorMessage ?? '',
                    bulkQuantityErrorMessage ?? '',
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

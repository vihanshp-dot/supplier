import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:supplier/config/theme/app_colors.dart';

class ErrorBanner extends StatelessWidget {
  final String message;
  final String? svgAssetPath;
  final Color backgroundColor;
  final Color textColor;
  final EdgeInsetsGeometry padding;
  final double borderRadius;
  final double iconSize;
  final double bottomBorderRadius;

  const ErrorBanner({
    super.key,
    required this.message,
    this.svgAssetPath,
    this.backgroundColor = AppColors.uiRed100,
    this.textColor = AppColors.uiWhite100,
    this.padding = const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
    this.borderRadius = 8.0,
    this.iconSize = 18,
    this.bottomBorderRadius = 12.0,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      height: 40,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.only(
          bottomLeft: Radius.circular(bottomBorderRadius),
          bottomRight: Radius.circular(bottomBorderRadius),
        ),
        color: backgroundColor,
        boxShadow: const [
          BoxShadow(
            color: AppColors.uiBlack25,
            blurRadius: 4.0,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Padding(
        padding: padding,
        child: Row(
          children: [
            const SizedBox(width: 10),
            SvgPicture.asset(
              'assets/warning.svg',
              width: iconSize,
              height: iconSize,
              colorFilter: ColorFilter.mode(
                textColor,
                BlendMode.srcIn,
              ),
            ),
            const SizedBox(width: 4),
            Expanded(
              child: Text(
                message,
                style: TextStyle(
                  color: textColor,
                  fontSize: 10,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

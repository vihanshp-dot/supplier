import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supplier/config/theme/app_colors.dart';

class CustomTextField extends StatelessWidget {
  const CustomTextField({
    super.key,
    required this.labelText,
    required this.hintText,
    required this.onChange,
    required this.isReadOnly,
    required this.inputFormatters,
    required this.textInputType,
    required this.initialValue,
    this.errorText,
  });

  final String labelText;
  final String hintText;
  final bool isReadOnly;
  final String? errorText;
  final String initialValue;
  final TextInputType textInputType;
  final List<TextInputFormatter> inputFormatters;
  final Function(String val) onChange;

  @override
  Widget build(BuildContext context) {
    return TextField(
      onChanged: onChange,
      controller: TextEditingController(text: initialValue)
        ..selection = TextSelection.fromPosition(
          TextPosition(offset: initialValue.length),
        ),
      readOnly: isReadOnly,
      inputFormatters: inputFormatters,
      keyboardType: textInputType,
      decoration: InputDecoration(
        isDense: true,
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 12,
          vertical: 12,
        ),
        errorMaxLines: 4,
        errorText: errorText,
        labelText: labelText,
        hintText: hintText,
        hintStyle: const TextStyle(color: AppColors.uiStroke10, fontSize: 12),
        floatingLabelBehavior: FloatingLabelBehavior.always,
        border: OutlineInputBorder(
          borderSide: const BorderSide(
            color: AppColors.uiStroke10,
          ),
          borderRadius: BorderRadius.circular(8),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(color: AppColors.primary100),
        ),
      ),
      style: const TextStyle(
        fontWeight: FontWeight.w600,
        fontSize: 14,
      ),
    );
  }
}

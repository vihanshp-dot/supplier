import 'package:flutter/material.dart';

class BackgroundPattern extends StatelessWidget {
  const BackgroundPattern({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      key: const Key('Background Pattern'),
      height: 400,
      padding: EdgeInsets.zero,
      margin: EdgeInsets.zero,
      decoration: const BoxDecoration(
        image: DecorationImage(
          image: AssetImage('assets/background.png'),
        ),
      ),
    );
  }
}

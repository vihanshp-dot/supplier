import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:supplier/config/theme/app_colors.dart';
import 'package:supplier/core/constants/app_constants.dart';
import 'package:supplier/core/utils/utils.dart';
import 'package:supplier/data/models/analytics.dart';
import 'package:supplier/data/models/location.dart';
import 'package:supplier/presentation/bloc/pop_up/pop_up_bloc.dart';
import 'package:supplier/presentation/bloc/supplier_page_bloc/supplier_page_bloc_bloc.dart';
import 'package:supplier/presentation/widgets/confirm_offer_dialog.dart';
import 'package:supplier/presentation/widgets/deactivate_pop_up.dart';

BlocListener<PopUpBloc, PopUpState> initialisePopUpListener(
  BuildContext context,
) {
  return BlocListener<PopUpBloc, PopUpState>(
    listener: (BuildContext context, PopUpState state) {
      if (state is! PopUpStateInitial) {
        final BuildContext modalContext = state.context!;
        final double width = MediaQuery.sizeOf(modalContext).width;
        final Alignment alignment =
            width >= maxPhoneWidth || state is ConfirmUpdateAgainPopUpState
                ? Alignment.center
                : Alignment.bottomCenter;
        final double screenWidthFactor = width >= maxPhoneWidth ? 0.8 : 1;
        final double screenHeightFactor = width >= maxPhoneWidth ? 0.8 : 0.7;

        showGeneralDialog(
          barrierLabel: state.label,
          barrierDismissible: true,
          barrierColor: Colors.black.withOpacity(0.6),
          context: modalContext,
          pageBuilder: (BuildContext context, _, __) {
            return Theme(
              data: Theme.of(state.context!),
              child: Align(
                alignment: alignment,
                child: Container(
                  width: state is ConfirmUpdateAgainPopUpState
                      ? 300
                      : MediaQuery.of(context).size.width * screenWidthFactor,
                  constraints: BoxConstraints(
                    maxHeight: state is ConfirmUpdateAgainPopUpState
                        ? 225
                        : MediaQuery.of(context).size.height *
                            screenHeightFactor,
                    minWidth: 350,
                  ),
                  clipBehavior: Clip.antiAlias,
                  decoration: const BoxDecoration(
                    color: AppColors.uiWhite100,
                    borderRadius: BorderRadius.all(Radius.circular(10)),
                  ),
                  child: Material(
                    child: _buildWidgetForDialog(state, modalContext),
                  ),
                ),
              ),
            );
          },
          transitionBuilder:
              (_, Animation<double> animation1, __, Widget child) {
            return SlideTransition(
              position: Tween(
                begin: const Offset(0, 1),
                end: Offset.zero,
              ).animate(animation1),
              child: child,
            );
          },
        ).then((_) {
          BlocProvider.of<PopUpBloc>(modalContext)
              .add(DismissPopUpEvent(modalContext));
        });
      }
    },
  );
}

Widget _buildWidgetForDialog(PopUpState state, BuildContext modalContext) {
  if (state is SelectLocationScreenState) {
    final List<Location> locations = state.locations;
    final Location currentLocation = state.currentLocation;
    final gradeIndex =
        locations.indexWhere((l) => l.locationId == currentLocation.locationId);

    return SingleChildScrollView(
      child: Container(
        padding: const EdgeInsets.fromLTRB(24, 24, 24, 16),
        decoration: const BoxDecoration(
          color: AppColors.uiWhite100,
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            const Padding(
              padding: EdgeInsets.only(bottom: 8),
              child: Text(
                'Select location',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: locations.length,
              itemBuilder: (context, index) {
                final location = locations[index];
                return Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: InkWell(
                    onTap: () {
                      Future.microtask(() {
                        modalContext.read<SupplierPageBlocBloc>().add(
                              LocationChangeEvent(location: locations[index]),
                            );
                        Navigator.of(modalContext).pop();
                      });
                    },
                    child: Row(
                      children: [
                        Radio<int>(
                          value: index,
                          groupValue: gradeIndex,
                          onChanged: (value) {
                            Future.microtask(() {
                              modalContext.read<SupplierPageBlocBloc>().add(
                                    LocationChangeEvent(
                                      location: locations[value!],
                                    ),
                                  );
                              Navigator.of(modalContext).pop();
                            });
                          },
                        ),
                        Expanded(
                          child: Text(
                            location.name,
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w400,
                            ),
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 6,
                          ),
                          decoration: BoxDecoration(
                            color: !location.deactivated &&
                                    location.status != "INACTIVE"
                                ? Colors.green.withOpacity(0.1)
                                : Colors.red.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: Text(
                            location.status,
                            style: TextStyle(
                              color: !location.deactivated &&
                                      location.status != "INACTIVE"
                                  ? Colors.green
                                  : Colors.red,
                              fontSize: 12,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
  if (state is ConfirmOffersPopUpState) {
    return ConfirmOfferDialog(
      gradeGroupMap: state.gradeGroupMap,
      currentLocation: state.currentLocation,
      buildContext: modalContext,
    );
  }

  if (state is ConfirmUpdateAgainPopUpState) {
    SupplierAppAnalytics.instance.push(
      {
        "message": state.message,
        "locationId": state.currentLocation.locationId,
      },
      EventType.PRICE_UPDATED_POPUP_ALERT,
    );
    return Center(
      child: Container(
        height: 225,
        width: 350,
        padding: const EdgeInsets.all(16),
        decoration: const BoxDecoration(
          color: AppColors.uiWhite100,
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                const Text(
                  'Alert!',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const Spacer(),
                IconButton(
                  onPressed: () {
                    Navigator.of(modalContext).pop();
                    modalContext.read<SupplierPageBlocBloc>().add(
                          SupplierPageOffersEvent(
                            locationId: state.currentLocation.locationId,
                          ),
                        );
                  },
                  icon: const Icon(Icons.close),
                ),
              ],
            ),
            const Divider(),
            const SizedBox(
              height: 10,
            ),
            Text.rich(
              TextSpan(
                children: [
                  TextSpan(children: parseText(state.message)),
                ],
              ),
            ),
            const SizedBox(
              height: 20,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: InkWell(
                    onTap: () {
                      Navigator.of(modalContext).pop();
                      modalContext.read<SupplierPageBlocBloc>().add(
                            SupplierPageOffersEvent(
                              locationId: state.currentLocation.locationId,
                            ),
                          );
                    },
                    child: Container(
                      alignment: Alignment.center,
                      padding: const EdgeInsets.all(10),
                      decoration: const BoxDecoration(
                        color: AppColors.uiBlack3,
                        borderRadius: BorderRadius.only(
                          bottomLeft: Radius.circular(8),
                        ),
                      ),
                      child: const Text(
                        'Cancel & refresh',
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ),
                Expanded(
                  child: InkWell(
                    onTap: () {
                      Navigator.of(modalContext).pop();
                      if (state.isActivate) {
                        modalContext.read<PopUpBloc>().add(
                              ConfirmOffersPopUpEvent(
                                '',
                                modalContext,
                                state.gradeGroupMap,
                                state.currentLocation,
                              ),
                            );
                      } else {
                        showDialog(
                          context: modalContext,
                          builder: (BuildContext alertContext) {
                            return DeactivatePopUp(
                              onCancel: () {
                                Navigator.of(alertContext).pop();
                                modalContext.read<SupplierPageBlocBloc>().add(
                                      SupplierPageOffersEvent(
                                        locationId:
                                            state.currentLocation.locationId,
                                      ),
                                    );
                              },
                              onDeactivate: () {
                                modalContext.read<SupplierPageBlocBloc>().add(
                                      DeactivateOffersEvent(
                                        location: state.currentLocation,
                                      ),
                                    );
                                Navigator.of(alertContext).pop();
                              },
                              currentLocationName: state.currentLocation.name,
                            );
                          },
                        );
                      }
                    },
                    child: Container(
                      alignment: Alignment.center,
                      padding: const EdgeInsets.all(10),
                      decoration: const BoxDecoration(
                        color: AppColors.primary100,
                        borderRadius: BorderRadius.only(
                          bottomRight: Radius.circular(8),
                        ),
                      ),
                      child: const Text(
                        'Yes, update again',
                        style: TextStyle(
                          color: AppColors.uiWhite100,
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
  return const Text('Incorrect State. Refresh your Page.');
}

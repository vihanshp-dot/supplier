import 'package:flutter/material.dart';

class AppIcon extends StatelessWidget {
  const AppIcon({super.key});
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(top: 100.0, bottom: 50.0),
      child: Column(
        children: [
          Image.asset(
            'assets/LOGO@4x.png',
            height: 65,
          ),
          const SizedBox(
            height: 5,
          ),
          const Text(
            'Seller App',
            style: TextStyle(fontWeight: FontWeight.w900),
          ),
        ],
      ),
    );
  }
}

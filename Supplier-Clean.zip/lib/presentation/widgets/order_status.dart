import 'package:flutter/material.dart';
import 'package:supplier/config/theme/app_colors.dart';

class OrderStatus extends StatelessWidget {
  const OrderStatus({super.key, required this.status, required this.val});

  final String status;
  final bool val;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        constraints: const BoxConstraints(maxWidth: 51.9),
        width: double.infinity,
        height: 56,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (val == true)
              const Padding(
                padding: EdgeInsets.only(left: 5),
                child: Icon(
                  Icons.check_circle_outline,
                  color: AppColors.primary100,
                  size: 20,
                ),
              )
            else
              const Padding(
                padding: EdgeInsets.only(left: 10),
                child: Text('-'),
              ),
            Text(
              status,
              style: const TextStyle(
                fontSize: 8,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

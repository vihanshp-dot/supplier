import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';
import 'package:supplier/config/theme/app_colors.dart';
import 'package:supplier/core/constants/app_constants.dart';
import 'package:supplier/core/utils/utils.dart';
import 'package:supplier/data/models/grade.dart';
import 'package:supplier/data/models/supplier_app_info.dart';
import 'package:supplier/presentation/bloc/supplier_page_bloc/supplier_page_bloc_bloc.dart';
import 'package:supplier/presentation/widgets/error_banner.dart';
import 'package:supplier/presentation/widgets/info_card.dart';

class GradeChip extends StatelessWidget {
  const GradeChip({
    super.key,
    required this.grade,
    required this.gradeGroupId,
    required this.lowerPriceBand,
    required this.upperPriceBand,
    required this.supplierAppInfo,
  });

  final Grade grade;
  final String gradeGroupId;
  final String lowerPriceBand;
  final String upperPriceBand;
  final SupplierAppInfo supplierAppInfo;

  @override
  Widget build(BuildContext context) {
    final double screenWidth = MediaQuery.of(context).size.width > 1200
        ? 1200
        : MediaQuery.of(context).size.width;
    final String? priceError =
        getErrorTextForGradePrice(grade.price, lowerPriceBand, upperPriceBand);

    final String? bulkQuantityError = getErrorTextForQuantity(
      grade.bulkQuantity,
      isBulk: true,
      bulkMinQuantity: supplierAppInfo.minimumBulkQuantity,
    );

    final String? bulkPriceError = getErrorTextForBulk(
      grade.price,
      grade.bulkPrice,
      lowerPriceBand,
      upperPriceBand,
    );

    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: screenWidth > maxPhoneWidth
          ? _buildWebGradeChip(
              context,
              screenWidth,
              priceError,
              bulkPriceError,
              bulkQuantityError,
            )
          : Container(
              margin: const EdgeInsets.symmetric(vertical: 2, horizontal: 4),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                color: AppColors.uiWhite100,
                boxShadow: const [
                  BoxShadow(
                    color: AppColors.uiBlack25,
                    blurRadius: 4.0,
                    offset: Offset(0, 2),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _buildMainSection(context),
                  if (grade.qtyRemarks != null)
                    _buildRemarksSectionForGrade(context, grade.qtyRemarks),
                  if (grade.gradeRemarks != null &&
                      grade.gradeRemarks!.trim().isNotEmpty)
                    InfoCard(
                      message: grade.gradeRemarks!,
                      gradeId: grade.gradeId,
                    ),
                  if (supplierAppInfo.isBulkOfferAllowed)
                    _buildBulkOfferSection(context),
                  if ((priceError != null && priceError.isNotEmpty) ||
                      (bulkPriceError != null && bulkPriceError.isNotEmpty) ||
                      (bulkQuantityError != null &&
                          bulkQuantityError.isNotEmpty))
                    ErrorBanner(
                      message: selectMessageForErrorDislay(
                        priceError ?? '',
                        bulkPriceError ?? '',
                        bulkQuantityError ?? '',
                      ),
                    ),
                ],
              ),
            ),
    );
  }

  Widget _buildMainSection(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: _buildGradeInfo(context),
          ),
          const SizedBox(width: 12),
          _buildPriceControls(context),
        ],
      ),
    );
  }

  Widget _buildGradeInfo(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(height: 10),
        Padding(
          padding: const EdgeInsets.only(left: 10),
          child: Text(
            grade.displayName,
            style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w600,
              color: Colors.black87,
              letterSpacing: 0.1,
            ),
          ),
        ),
        if (grade.qtyRemarks == null) ...[
          const SizedBox(height: 8),
          _buildAddRemarksButton(context),
        ],
      ],
    );
  }

  Widget _buildAddRemarksButton(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final fontSize = screenWidth > maxPhoneWidth ? 10.0 : 12.0;
    final iconSize = screenWidth > maxPhoneWidth ? 15.0 : 14.0;
    final spacing = screenWidth > maxPhoneWidth ? 5.0 : 4.0;

    return InkWell(
      onTap: () {
        FocusScope.of(context).unfocus();
        context.read<SupplierPageBlocBloc>().add(
              UpdateGradeOfListingEvent(
                gradeGroupId: gradeGroupId,
                gradeId: grade.gradeId,
                field: GradeField.remarks,
                value: '',
              ),
            );
      },
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const SizedBox(
            width: 10,
          ),
          Text(
            'Add Remarks',
            style: TextStyle(
              color: AppColors.primary100,
              fontSize: fontSize,
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(width: spacing),
          SvgPicture.asset(
            'assets/ICON_PEN.svg',
            height: iconSize,
            width: iconSize,
            colorFilter: const ColorFilter.mode(
              AppColors.primary100,
              BlendMode.srcIn,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPriceControls(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        SizedBox(
          width: 80,
          child: _buildPriceField(
            context,
            grade.price,
            getErrorTextForGradePrice(
              grade.price,
              lowerPriceBand,
              upperPriceBand,
            ),
          ),
        ),
        const SizedBox(width: 8),
        SizedBox(
          height: 35,
          child: _buildDeleteButton(context),
        ),
      ],
    );
  }

  Widget _buildPriceField(
    BuildContext context,
    String gradePrice,
    String? priceError,
  ) {
    final screenWidth = MediaQuery.of(context).size.width;
    final isWeb = screenWidth > maxPhoneWidth;
    final Widget formField = TextFormField(
      initialValue: gradePrice,
      onChanged: (value) {
        context.read<SupplierPageBlocBloc>().add(
              UpdateGradeOfListingEvent(
                gradeGroupId: gradeGroupId,
                gradeId: grade.gradeId,
                field: GradeField.price,
                value: value,
              ),
            );
      },
      decoration: InputDecoration(
        errorText: priceError != null ? null : null,
        errorMaxLines: 3,
        errorStyle: const TextStyle(
          color: AppColors.uiRed100,
          fontSize: 9,
          height: 0.8,
        ),
        isDense: true,
        labelStyle: const TextStyle(color: AppColors.uiBlack100, fontSize: 8),
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 12,
          vertical: 10,
        ),
        labelText: 'Price',
        hintText: 'Price in ₹',
        floatingLabelBehavior: FloatingLabelBehavior.always,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(
            color: priceError != null ? Colors.red : AppColors.uiBlack25,
          ),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(
            color: priceError != null ? Colors.red : AppColors.uiBlack25,
          ),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(
            color: priceError != null ? Colors.red : AppColors.primary100,
            width: 2,
          ),
        ),
      ),
      inputFormatters: <TextInputFormatter>[
        FilteringTextInputFormatter.allow(
          RegExp(r'^\d*\.?\d{0,2}'),
        ),
      ],
      keyboardType: const TextInputType.numberWithOptions(
        decimal: true,
        signed: true,
      ),
      style: const TextStyle(
        fontWeight: FontWeight.w600,
        fontSize: 12,
      ),
    );
    if (isWeb) {
      return ConstrainedBox(
        constraints: BoxConstraints(maxWidth: screenWidth * 2 / 5 * 0.3),
        child: formField,
      );
    }
    return SizedBox(
      height: 35,
      child: formField,
    );
  }

  Widget _buildDeleteButton(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        border: Border.all(color: AppColors.uiBlack25),
        borderRadius: BorderRadius.circular(8),
      ),
      child: IconButton(
        onPressed: () {
          FocusScope.of(context).unfocus();
          context.read<SupplierPageBlocBloc>().add(
                DeleteGradeFromListingEvent(
                  gradeGroupId: gradeGroupId,
                  gradeId: grade.gradeId,
                ),
              );
        },
        icon: SvgPicture.asset(
          'assets/ICON_DELETE.svg',
          height: 15,
          width: 20,
          colorFilter: const ColorFilter.mode(
            AppColors.uiRed100,
            BlendMode.srcIn,
          ),
        ),
        padding: const EdgeInsets.all(8),
        constraints: const BoxConstraints(),
      ),
    );
  }

  Widget _buildRemarksSectionForGrade(
    BuildContext context,
    String? initialValue,
  ) {
    final screenWidth = MediaQuery.of(context).size.width;
    final isWeb = screenWidth > maxPhoneWidth;

    final Widget formField = TextFormField(
      initialValue: initialValue ?? '',
      inputFormatters: [LengthLimitingTextInputFormatter(50)],
      onChanged: (value) {
        context.read<SupplierPageBlocBloc>().add(
              UpdateGradeOfListingEvent(
                gradeGroupId: gradeGroupId,
                gradeId: grade.gradeId,
                field: GradeField.remarks,
                value: value,
              ),
            );
      },
      decoration: InputDecoration(
        isDense: true,
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 12,
          vertical: 10,
        ),
        labelText: 'Remark',
        hintText: 'Add remark',
        hintStyle: const TextStyle(
          color: AppColors.uiBlack25,
          fontSize: 10,
          fontWeight: FontWeight.w600,
        ),
        floatingLabelBehavior: FloatingLabelBehavior.always,
        labelStyle: const TextStyle(color: AppColors.uiBlack100, fontSize: 8),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(color: AppColors.primary100),
        ),
      ),
      style: const TextStyle(
        fontWeight: FontWeight.w600,
        fontSize: 12,
      ),
    );

    if (isWeb) {
      return ConstrainedBox(
        constraints: BoxConstraints(maxWidth: screenWidth * 2 / 5 * 0.3),
        child: formField,
      );
    }

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
      child: formField,
    );
  }

  Widget _buildBulkOfferSection(BuildContext context) {
    if (grade.bulkPrice == null && grade.bulkQuantity == null) {
      return _buildAddBulkPriceButton(context);
    }
    return _buildBulkPriceFields(context);
  }

  Widget _buildAddBulkPriceButton(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final isWeb = screenWidth > maxPhoneWidth;

    void onTapHandler() {
      FocusScope.of(context).unfocus();
      context.read<SupplierPageBlocBloc>().add(
            AddBulkOfferToListingEvent(
              gradeGroupId: gradeGroupId,
              gradeId: grade.gradeId,
              defaultBulkQuantity: supplierAppInfo.defaultQuantity,
            ),
          );
    }

    final icon = Icon(
      Icons.add_circle_outline,
      color: AppColors.primary100,
      size: isWeb ? 24 : 14,
    );

    final text = Text(
      'Add bulk price',
      style: TextStyle(
        color: AppColors.primary100,
        fontWeight: isWeb ? FontWeight.normal : FontWeight.w600,
        fontSize: isWeb ? 10 : 12,
      ),
    );
    if (isWeb) {
      return InkWell(
        onTap: onTapHandler,
        child: Row(
          children: [
            icon,
            const SizedBox(width: 5),
            text,
          ],
        ),
      );
    }
    return Container(
      color: AppColors.primary15,
      height: 40,
      child: TextButton.icon(
        onPressed: onTapHandler,
        icon: icon,
        label: text,
      ),
    );
  }

  Widget _buildBulkPriceFields(BuildContext context) {
    return Container(
      color: AppColors.primary15,
      padding: const EdgeInsets.all(8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(width: 6),
          Expanded(
            child: _buildBulkQuantityField(context, grade.bulkQuantity),
          ),
          const SizedBox(width: 12),
          SizedBox(
            width: 75,
            height: 35,
            child: _buildBulkPriceField(context, grade.bulkPrice),
          ),
          const SizedBox(width: 10),
          SizedBox(height: 35, child: _buildBulkDeleteButton(context)),
        ],
      ),
    );
  }

  Widget _buildBulkQuantityField(BuildContext context, String? initialValue) {
    final screenWidth = MediaQuery.of(context).size.width;
    final isWeb = screenWidth > maxPhoneWidth;
    final String? errorTextForBulk = getErrorTextForQuantity(
      initialValue,
      isBulk: true,
      bulkMinQuantity: supplierAppInfo.minimumBulkQuantity,
    );

    final formField = TextFormField(
      initialValue: initialValue,
      onChanged: (value) {
        context.read<SupplierPageBlocBloc>().add(
              UpdateBulkOffersOfListingEvent(
                gradeGroupId: gradeGroupId,
                gradeId: grade.gradeId,
                field: GradeField.bulkQuantity,
                value: value,
              ),
            );
      },
      decoration: InputDecoration(
        labelStyle: const TextStyle(color: AppColors.uiBlack100, fontSize: 10),
        errorMaxLines: 2,
        errorStyle: const TextStyle(
          color: AppColors.uiRed100,
          fontSize: 8,
          height: 0.9,
        ),
        isDense: true,
        contentPadding: const EdgeInsets.symmetric(
          vertical: 10,
          horizontal: 12,
        ),
        labelText: 'Bulk Quantity',
        hintText: 'Quantity in MT',
        floatingLabelBehavior: FloatingLabelBehavior.always,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(
            color: errorTextForBulk != null
                ? AppColors.uiRed100 // Show red border on error
                : AppColors.uiBlack25,
          ),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(
            color: errorTextForBulk != null
                ? AppColors.uiRed100
                : AppColors.uiBlack25,
          ),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(
            color: errorTextForBulk != null
                ? AppColors.uiRed100
                : AppColors.primary100,
            width: 2,
          ),
        ),
      ),
      inputFormatters: <TextInputFormatter>[
        FilteringTextInputFormatter.allow(
          RegExp(r'^\d*\.?\d{0,2}'),
        ),
      ],
      keyboardType: const TextInputType.numberWithOptions(
        decimal: true,
        signed: true,
      ),
      style: const TextStyle(
        fontWeight: FontWeight.w600,
        fontSize: 12,
      ),
    );

    if (isWeb) {
      return Expanded(child: formField);
    }

    return SizedBox(
      height: 35,
      child: formField,
    );
  }

  Widget _buildBulkPriceField(BuildContext context, String? initialValue) {
    final screenWidth = MediaQuery.of(context).size.width;
    final bool isWeb = screenWidth > maxPhoneWidth;
    final String? errorTextForPrice = getErrorTextForBulk(
      grade.price,
      grade.bulkPrice,
      lowerPriceBand,
      upperPriceBand,
    );
    final formField = TextFormField(
      initialValue: initialValue,
      onChanged: (value) {
        context.read<SupplierPageBlocBloc>().add(
              UpdateBulkOffersOfListingEvent(
                gradeGroupId: gradeGroupId,
                gradeId: grade.gradeId,
                field: GradeField.bulkPrice,
                value: value,
              ),
            );
      },
      decoration: InputDecoration(
        labelStyle: const TextStyle(color: AppColors.uiBlack100, fontSize: 10),
        isDense: true,
        contentPadding: const EdgeInsets.symmetric(
          vertical: 10,
          horizontal: 12,
        ),
        labelText: 'Price',
        hintText: 'Price in ₹',
        hintStyle: const TextStyle(
          color: AppColors.uiBlack25,
          fontSize: 10,
          fontWeight: FontWeight.w600,
        ),
        errorMaxLines: 4,
        errorStyle: const TextStyle(
          color: AppColors.uiRed100,
          fontSize: 8,
          height: 1,
        ),
        floatingLabelBehavior: FloatingLabelBehavior.always,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(
            color: errorTextForPrice != null
                ? AppColors.uiRed100
                : AppColors.uiBlack25,
          ),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(
            color: errorTextForPrice != null ? Colors.red : AppColors.uiBlack25,
          ),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(
            color: errorTextForPrice != null
                ? AppColors.uiRed100
                : AppColors.primary100,
            width: 2,
          ),
        ),
      ),
      keyboardType: const TextInputType.numberWithOptions(
        decimal: true,
        signed: true,
      ),
      style: const TextStyle(
        fontWeight: FontWeight.w600,
        fontSize: 12,
      ),
      inputFormatters: <TextInputFormatter>[
        FilteringTextInputFormatter.allow(
          RegExp(r'^\d*\.?\d{0,2}'),
        ),
      ],
    );

    if (isWeb) {
      return Expanded(child: formField);
    }

    return formField;
  }

  Widget _buildBulkDeleteButton(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        border: Border.all(color: AppColors.uiBlack25),
        borderRadius: BorderRadius.circular(8),
      ),
      child: IconButton(
        onPressed: () {
          FocusScope.of(context).unfocus();
          context.read<SupplierPageBlocBloc>().add(
                DeleteBulkOfferOfListingEvent(
                  gradeGroupId: gradeGroupId,
                  gradeId: grade.gradeId,
                ),
              );
        },
        icon: SvgPicture.asset(
          'assets/ICON_DELETE.svg',
          height: 15,
          width: 20,
          colorFilter: const ColorFilter.mode(
            AppColors.uiRed100,
            BlendMode.srcIn,
          ),
        ),
        padding: const EdgeInsets.all(8),
        constraints: const BoxConstraints(),
      ),
    );
  }

  Widget _buildWebGradeChip(
    BuildContext context,
    double screenWidth,
    String? priceError,
    String? bulkPriceError,
    String? bulkQuantityError,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              decoration: BoxDecoration(
                color: AppColors.uiWhite100,
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(10),
                  bottomLeft: Radius.circular(10),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.3),
                    blurRadius: 2,
                  ),
                ],
              ),
              width: screenWidth * 2 / 3 - 12,
              padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 14),
              child: Row(
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        grade.displayName,
                        style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      if (grade.qtyRemarks == null)
                        _buildAddRemarksButton(context),
                      if (grade.qtyRemarks == null) const SizedBox(height: 5),
                      if (grade.gradeRemarks != null &&
                          grade.gradeRemarks!.trim().isNotEmpty)
                        ConstrainedBox(
                          constraints: BoxConstraints(
                            maxWidth: screenWidth > 900 ? 300 : 200,
                          ),
                          child: InfoCard(
                            message: grade.gradeRemarks!,
                            gradeId: grade.gradeId,
                            margin: EdgeInsets.zero,
                          ),
                        ),
                    ],
                  ),
                  const Spacer(),
                  Row(
                    children: [
                      if (grade.qtyRemarks != null)
                        _buildRemarksSectionForGrade(context, grade.qtyRemarks),
                      const SizedBox(width: 10),
                      _buildPriceField(
                        context,
                        grade.price,
                        getErrorTextForGradePrice(
                          grade.price,
                          lowerPriceBand,
                          upperPriceBand,
                        ),
                      ),
                      const SizedBox(width: 10),
                      _buildDeleteButton(context),
                    ],
                  ),
                ],
              ),
            ),
            if (supplierAppInfo.isBulkOfferAllowed)
              Container(
                padding:
                    const EdgeInsets.symmetric(vertical: 12, horizontal: 14),
                decoration: const BoxDecoration(
                  borderRadius: BorderRadius.only(
                    bottomRight: Radius.circular(10),
                    topRight: Radius.circular(10),
                  ),
                  color: AppColors.primary15,
                ),
                width: grade.bulkPrice == null && grade.bulkQuantity == null
                    ? 135
                    : screenWidth * 1 / 4 - 8,
                child: Row(
                  children: (grade.bulkPrice == null &&
                          grade.bulkQuantity == null)
                      ? [
                          _buildAddBulkPriceButton(context),
                        ]
                      : [
                          _buildBulkQuantityField(context, grade.bulkQuantity),
                          const SizedBox(
                            width: 10,
                          ),
                          _buildBulkPriceField(context, grade.bulkPrice),
                          const SizedBox(
                            width: 10,
                          ),
                          SizedBox(
                            height: 33,
                            child: _buildBulkDeleteButton(context),
                          ),
                        ],
                ),
              ),
          ],
        ),
        if ((priceError != null && priceError.isNotEmpty) ||
            (bulkPriceError != null && bulkPriceError.isNotEmpty) ||
            (bulkQuantityError != null && bulkQuantityError.isNotEmpty))
          SizedBox(
            width: screenWidth * 2 / 3 - 12,
            child: ErrorBanner(
              message: selectMessageForErrorDislay(
                priceError ?? '',
                bulkPriceError ?? '',
                bulkQuantityError ?? '',
              ),
            ),
          ),
      ],
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:supplier/config/theme/app_colors.dart';
import 'package:supplier/core/constants/app_constants.dart';
import 'package:supplier/core/utils/utils.dart';
import 'package:supplier/data/models/order.dart';
import 'package:supplier/presentation/widgets/order_card_middle_content.dart';
import 'package:supplier/presentation/widgets/order_status.dart';

class ConfirmedCardItem extends StatelessWidget {
  const ConfirmedCardItem({super.key, required this.order});

  final Order order;

  @override
  Widget build(BuildContext context) {
    final double screenWidth = MediaQuery.of(context).size.width;

    int stage;
    if (order.invoiceReceived != "") {
      stage = 5;
    } else if (order.vehicleLoaded != "") {
      stage = 4;
    } else if (order.vehicleReached != "") {
      stage = 3;
    } else if (order.vehicleConfirmed != "") {
      stage = 2;
    } else if (order.loadingAddressUpdates != "") {
      stage = 1;
    } else {
      stage = 0;
    }
    return Card(
      color: AppColors.uiWhite100,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 14),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    SvgPicture.asset(
                      'assets/box.svg',
                      height: 20.0,
                      width: 20.0,
                    ),
                    const SizedBox(
                      width: 5,
                    ),
                    Text(
                      order.orderNo,
                      style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
                Row(
                  children: [
                    const Text(
                      'Dispatch: ',
                      style: TextStyle(
                        color: AppColors.uiBlack50,
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    Text(
                      formatDate(order.dispatchDate),
                      style: const TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ],
            ),
            const Divider(
              color: AppColors.uiStroke10,
              thickness: 1,
            ),
            if (screenWidth > maxPhoneWidth)
              Flexible(
                child: SingleChildScrollView(
                  child: OrderCardMiddleContent(
                    order: order,
                  ),
                ),
              )
            else
              OrderCardMiddleContent(
                order: order,
              ),
            const Divider(
              color: AppColors.uiStroke10,
              thickness: 1,
            ),
            SizedBox(
              height: 56,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  OrderStatus(
                    status: stage == 0
                        ? loadingAddressPending
                        : loadingAddressUpdated,
                    val: order.loadingAddressUpdates != "",
                  ),
                  OrderStatus(
                    status: stage == 0
                        ? vehicleNotConfirmed
                        : stage == 1
                            ? confirmingVehicle
                            : vehicleConfirmed,
                    val: order.vehicleConfirmed != "",
                  ),
                  OrderStatus(
                    status: stage < 2
                        ? vehicleNotReached
                        : stage == 2
                            ? vehicleReaching
                            : vehicleReached,
                    val: order.vehicleReached != "",
                  ),
                  OrderStatus(
                    status: stage < 3
                        ? vehicleNotLoaded
                        : stage == 3
                            ? loadingVehicle
                            : vehicleLoaded,
                    val: order.vehicleLoaded != "",
                  ),
                  OrderStatus(
                    status: stage < 4
                        ? invoiceNotRecieved
                        : stage == 4
                            ? invoicePending
                            : invoiceReceived,
                    val: order.invoiceReceived != "",
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:supplier/config/theme/app_colors.dart';
import 'package:supplier/presentation/bloc/supplier_page_bloc/supplier_page_bloc_bloc.dart';

class InfoCard extends StatelessWidget {
  const InfoCard({
    required this.message,
    required this.gradeId,
    this.backgroundColor,
    this.iconColor,
    this.wordLimit = 10,
    this.margin = const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
    super.key,
  });

  final String message;
  final String gradeId;
  final Color? backgroundColor;
  final Color? iconColor;
  final int wordLimit;
  final EdgeInsetsGeometry margin;

  String _getTruncatedText(String text, int wordLimit) {
    final words = text.split(RegExp(r'\s+'));
    if (words.length <= wordLimit) {
      return text;
    }
    return words.take(wordLimit).join(' ');
  }

  @override
  Widget build(BuildContext context) {
    final shouldTruncate = message.split(RegExp(r'\s+')).length > wordLimit;

    return BlocBuilder<SupplierPageBlocBloc, SupplierPageBlocState>(
      builder: (context, state) {
        if (state is! SupplierPageOffersBlocState) {
          return const SizedBox.shrink();
        }
        final isExpanded = state.expandedInfoCards[gradeId] ?? false;
        final displayText = isExpanded || !shouldTruncate
            ? message
            : _getTruncatedText(message, wordLimit);

        return _buildCard(context, displayText, shouldTruncate, isExpanded);
      },
    );
  }

  Widget _buildCard(
    BuildContext context,
    String displayText,
    bool shouldTruncate,
    bool isExpanded,
  ) {
    return Container(
      margin: margin,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: backgroundColor ?? AppColors.uiOrange20,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(Icons.info, color: iconColor ?? AppColors.uiOrange100),
          const SizedBox(width: 12),
          Expanded(
            child: shouldTruncate
                ? Text.rich(
                    TextSpan(
                      children: [
                        TextSpan(
                          text: displayText,
                          style: const TextStyle(
                            fontSize: 12,
                          ),
                        ),
                        if (!isExpanded) ...[
                          const TextSpan(text: '... '),
                          WidgetSpan(
                            child: GestureDetector(
                              onTap: () {
                                context.read<SupplierPageBlocBloc>().add(
                                      ToggleInfoCardExpansionEvent(
                                        gradeId: gradeId,
                                      ),
                                    );
                              },
                              child: Text(
                                'Show more',
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                  color: iconColor ?? AppColors.uiOrange100,
                                ),
                              ),
                            ),
                          ),
                        ] else ...[
                          const TextSpan(text: ' '),
                          WidgetSpan(
                            child: GestureDetector(
                              onTap: () {
                                context.read<SupplierPageBlocBloc>().add(
                                      ToggleInfoCardExpansionEvent(
                                        gradeId: gradeId,
                                      ),
                                    );
                              },
                              child: Text(
                                'Show less',
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                  color: iconColor ?? AppColors.uiOrange100,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ],
                    ),
                  )
                : Text(
                    displayText,
                    style: const TextStyle(
                      fontSize: 12,
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}

part of 'auth_bloc.dart';

sealed class AuthState extends Equatable {
  const AuthState({this.appVersion, this.accountManager});
  final AppVersion? appVersion;
  final String? accountManager;

  @override
  List<Object?> get props => [appVersion];
}

class Authenticated extends AuthState {
  const Authenticated(
      {required super.appVersion, required super.accountManager,});
}

class UnAuthenticated extends AuthState {
  const UnAuthenticated();
}

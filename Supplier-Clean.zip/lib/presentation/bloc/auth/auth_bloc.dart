import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supplier/core/constants/constants.dart';
import 'package:supplier/data/models/app_version.dart';
import 'package:supplier/data/repositories/app_version_repository.dart';
import 'package:supplier/data/repositories/auth_repository.dart';

part 'auth_event.dart';
part 'auth_state.dart';

class AuthBloc extends Bloc<AuthEvent, AuthState> {
  AuthBloc(this._localStorage, this._appVersionRepository, this._authRepository)
      : super(const UnAuthenticated()) {
    on<AuthSubscriptionRequested>(_onAuthSubscriptionRequested);
    on<AuthLogoutRequested>(_onAuthLogoutRequested);
  }
  Future<void> _onAuthSubscriptionRequested(
    AuthSubscriptionRequested event,
    Emitter<AuthState> emit,
  ) async {
    final String? session = await _localStorage.getString(sessionId);
    final String? number = await _localStorage.getString(whatsappNumber);
    final String? accountManagerNumber =
        await _localStorage.getString(accountManager);
    if (session == null || number == null) {
      emit(const UnAuthenticated());
      return;
    }
    if (kIsWeb) {
      emit(
        Authenticated(
          appVersion: const AppVersion(
            isUpdateRequired: false,
            messageForUser: '',
            supplierAppLink: '',
          ),
          accountManager: accountManagerNumber,
        ),
      );
      return;
    }
    final AppVersion appVersion = await _appVersionRepository.checkAppVersion();
    emit(
      Authenticated(
        appVersion: appVersion,
        accountManager: accountManagerNumber,
      ),
    );
  }

  Future<void> _onAuthLogoutRequested(
    AuthLogoutRequested event,
    Emitter<AuthState> emit,
  ) async {
    final String? session = await _localStorage.getString(sessionId);
    final String? number = await _localStorage.getString(whatsappNumber);
    await _authRepository.logOut(number ?? '', session ?? '');
    await _localStorage.remove(referenceToken);
    await _localStorage.remove(whatsappNumber);
    await _localStorage.remove(sessionId);
    await _localStorage.remove(accountManager);
    emit(const UnAuthenticated());
  }

  final SharedPreferencesAsync _localStorage;
  final AppVersionRepository _appVersionRepository;
  final AuthRepository _authRepository;
}

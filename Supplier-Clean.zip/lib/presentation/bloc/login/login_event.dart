part of 'login_bloc.dart';

sealed class LoginEvent extends Equatable {
  const LoginEvent();

  @override
  List<Object> get props => [];
}

final class PhoneNumberChanged extends LoginEvent {
  final String phoneNumber;

  const PhoneNumberChanged(this.phoneNumber);

  @override
  List<Object> get props => [phoneNumber];
}

final class PhoneNumberSubmitted extends LoginEvent {
  const PhoneNumberSubmitted({required this.phoneNumber});
  final String phoneNumber;
}

final class OtpChanged extends LoginEvent {
  final String otp;

  const OtpChanged(this.otp);

  @override
  List<Object> get props => [otp];
}

final class VerifyOtp extends LoginEvent {
  final String otp;
  const VerifyOtp(this.otp);
}

class TimerTicked extends LoginEvent {
  final int duration;
  const TimerTicked(this.duration);

  @override
  List<Object> get props => [duration];
}

class TimerStarted extends LoginEvent {
  final int duration;
  const TimerStarted(this.duration);
}

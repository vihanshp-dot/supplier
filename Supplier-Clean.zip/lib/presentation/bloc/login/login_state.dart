part of 'login_bloc.dart';

sealed class LoginState extends Equatable {
  const LoginState();
  @override
  List<Object> get props => [];
}

class PhoneNumberInvalid extends LoginState {
  const PhoneNumberInvalid();
}

class PhoneNumberInitial extends LoginState {
  final int duration;
  const PhoneNumberInitial(this.duration);
}

class PhoneNumberValid extends LoginState {
  final String phoneNumber;

  const PhoneNumberValid(this.phoneNumber);

  @override
  List<Object> get props => [phoneNumber];
}

class OtpValid extends LoginState {
  final String accountManager;
  const OtpValid({required this.accountManager});
}

class OtpInvalid extends LoginState {
  const OtpInvalid();
}

class UserAppNotAllowed extends LoginState {
  final String message;
  final String buttonCTA;
  final String buttonText;
  final String phoneNumber;
  const UserAppNotAllowed(
    this.message,
    this.buttonCTA,
    this.buttonText,
    this.phoneNumber,
  );
}

class OtpCompleted extends LoginState {
  final String otp;
  const OtpCompleted(this.otp);
}

class OtpIncomplete extends LoginState {
  const OtpIncomplete();
}

class ReceivedReferenceToken extends LoginState {
  final ReferenceToken referenceToken;
  final String whatsappNumber;

  const ReceivedReferenceToken(this.referenceToken, this.whatsappNumber);
}

class DidNotReceiveReferenceToken extends LoginState {
  final ReferenceToken referenceToken;

  const DidNotReceiveReferenceToken(this.referenceToken);
}

class ApiRequestFailed extends LoginState {}

class PhoneNumberVerified extends LoginState {
  final String phoneNumber;
  final String referenceToken;

  const PhoneNumberVerified(
    this.phoneNumber,
    this.referenceToken,
  );

  @override
  List<Object> get props => [phoneNumber];
}

class UserDetailsReceived extends LoginState {
  final List<User> user;

  const UserDetailsReceived(this.user);
}

class TimerInitial extends LoginState {
  final int duration;
  const TimerInitial(this.duration);
}

class TimerRunInProgress extends LoginState {
  final int duration;
  const TimerRunInProgress(this.duration);
}

class TimerRunComplete extends LoginState {
  final int duration;
  const TimerRunComplete(this.duration);
}

class TimerHasTicked extends LoginState {
  final int duration;
  const TimerHasTicked(this.duration);
}

class DataLoadingState extends LoginState {}

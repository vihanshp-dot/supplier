import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supplier/core/constants/constants.dart';
import 'package:supplier/core/service/api_service.dart';
import 'package:supplier/core/service/log_service.dart';
import 'package:supplier/data/models/reference_toke.dart';
import 'package:supplier/data/models/ticker.dart';
import 'package:supplier/data/models/user.dart';
import 'package:supplier/data/repositories/auth_repository.dart';

part 'package:supplier/presentation/bloc/login/login_event.dart';
part 'package:supplier/presentation/bloc/login/login_state.dart';

class LoginBloc extends Bloc<LoginEvent, LoginState> {
  final Ticker _ticker;
  final AuthRepository _authRepository;
  final SharedPreferencesAsync _localStorage;

  StreamSubscription<int>? _tickerSubscription;

  LoginBloc(
    this._authRepository,
    this._ticker,
    this._localStorage,
  ) : super(const PhoneNumberInitial(resendOtpCountdownDuration)) {
    on<PhoneNumberChanged>(_onPhoneNumberChanged);
    on<PhoneNumberSubmitted>(_onPhoneNumberSubmitted);
    on<TimerStarted>(_onStarted);
    on<TimerTicked>(_onTicked);
    on<OtpChanged>(_onOtpChanged);
    on<VerifyOtp>(_onVerifyButton);
  }

  Future<void> _onPhoneNumberChanged(
    PhoneNumberChanged event,
    Emitter<LoginState> emit,
  ) async {
    if (event.phoneNumber.length == 10 &&
        RegExp(r'^\d{10}$').hasMatch(event.phoneNumber)) {
      emit(
        PhoneNumberValid(
          event.phoneNumber,
        ),
      );
    } else {
      emit(const PhoneNumberInvalid());
    }
  }

  Future<void> _onPhoneNumberSubmitted(
    PhoneNumberSubmitted event,
    Emitter<LoginState> emit,
  ) async {
    emit(DataLoadingState());
    try {
      final ReferenceToken data =
          await _authRepository.login(event.phoneNumber);
      await _localStorage.setString('whatsappNumber', event.phoneNumber);
      await _localStorage.setString(
        'referenceToken',
        data.referenceToken,
      );
      if (data.message == 'success') {
        emit(
          ReceivedReferenceToken(data, event.phoneNumber),
        );
      } else {
        emit(
          DidNotReceiveReferenceToken(
            data,
          ),
        );
      }
    } catch (e) {
      emit(ApiRequestFailed());
      LogService.logError(e);
    }
  }

  Future<void> _onOtpChanged(
    OtpChanged event,
    Emitter<LoginState> emit,
  ) async {
    if (event.otp.length == 4) {
      emit(
        OtpCompleted(
          event.otp,
        ),
      );
    } else {
      emit(const OtpIncomplete());
    }
  }

  Future<void> _onVerifyButton(
    VerifyOtp event,
    Emitter<LoginState> emit,
  ) async {
    emit(DataLoadingState());
    try {
      final String whatappNumber =
          await _localStorage.getString('whatsappNumber') ?? '';
      final String referenceToken =
          await _localStorage.getString('referenceToken') ?? '';

      final User user = await _authRepository.authOtp(
        whatappNumber,
        referenceToken,
        event.otp,
      );
      if (user.isPersonAppAllowed) {
        await _localStorage.setString('sessionId', user.sessionId);
        await _localStorage.setString(accountManager, user.accountManager);
        emit(OtpValid(accountManager: user.accountManager));
      } else if (user.message == authFailedMessage) {
        emit(const OtpInvalid());
      } else {
        emit(
          UserAppNotAllowed(
            user.message,
            user.buttonCTA,
            user.buttonText,
            user.whatsappNumber,
          ),
        );
      }
    } on APIException catch (e) {
      if (e.statusCode == 403) {
        emit(const OtpInvalid());
      }
    } catch (e) {
      emit(ApiRequestFailed());
    }
  }

  @override
  Future<void> close() {
    _tickerSubscription?.cancel();
    return super.close();
  }

  void _onStarted(TimerStarted event, Emitter<LoginState> emit) {
    _tickerSubscription?.cancel();

    emit(const TimerRunInProgress(resendOtpCountdownDuration));

    _tickerSubscription = _ticker
        .tick(ticks: resendOtpCountdownDuration)
        .listen((duration) => add(TimerTicked(duration)));
  }

  void _onTicked(TimerTicked event, Emitter<LoginState> emit) {
    emit(TimerHasTicked(event.duration));
    emit(
      event.duration > 0
          ? TimerRunInProgress(event.duration)
          : const TimerRunComplete(resendOtpCountdownDuration),
    );
  }
}

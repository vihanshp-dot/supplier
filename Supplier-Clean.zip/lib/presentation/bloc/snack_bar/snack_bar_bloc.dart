import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

part 'snack_bar_event.dart';
part 'snack_bar_state.dart';

class SnackBarBloc extends Bloc<SnackBarEvent, SnackBarState> {
  SnackBarBloc() : super(const SnackBarHide()) {
    on<SnackBarDisplayed>(_onSnackBarDisplayed);
    on<SnackBarDismissed>((_, Emitter<SnackBarState> emit) {
      emit(const SnackBarHide());
    });
  }

  void _onSnackBarDisplayed(
    SnackBarDisplayed event,
    Emitter<SnackBarState> emit,
  ) {
    emit(const SnackBarHide());
    emit(SnackBarShow(event.title, message: event.message, type: event.type));
  }
}

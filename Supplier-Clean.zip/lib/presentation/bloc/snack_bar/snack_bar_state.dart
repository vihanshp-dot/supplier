part of 'snack_bar_bloc.dart';

enum SnackType { info, error }

abstract class SnackBarState extends Equatable {
  const SnackBarState(this.title, {this.type, this.message});
  final String title;
  final String? message;
  final SnackType? type;

  @override
  List<Object?> get props => [title, message, type];
}

class SnackBarHide extends SnackBarState {
  const SnackBarHide() : super('');
}

class SnackBarShow extends SnackBarState {
  const SnackBarShow(super.title, {super.message, super.type = SnackType.info});
}

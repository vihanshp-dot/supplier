part of 'snack_bar_bloc.dart';

abstract class SnackBarEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

class SnackBarDisplayed extends SnackBarEvent {
  SnackBarDisplayed(this.title, {this.type = SnackType.info, this.message});
  final String title;
  final String? message;
  final SnackType? type;

  @override
  List<Object?> get props => <Object?>[title, message, type];
}

class SnackBarDismissed extends SnackBarEvent {}

part of 'bottom_navigation_bar_bloc.dart';

sealed class BottomNavigationBarState extends Equatable {
  const BottomNavigationBarState();

  @override
  List<Object> get props => [];
}

class InitialBottomNavigationBarState extends BottomNavigationBarState {
  final TabItem currentTab;
  const InitialBottomNavigationBarState(this.currentTab);
  @override
  List<Object> get props => [currentTab];
}

import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:supplier/core/constants/constants.dart';

part 'bottom_navigation_bar_event.dart';
part 'bottom_navigation_bar_state.dart';

class BottomNavigationBarBloc extends Bloc<BottomNavigationBarEvent, BottomNavigationBarState> {
  BottomNavigationBarBloc() : super(const  InitialBottomNavigationBarState(TabItem.offers)) {
    on<BottomNavigationBarChangeEvent>((event, emit) {
       emit(InitialBottomNavigationBarState(event.tab));
    });
  }
}

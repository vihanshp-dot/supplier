part of 'bottom_navigation_bar_bloc.dart';

sealed class BottomNavigationBarEvent extends Equatable {
  const BottomNavigationBarEvent();

  @override
  List<Object> get props => [];
}

class BottomNavigationBarChangeEvent extends BottomNavigationBarEvent {
  final TabItem tab;
  const BottomNavigationBarChangeEvent(this.tab);
  @override
  List<Object> get props => [tab];
}

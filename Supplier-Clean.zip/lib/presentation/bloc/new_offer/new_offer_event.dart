part of 'new_offer_bloc.dart';

sealed class NewOfferEvent extends Equatable {
  const NewOfferEvent();

  @override
  List<Object?> get props => [];
}

class IntializeNewOfferEvent extends NewOfferEvent {
  const IntializeNewOfferEvent();
}

class GetGradesListForDropDownEvent extends NewOfferEvent {
  const GetGradesListForDropDownEvent({required this.value});
  final String value;
  @override
  List<Object?> get props => [value];
}

class UpdateGradeEvent extends NewOfferEvent {
  const UpdateGradeEvent({required this.field, required this.value});

  final GradeField field;
  final String value;
  @override
  List<Object?> get props => [field, value];
}

class AddGradePriceEvent extends NewOfferEvent {
  const AddGradePriceEvent({required this.gradeId});

  final String gradeId;

  @override
  List<Object?> get props => [gradeId];
}

class AddNewGradeEvent extends NewOfferEvent {
  const AddNewGradeEvent({
    required this.grade,
    required this.gradeGroupId,
    required this.lowerPriceBand,
    required this.upperPriceBand,
    required this.gradeGroupName,
  });

  final Grade grade;
  final String lowerPriceBand;
  final String upperPriceBand;
  final String gradeGroupId;
  final String gradeGroupName;

  @override
  List<Object?> get props =>
      [grade, lowerPriceBand, upperPriceBand, gradeGroupId, gradeGroupName];
}

class UpdateBulkOffersEvent extends NewOfferEvent {
  const UpdateBulkOffersEvent({required this.gradeField, required this.value});
  final GradeField gradeField;
  final String value;

  @override
  List<Object?> get props => [gradeField, value];
}

class DeleteBulkOffersEvent extends NewOfferEvent {
  const DeleteBulkOffersEvent();
}

class AddBulkOffersEvent extends NewOfferEvent {
  final String defaultBulkQuantity;
  const AddBulkOffersEvent({required this.defaultBulkQuantity});
}

import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:supplier/core/constants/app_constants.dart';
import 'package:supplier/data/models/grade.dart';
import 'package:supplier/data/models/grade_drop_down_options.dart';
import 'package:supplier/data/repositories/new_offer_repository.dart';

part 'new_offer_event.dart';
part 'new_offer_state.dart';

class NewOfferBloc extends Bloc<NewOfferEvent, NewOfferState> {
  NewOfferBloc(this._newOfferRepository) : super(const NewOfferFormState()) {
    on<IntializeNewOfferEvent>((event, emit) {
      emit(const NewOfferFormState());
    });
    on<GetGradesListForDropDownEvent>((event, emit) async {
      if (state is NewOfferFormState) {
        final NewOfferFormState currState = state as NewOfferFormState;
        try {
          final String searchField = event.value;
          if (searchField.trim().length < 3) {
            emit(currState.copyWith(gradeOptions: []));
            return;
          }
          final List<GradeDropDownOption> gradeOptions =
              await _newOfferRepository.getGradeOptions(searchField);
          emit(currState.copyWith(gradeOptions: gradeOptions));
        } catch (error) {
          emit(currState.copyWith(gradeOptions: []));
        }
      }
    });
    on<UpdateGradeEvent>((event, emit) {
      if (state is NewOfferFormState) {
        final NewOfferFormState currState = state as NewOfferFormState;
        final GradeField field = event.field;
        final String value = event.value;
        final Grade? currGrade = currState.selectedGrade;
        if (currGrade != null) {
          emit(
            currState.copyWith(
              selectedGrade: Grade(
                gradeId: currGrade.gradeId,
                price: field == GradeField.price ? value : currGrade.price,
                displayName: currGrade.displayName,
                qtyRemarks:
                    field == GradeField.remarks ? value : currGrade.qtyRemarks,
                bulkPrice: currGrade.bulkPrice,
                bulkQuantity: currGrade.bulkQuantity,
                gradeRemarks: currGrade.gradeRemarks,
              ),
            ),
          );
          return;
        }
      }
    });

    on<AddNewGradeEvent>((event, emit) {
      if (state is NewOfferFormState) {
        final NewOfferFormState currState = state as NewOfferFormState;
        final Grade grade = event.grade;
        emit(
          currState.copyWith(
            selectedGrade: Grade(
              gradeId: grade.gradeId,
              price: '',
              displayName: grade.displayName,
              gradeRemarks: grade.gradeRemarks,
            ),
            gradeGroupId: event.gradeGroupId,
            lowerPriceBand: event.lowerPriceBand,
            upperPriceBand: event.upperPriceBand,
            gradeGroupName: event.gradeGroupName,
          ),
        );
      }
    });

    on<AddBulkOffersEvent>((event, emit) {
      if (state is NewOfferFormState) {
        final NewOfferFormState currState = state as NewOfferFormState;
        if (currState.selectedGrade != null) {
          emit(
            currState.copyWith(
              selectedGrade: Grade(
                gradeId: currState.selectedGrade!.gradeId,
                price: currState.selectedGrade!.price,
                displayName: currState.selectedGrade!.displayName,
                qtyRemarks: currState.selectedGrade!.qtyRemarks,
                bulkPrice: '',
                bulkQuantity: event.defaultBulkQuantity,
                gradeRemarks: currState.selectedGrade!.gradeRemarks,
              ),
            ),
          );
        }
      }
    });

    on<UpdateBulkOffersEvent>((event, emit) {
      if (state is NewOfferFormState) {
        final NewOfferFormState currState = state as NewOfferFormState;
        final GradeField field = event.gradeField;
        final String value = event.value;
        emit(
          currState.copyWith(
            selectedGrade: Grade(
              gradeId: currState.selectedGrade!.gradeId,
              price: currState.selectedGrade != null
                  ? currState.selectedGrade!.price
                  : '',
              displayName: currState.selectedGrade!.displayName,
              qtyRemarks: currState.selectedGrade?.qtyRemarks,
              bulkPrice: field == GradeField.bulkPrice
                  ? value
                  : currState.selectedGrade?.bulkPrice,
              bulkQuantity: field == GradeField.bulkQuantity
                  ? value
                  : currState.selectedGrade?.bulkQuantity,
              gradeRemarks: currState.selectedGrade?.gradeRemarks,
            ),
          ),
        );
      }
    });
    on<DeleteBulkOffersEvent>(
      (event, emit) {
        if (state is NewOfferFormState) {
          final NewOfferFormState currState = state as NewOfferFormState;
          if (currState.selectedGrade != null) {
            emit(
              currState.copyWith(
                selectedGrade: Grade(
                  gradeId: currState.selectedGrade!.gradeId,
                  price: currState.selectedGrade!.price,
                  displayName: currState.selectedGrade!.displayName,
                  qtyRemarks: currState.selectedGrade!.qtyRemarks,
                  gradeRemarks: currState.selectedGrade!.gradeRemarks,
                ),
              ),
            );
          }
        }
      },
    );
  }

  final NewOfferRepository _newOfferRepository;
  final FocusNode gradeDropdownFocusNode = FocusNode();

  @override
  Future<void> close() {
    gradeDropdownFocusNode.dispose();
    return super.close();
  }
}

part of 'new_offer_bloc.dart';

sealed class NewOfferState extends Equatable {
  const NewOfferState();

  @override
  List<Object?> get props => [];
}

class NewOfferFormState extends NewOfferState {
  @override
  List<Object?> get props => <Object?>[selectedGrade, gradeOptions];
  final Grade? selectedGrade;
  final List<GradeDropDownOption>? gradeOptions;
  final String? lowerPriceBand;
  final String? upperPriceBand;
  final String? gradeGroupId;
  final String? gradeGroupName;

  const NewOfferFormState(
      {this.selectedGrade,
      this.gradeOptions,
      this.lowerPriceBand,
      this.upperPriceBand,
      this.gradeGroupId,
      this.gradeGroupName,});
  NewOfferFormState copyWith(
      {Grade? selectedGrade,
      List<GradeDropDownOption>? gradeOptions,
      String? lowerPriceBand,
      String? upperPriceBand,
      String? gradeGroupId,
      String? gradeGroupName,}) {
    return NewOfferFormState(
        selectedGrade: selectedGrade ?? this.selectedGrade,
        gradeOptions: gradeOptions ?? this.gradeOptions,
        lowerPriceBand: lowerPriceBand ?? this.lowerPriceBand,
        upperPriceBand: upperPriceBand ?? this.upperPriceBand,
        gradeGroupId: gradeGroupId ?? this.gradeGroupId,
        gradeGroupName: gradeGroupName ?? this.gradeGroupName,);
  }
}

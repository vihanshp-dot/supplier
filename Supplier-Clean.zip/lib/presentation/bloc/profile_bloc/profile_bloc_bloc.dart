import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:supplier/data/models/profile.dart';
import 'package:supplier/data/repositories/profile_repository.dart';

part 'profile_bloc_event.dart';
part 'profile_bloc_state.dart';

class ProfileBloc extends Bloc<ProfileBlocEvent, ProfileBlocState> {
  ProfileBloc(this._profileRepository)
      : super(const ProfileScreenLoadingState()) {
    on<FetchUserDataEvent>(_fetchUserData);
  }

  Future<void> _fetchUserData(
    FetchUserDataEvent event,
    Emitter<ProfileBlocState> emit,
  ) async {
    try {
      emit(const ProfileScreenLoadingState());
      final List<Profile> userData = await _profileRepository.fetchUserData();
      emit(ProfileScreenUserDataLoadedState(userData: userData));
    } catch (err) {
      emit(ProfileScreenLoadedErrorState(errorMessage: err.toString()));
    }
  }

  final ProfileRepository _profileRepository;
}

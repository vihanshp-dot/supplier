part of 'profile_bloc_bloc.dart';

sealed class ProfileBlocState extends Equatable {
  const ProfileBlocState();

  @override
  List<Object?> get props => [];
}

class ProfileScreenLoadingState extends ProfileBlocState {
  const ProfileScreenLoadingState();
}

class ProfileScreenUserDataLoadedState extends ProfileBlocState {
  const ProfileScreenUserDataLoadedState({required this.userData});
  final List<Profile> userData;

  @override
  List<Object?> get props => [userData];
}

class ProfileScreenLoadedErrorState extends ProfileBlocState {
  final String errorMessage;
  const ProfileScreenLoadedErrorState({required this.errorMessage});

  @override
  List<Object?> get props => [];
}


// class LogOutState extends ProfileBlocState {
//   @override
//   List<Object?> get props => [];
// }

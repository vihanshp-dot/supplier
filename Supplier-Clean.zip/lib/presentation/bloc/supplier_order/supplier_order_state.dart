part of 'supplier_order_bloc.dart';

sealed class SupplierOrderState extends Equatable {
  @override
  List<Object?> get props => [filterVal, activeIndex];

  const SupplierOrderState({
    required this.filterVal,
    required this.activeIndex,
  });

  final String filterVal;
  final int activeIndex;
}

class OrderScreenLoadingDataState extends SupplierOrderState {
  const OrderScreenLoadingDataState({
    required super.activeIndex,
    required super.filterVal,
  });

  @override
  List<Object?> get props => [activeIndex];
}

class LoadedOrdersState extends SupplierOrderState {
  final List<Order> orders;
  const LoadedOrdersState({
    required super.activeIndex,
    required this.orders,
    required super.filterVal,
  });

  @override
  List<Object?> get props => [filterVal, activeIndex, orders];
}

class OrderScreenLoadedErrorState extends SupplierOrderState {
  final String errMessage;
  const OrderScreenLoadedErrorState({
    required this.errMessage,
    required super.activeIndex,
    super.filterVal = 'Last 30 days',
  });

  @override
  List<Object?> get props => [errMessage, activeIndex, filterVal];
}

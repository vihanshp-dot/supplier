import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:supplier/data/models/order.dart';
import 'package:supplier/data/repositories/order_repository.dart';

part 'supplier_order_event.dart';
part 'supplier_order_state.dart';

class SupplierOrderBloc extends Bloc<SupplierOrderEvent, SupplierOrderState> {
  SupplierOrderBloc(this._orderRepository)
      : super(
          const OrderScreenLoadingDataState(
            activeIndex: 0,
            filterVal: 'Last 30 days',
          ),
        ) {
    on<TabChangeEvent>(_onTabChange);
    on<FilterChangeEvent>(_onFilterChange);
  }

  Future<void> _onTabChange(
    TabChangeEvent event,
    Emitter<SupplierOrderState> emit,
  ) async {
    emit(
      OrderScreenLoadingDataState(
        activeIndex: event.activeIndex,
        filterVal: event.filterVal!,
      ),
    );
    if (event.activeIndex == 0) {
      try {
        final List<Order> confirmedOrders =
            await _orderRepository.fetchConfirmedOrders();
        emit(
          LoadedOrdersState(
            activeIndex: event.activeIndex,
            orders: confirmedOrders,
            filterVal: event.filterVal!,
          ),
        );
      } catch (error) {
        emit(
          OrderScreenLoadedErrorState(
            activeIndex: event.activeIndex,
            errMessage: error.toString(),
          ),
        );
      }
    } else {
      try {
        final List<Order> completedOrders =
            await _orderRepository.fetchCompletedOrders(event.filterVal!);
        emit(
          LoadedOrdersState(
            activeIndex: event.activeIndex,
            orders: completedOrders,
            filterVal: event.filterVal!,
          ),
        );
      } catch (error) {
        emit(
          OrderScreenLoadedErrorState(
            errMessage: error.toString(),
            activeIndex: event.activeIndex,
          ),
        );
      }
    }
  }

  Future<void> _onFilterChange(
    FilterChangeEvent event,
    Emitter<SupplierOrderState> emit,
  ) async {
    emit(
      OrderScreenLoadingDataState(
        activeIndex: 1,
        filterVal: event.filterVal!,
      ),
    );
    try {
      final List<Order> completedOrders =
          await _orderRepository.fetchCompletedOrders(event.filterVal!);
      emit(
        LoadedOrdersState(
          filterVal: event.filterVal!,
          activeIndex: event.activeIndex,
          orders: completedOrders,
        ),
      );
    } catch (error) {
      emit(
        OrderScreenLoadedErrorState(
          errMessage: error.toString(),
          activeIndex: 1,
        ),
      );
    }
  }

  final OrderRepository _orderRepository;
}

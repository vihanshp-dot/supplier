part of 'supplier_order_bloc.dart';

sealed class SupplierOrderEvent extends Equatable {
  final int activeIndex;
  final String? filterVal;
  const SupplierOrderEvent(
      {required this.activeIndex, required this.filterVal});

  @override
  List<Object?> get props => [activeIndex, filterVal];
}

class TabChangeEvent extends SupplierOrderEvent {
  const TabChangeEvent({required super.activeIndex, required super.filterVal});
}

class FilterChangeEvent extends SupplierOrderEvent {
  const FilterChangeEvent(
      {required super.filterVal, required super.activeIndex});
}

part of 'supplier_page_bloc_bloc.dart';

sealed class SupplierPageBlocEvent extends Equatable {
  const SupplierPageBlocEvent();

  @override
  List<Object?> get props => [];
}

// Base Grade Event for common parameters
class GradeEvent extends SupplierPageBlocEvent {
  const GradeEvent({this.gradeGroupId, this.gradeId, this.grade});

  final String? gradeGroupId;
  final String? gradeId;
  final Grade? grade;

  @override
  List<Object?> get props => [gradeGroupId, gradeId, grade];
}

// Specific Event Implementations
class SupplierPageOffersEvent extends SupplierPageBlocEvent {
  final String? locationId;
  const SupplierPageOffersEvent({this.locationId});
}

class AddGradeToListingEvent extends SupplierPageBlocEvent {
  const AddGradeToListingEvent({required this.gradegroup, required this.grade});
  final Gradegroup gradegroup;
  final Grade grade;
}

class DeleteGradeFromListingEvent extends GradeEvent {
  const DeleteGradeFromListingEvent({
    required String gradeGroupId,
    required String gradeId,
  }) : super(gradeGroupId: gradeGroupId, gradeId: gradeId);
}

class UpdateGradeOfListingEvent extends GradeEvent {
  const UpdateGradeOfListingEvent({
    required String gradeGroupId,
    required String gradeId,
    required this.field,
    required this.value,
  }) : super(gradeGroupId: gradeGroupId, gradeId: gradeId);
  final GradeField field;
  final String value;

  @override
  List<Object?> get props => [field, value, gradeGroupId, gradeId];
}

// Bulk Offer Events
class AddBulkOfferToListingEvent extends GradeEvent {
  final String defaultBulkQuantity;
  const AddBulkOfferToListingEvent({
    required String gradeGroupId,
    required String gradeId,
    required this.defaultBulkQuantity,
  }) : super(gradeGroupId: gradeGroupId, gradeId: gradeId);
}

class DeleteBulkOfferOfListingEvent extends GradeEvent {
  const DeleteBulkOfferOfListingEvent({
    required String gradeGroupId,
    required String gradeId,
  }) : super(gradeGroupId: gradeGroupId, gradeId: gradeId);
}

class UpdateBulkOffersOfListingEvent extends GradeEvent {
  const UpdateBulkOffersOfListingEvent({
    required String gradeGroupId,
    required String gradeId,
    required this.field,
    required this.value,
  }) : super(gradeGroupId: gradeGroupId, gradeId: gradeId);
  final GradeField field;
  final String value;

  @override
  List<Object?> get props => [field, value, gradeGroupId, gradeId];
}

class LocationChangeEvent extends SupplierPageBlocEvent {
  final Location location;
  const LocationChangeEvent({required this.location});

  @override
  List<Object?> get props => [location];
}

class ActivateOffersEvent extends SupplierPageBlocEvent {
  const ActivateOffersEvent({required this.gradeMap, required this.location});
  final Map<String, Gradegroup> gradeMap;
  final Location location;
  @override
  List<Object?> get props => [gradeMap, location];
}

class DeactivateOffersEvent extends SupplierPageBlocEvent {
  const DeactivateOffersEvent({required this.location});
  final Location location;
  @override
  List<Object?> get props => [location];
}

class CheckLastUpdateTimeEvent extends SupplierPageBlocEvent {
  const CheckLastUpdateTimeEvent({
    required this.location,
    required this.gradeMap,
    required this.lastUpdatedAt,
    required this.isActivate,
  });
  final Location location;
  final Map<String, Gradegroup> gradeMap;
  final int lastUpdatedAt;
  final bool isActivate;
  @override
  List<Object?> get props => [location, gradeMap, lastUpdatedAt, isActivate];
}

class ToggleInfoCardExpansionEvent extends SupplierPageBlocEvent {
  const ToggleInfoCardExpansionEvent({
    required this.gradeId,
  });
  final String gradeId;

  @override
  List<Object?> get props => [gradeId];
}

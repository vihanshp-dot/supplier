import 'dart:collection';

import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:supplier/core/constants/app_constants.dart';
import 'package:supplier/core/utils/utils.dart';
import 'package:supplier/data/models/analytics.dart';
import 'package:supplier/data/models/app_restriction.dart';
import 'package:supplier/data/models/grade.dart';
import 'package:supplier/data/models/grade_group.dart';
import 'package:supplier/data/models/location.dart';
import 'package:supplier/data/models/location_wise_gg_info.dart';
import 'package:supplier/data/models/supplier_app_info.dart';
import 'package:supplier/data/repositories/supplier_screen_repository.dart';

part 'supplier_page_bloc_event.dart';
part 'supplier_page_bloc_state.dart';

class SupplierPageBlocBloc
    extends Bloc<SupplierPageBlocEvent, SupplierPageBlocState> {
  SupplierPageBlocBloc(this._supplierScreenRepository)
      : super(SupplierPageLoading()) {
    on<SupplierPageOffersEvent>(_getSupplierOffers);
    on<AddGradeToListingEvent>(_addGrade);
    on<DeleteGradeFromListingEvent>(_deleteGrade);
    on<UpdateGradeOfListingEvent>(_updateGrade);
    on<AddBulkOfferToListingEvent>(_addBulkOffer);
    on<DeleteBulkOfferOfListingEvent>(_deleteBulkOffer);
    on<UpdateBulkOffersOfListingEvent>(_updateBulkOffer);
    on<LocationChangeEvent>(_updateLocation);
    on<ActivateOffersEvent>(_activateOffers);
    on<DeactivateOffersEvent>(_deactivateOffers);
    on<CheckLastUpdateTimeEvent>(_checkLastUpdatedTime);
    on<ToggleInfoCardExpansionEvent>(_toggleInfoCardExpansion);
  }

  Future<void> _getSupplierOffers(
    SupplierPageOffersEvent event,
    Emitter<SupplierPageBlocState> emit,
  ) async {
    emit(SupplierPageLoading());
    try {
      final AppRestriction isAppRestricted =
          await _supplierScreenRepository.getSupplierLogStatus();
      if (!isAppRestricted.isAppAccessRestricted) {
        final String locationId;
        final List<Location> locationsList =
            await _supplierScreenRepository.getSupplierLocations();
        if (event.locationId != null) {
          locationId = event.locationId!;
        } else {
          if (locationsList.isEmpty) {
            emit(
              const InvalidSupplierPersonState(
                errMessage: 'No location associated with supplier',
              ),
            );
            return;
          }
          locationId = locationsList[0].locationId;
        }
        final SupplierAppInfo supplierAppInfo =
            await _supplierScreenRepository.getSupplierAppInfo();
        final LocationWiseGGInfo locationWiseGGInfo =
            await _supplierScreenRepository.getLocationWiseListings(locationId);

        final Map<String, Gradegroup> gradeGroupMap = {};
        for (final gradegroup in locationWiseGGInfo.gradeGroups) {
          gradeGroupMap[gradegroup.gradeGroupId] = gradegroup;
        }
        notifySupplierAppEvent(
          {'locationId': locationId},
          EventType.USER_CHANGED_LOCATION,
        );
        emit(
          SupplierPageOffersBlocState(
            allLocations: locationsList,
            selectedLocation:
                locationsList.firstWhere((l) => l.locationId == locationId),
            gradeGroupMap: gradeGroupMap,
            supplierAppInfo: supplierAppInfo,
            isEdited: false,
            lastUpdatedAt: locationWiseGGInfo.lastUpdatedAt,
            message: locationWiseGGInfo.message,
          ),
        );
      } else {
        emit(InvalidSupplierPersonState(errMessage: isAppRestricted.remarks));
      }
    } catch (error) {
      emit(SupplierPageErrorState(errMessage: error.toString()));
    }
  }

  void _addGrade(
    AddGradeToListingEvent event,
    Emitter<SupplierPageBlocState> emit,
  ) {
    final String gradeGroupId = event.gradegroup.gradeGroupId;
    final Grade grade = event.grade;
    final currentState = state as SupplierPageOffersBlocState;
    final updatedGradeGroupMap =
        Map<String, Gradegroup>.from(currentState.gradeGroupMap);
    if (currentState.gradeGroupMap.containsKey(gradeGroupId)) {
      final List<Grade> list = updatedGradeGroupMap[gradeGroupId]!.grades;
      final newList = List<Grade>.from(list)..add(grade);
      updatedGradeGroupMap[gradeGroupId] = Gradegroup(
        gradeGroupId: gradeGroupId,
        gradeGroupName: event.gradegroup.gradeGroupName,
        lowerPriceBand: event.gradegroup.lowerPriceBand,
        upperPriceBand: event.gradegroup.upperPriceBand,
        grades: newList,
      );
    } else {
      updatedGradeGroupMap[gradeGroupId] = Gradegroup(
        gradeGroupId: gradeGroupId,
        gradeGroupName: event.gradegroup.gradeGroupName,
        lowerPriceBand: event.gradegroup.lowerPriceBand,
        upperPriceBand: event.gradegroup.upperPriceBand,
        grades: [grade],
      );
    }
    notifySupplierAppEvent(
      {
        "gradeGroupId": gradeGroupId,
        "gradeId": grade.gradeId,
        "displayName": grade.displayName,
      },
      EventType.USER_CHOSE_GRADE,
    );
    emit(
      currentState.copyWith(
        gradeGroupMap: updatedGradeGroupMap,
        isEdited: true,
      ),
    );
  }

  Grade _createUpdatedGrade(
    Grade grade, {
    String? price,
    String? qtyRemarks,
    String? bulkPrice,
    String? bulkQuantity,
  }) {
    return Grade(
      gradeId: grade.gradeId,
      price: price ?? grade.price,
      qtyRemarks: qtyRemarks ?? grade.qtyRemarks,
      displayName: grade.displayName,
      bulkPrice: bulkPrice ?? grade.bulkPrice,
      bulkQuantity: bulkQuantity ?? grade.bulkQuantity,
      gradeRemarks: grade.gradeRemarks,
    );
  }

  void _updateGradeGroupMap({
    required SupplierPageOffersBlocState currentState,
    required String gradeGroupId,
    required List<Grade> updatedGrades,
    required Emitter<SupplierPageBlocState> emit,
  }) {
    if (!currentState.gradeGroupMap.containsKey(gradeGroupId)) return;
    final updatedGradeGroupMap =
        Map<String, Gradegroup>.from(currentState.gradeGroupMap);
    final currentGradeGroup = currentState.gradeGroupMap[gradeGroupId]!;

    if (updatedGrades.isEmpty) {
      updatedGradeGroupMap.remove(gradeGroupId);
    } else {
      updatedGradeGroupMap[gradeGroupId] = Gradegroup(
        gradeGroupId: gradeGroupId,
        gradeGroupName: currentGradeGroup.gradeGroupName,
        lowerPriceBand: currentGradeGroup.lowerPriceBand,
        upperPriceBand: currentGradeGroup.upperPriceBand,
        grades: updatedGrades,
      );
    }

    emit(
      currentState.copyWith(
        gradeGroupMap: updatedGradeGroupMap,
        isEdited: true,
      ),
    );
  }

  void _deleteGrade(
    DeleteGradeFromListingEvent event,
    Emitter<SupplierPageBlocState> emit,
  ) {
    if (state is! SupplierPageOffersBlocState) return;

    final currentState = state as SupplierPageOffersBlocState;
    final gradeGroupId = event.gradeGroupId!;

    if (!currentState.gradeGroupMap.containsKey(gradeGroupId)) return;

    final updatedGrades =
        List<Grade>.from(currentState.gradeGroupMap[gradeGroupId]!.grades)
          ..removeWhere((grade) => grade.gradeId == event.gradeId);

    _updateGradeGroupMap(
      currentState: currentState,
      gradeGroupId: gradeGroupId,
      updatedGrades: updatedGrades,
      emit: emit,
    );
  }

  void _updateGrade(
    UpdateGradeOfListingEvent event,
    Emitter<SupplierPageBlocState> emit,
  ) {
    if (state is! SupplierPageOffersBlocState) return;

    final currentState = state as SupplierPageOffersBlocState;
    final gradeGroupId = event.gradeGroupId!;
    final gradeId = event.gradeId!;

    if (!currentState.gradeGroupMap.containsKey(gradeGroupId)) return;

    final grades =
        List<Grade>.from(currentState.gradeGroupMap[gradeGroupId]!.grades);
    final gradeIndex = grades.indexWhere((grade) => grade.gradeId == gradeId);

    if (gradeIndex == -1) return;

    grades[gradeIndex] = _createUpdatedGrade(
      grades[gradeIndex],
      price: event.field == GradeField.price ? event.value : null,
      qtyRemarks: event.field == GradeField.remarks ? event.value : null,
      bulkPrice: grades[gradeIndex].bulkPrice,
      bulkQuantity: grades[gradeIndex].bulkQuantity,
    );

    _updateGradeGroupMap(
      currentState: currentState,
      gradeGroupId: gradeGroupId,
      updatedGrades: grades,
      emit: emit,
    );
  }

  void _addBulkOffer(
    AddBulkOfferToListingEvent event,
    Emitter<SupplierPageBlocState> emit,
  ) {
    if (state is! SupplierPageOffersBlocState) return;

    final currentState = state as SupplierPageOffersBlocState;
    final gradeGroupId = event.gradeGroupId!;
    final gradeId = event.gradeId!;
    final defaultBulkQuantity = event.defaultBulkQuantity;

    _updateGradeWithBulkOffer(
      currentState: currentState,
      gradeGroupId: gradeGroupId,
      gradeId: gradeId,
      bulkPrice: '',
      bulkQuantity: defaultBulkQuantity,
      emit: emit,
    );
  }

  void _deleteBulkOffer(
    DeleteBulkOfferOfListingEvent event,
    Emitter<SupplierPageBlocState> emit,
  ) {
    if (state is! SupplierPageOffersBlocState) return;

    final currentState = state as SupplierPageOffersBlocState;
    final gradeGroupId = event.gradeGroupId!;
    final gradeId = event.gradeId!;
    final grades =
        List<Grade>.from(currentState.gradeGroupMap[gradeGroupId]!.grades);
    final gradeIndex = grades.indexWhere((grade) => grade.gradeId == gradeId);
    if (gradeIndex == -1) return;
    grades[gradeIndex] = Grade(
      gradeId: gradeId,
      price: grades[gradeIndex].price,
      displayName: grades[gradeIndex].displayName,
      qtyRemarks: grades[gradeIndex].qtyRemarks,
      gradeRemarks: grades[gradeIndex].gradeRemarks,
    );
    _updateGradeGroupMap(
      currentState: currentState,
      gradeGroupId: gradeGroupId,
      updatedGrades: grades,
      emit: emit,
    );
  }

  void _updateBulkOffer(
    UpdateBulkOffersOfListingEvent event,
    Emitter<SupplierPageBlocState> emit,
  ) {
    if (state is! SupplierPageOffersBlocState) return;

    final currentState = state as SupplierPageOffersBlocState;
    final gradeGroupId = event.gradeGroupId!;
    final gradeId = event.gradeId!;

    _updateGradeWithBulkOffer(
      currentState: currentState,
      gradeGroupId: gradeGroupId,
      gradeId: gradeId,
      bulkPrice: event.field == GradeField.bulkPrice ? event.value : null,
      bulkQuantity: event.field == GradeField.bulkQuantity ? event.value : null,
      emit: emit,
    );
  }

  void _updateGradeWithBulkOffer({
    required SupplierPageOffersBlocState currentState,
    required String gradeGroupId,
    required String gradeId,
    String? bulkPrice,
    String? bulkQuantity,
    required Emitter<SupplierPageBlocState> emit,
  }) {
    if (!currentState.gradeGroupMap.containsKey(gradeGroupId)) return;

    final grades =
        List<Grade>.from(currentState.gradeGroupMap[gradeGroupId]!.grades);
    final gradeIndex = grades.indexWhere((grade) => grade.gradeId == gradeId);

    if (gradeIndex == -1) return;

    grades[gradeIndex] = _createUpdatedGrade(
      grades[gradeIndex],
      bulkPrice: bulkPrice,
      bulkQuantity: bulkQuantity,
    );

    _updateGradeGroupMap(
      currentState: currentState,
      gradeGroupId: gradeGroupId,
      updatedGrades: grades,
      emit: emit,
    );
  }

  Future<void> _updateLocation(
    LocationChangeEvent event,
    Emitter<SupplierPageBlocState> emit,
  ) async {
    if (state is! SupplierPageOffersBlocState) return;

    final currentState = state as SupplierPageOffersBlocState;
    emit(SupplierPageLoading());
    final Location location = event.location;
    final LocationWiseGGInfo locationWiseGGInfo =
        await _supplierScreenRepository
            .getLocationWiseListings(location.locationId);
    notifySupplierAppEvent(
      {'locationId': location.locationId},
      EventType.USER_CHANGED_LOCATION,
    );
    final Map<String, Gradegroup> gradeGroupMap = HashMap();
    for (final gradegroup in locationWiseGGInfo.gradeGroups) {
      gradeGroupMap[gradegroup.gradeGroupId] = gradegroup;
    }
    emit(
      currentState.copyWith(
        selectedLocation: location,
        gradeGroupMap: gradeGroupMap,
        isEdited: false,
        message: locationWiseGGInfo.message,
        lastUpdatedAt: locationWiseGGInfo.lastUpdatedAt,
      ),
    );
  }

  Future<void> _activateOffers(
    ActivateOffersEvent event,
    Emitter<SupplierPageBlocState> emit,
  ) async {
    try {
      final String message = await _supplierScreenRepository.activateOffers(
        event.location.locationId,
        event.gradeMap.values.expand((group) => group.grades).toList(),
      );
      notifySupplierAppEvent({}, EventType.SUBMITTED_OFFERS);
      final currentState = state as SupplierPageOffersBlocState;
      if (event.gradeMap.isEmpty) {
        emit(
          NoOffersActivatedState(
            locationId: currentState.selectedLocation.locationId,
          ),
        );
      } else {
        emit(
          ActivateOffersSuccessState(
            locationId: currentState.selectedLocation.locationId,
            message: message,
          ),
        );
      }
    } catch (e) {
      emit(ActivateOffersFailureState(errMessage: e.toString()));
    }
  }

  Future<void> _deactivateOffers(
    DeactivateOffersEvent event,
    Emitter<SupplierPageBlocState> emit,
  ) async {
    try {
      final String message = await _supplierScreenRepository.deActivateOffers(
        event.location.locationId,
      );
      notifySupplierAppEvent({}, EventType.USER_TAPPED_DEACTIVATE_OFFERS);
      final currentState = state as SupplierPageOffersBlocState;
      emit(
        DeActivateOffersSuccessState(
          locationId: currentState.selectedLocation.locationId,
          message: message,
        ),
      );
    } catch (e) {
      emit(DeActivateOffersFailureState(errMessage: e.toString()));
    }
  }

  Future<void> _checkLastUpdatedTime(
    CheckLastUpdateTimeEvent event,
    Emitter<SupplierPageBlocState> emit,
  ) async {
    try {
      final String? message = await _supplierScreenRepository.checkRecentUpdate(
        event.location.locationId,
        event.lastUpdatedAt,
      );
      final currentState = state as SupplierPageOffersBlocState;
      emit(
        RecentlyUpdatedState(
          gradeMap: event.gradeMap,
          location: event.location,
          message: message,
          showPopUp: message != null,
          isActivate: event.isActivate,
        ),
      );
      emit(
        currentState.copyWith(
          selectedLocation: event.location,
          gradeGroupMap: event.gradeMap,
        ),
      );
    } catch (e) {
      emit(ActivateOffersFailureState(errMessage: e.toString()));
    }
  }

  void _toggleInfoCardExpansion(
    ToggleInfoCardExpansionEvent event,
    Emitter<SupplierPageBlocState> emit,
  ) {
    if (state is! SupplierPageOffersBlocState) return;

    final currentState = state as SupplierPageOffersBlocState;
    final currentExpanded =
        Map<String, bool>.from(currentState.expandedInfoCards);
    currentExpanded[event.gradeId] = !(currentExpanded[event.gradeId] ?? false);

    emit(
      currentState.copyWith(
        expandedInfoCards: currentExpanded,
      ),
    );
  }

  final SupplierScreenRepository _supplierScreenRepository;
}

part of 'supplier_page_bloc_bloc.dart';

sealed class SupplierPageBlocState extends Equatable {
  const SupplierPageBlocState();

  @override
  List<Object?> get props => [];
}

final class SupplierPageBlocInitial extends SupplierPageBlocState {}

final class SupplierPageLoading extends SupplierPageBlocState {}

final class SupplierPageOffersBlocState extends SupplierPageBlocState {
  final Map<String, Gradegroup> gradeGroupMap;
  final Location selectedLocation;
  final List<Location> allLocations;
  final SupplierAppInfo supplierAppInfo;
  final bool isEdited;
  final int lastUpdatedAt;
  final String message;
  final Map<String, bool> expandedInfoCards;

  const SupplierPageOffersBlocState({
    required this.gradeGroupMap,
    required this.selectedLocation,
    required this.allLocations,
    required this.supplierAppInfo,
    required this.isEdited,
    required this.lastUpdatedAt,
    required this.message,
    this.expandedInfoCards = const {},
  });

  @override
  List<Object?> get props => <Object?>[
        gradeGroupMap,
        selectedLocation,
        allLocations,
        supplierAppInfo,
        isEdited,
        lastUpdatedAt,
        message,
        expandedInfoCards,
      ];

  SupplierPageOffersBlocState copyWith({
    Map<String, Gradegroup>? gradeGroupMap,
    Location? selectedLocation,
    List<Location>? allLocations,
    SupplierAppInfo? supplierAppInfo,
    bool? isEdited,
    int? lastUpdatedAt,
    String? message,
    Map<String, bool>? expandedInfoCards,
  }) {
    return SupplierPageOffersBlocState(
      gradeGroupMap: gradeGroupMap ?? this.gradeGroupMap,
      selectedLocation: selectedLocation ?? this.selectedLocation,
      allLocations: allLocations ?? this.allLocations,
      supplierAppInfo: supplierAppInfo ?? this.supplierAppInfo,
      isEdited: isEdited ?? this.isEdited,
      lastUpdatedAt: lastUpdatedAt ?? this.lastUpdatedAt,
      message: message ?? this.message,
      expandedInfoCards: expandedInfoCards ?? this.expandedInfoCards,
    );
  }
}

final class SupplierPageErrorState extends SupplierPageBlocState {
  final String errMessage;
  const SupplierPageErrorState({required this.errMessage});
  @override
  List<Object?> get props => <Object?>[errMessage];
}

class ActivateOffersSuccessState extends SupplierPageBlocState {
  const ActivateOffersSuccessState({
    required this.locationId,
    required this.message,
  });
  final String locationId;
  final String message;
}

class ActivateOffersFailureState extends SupplierPageBlocState {
  const ActivateOffersFailureState({required this.errMessage});
  final String errMessage;
}

class DeActivateOffersSuccessState extends SupplierPageBlocState {
  const DeActivateOffersSuccessState({
    required this.locationId,
    required this.message,
  });
  final String locationId;
  final String message;
}

class DeActivateOffersFailureState extends SupplierPageBlocState {
  const DeActivateOffersFailureState({required this.errMessage});
  final String errMessage;
}

class InvalidSupplierPersonState extends SupplierPageBlocState {
  final String errMessage;
  const InvalidSupplierPersonState({required this.errMessage});
}

class NoOffersActivatedState extends SupplierPageBlocState {
  final String locationId;
  const NoOffersActivatedState({required this.locationId});
}

class RecentlyUpdatedState extends SupplierPageBlocState {
  final String? message;
  final Location location;
  final Map<String, Gradegroup> gradeMap;
  final bool showPopUp;
  final bool isActivate;

  const RecentlyUpdatedState({
    required this.gradeMap,
    required this.location,
    required this.message,
    required this.showPopUp,
    required this.isActivate,
  });
}

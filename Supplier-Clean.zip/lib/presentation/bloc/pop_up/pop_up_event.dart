part of 'pop_up_bloc.dart';

sealed class PopUpEvent extends Equatable {
  const PopUpEvent(this.label, this.context);
  final BuildContext context;
  final String label;
}

class DismissPopUpEvent extends PopUpEvent {
  const DismissPopUpEvent(BuildContext context) : super('', context);
  @override
  List<Object?> get props => <Object?>[];
}

class SelectLocationPopUpEvent extends PopUpEvent {
  const SelectLocationPopUpEvent(
    super.label,
    super.context,
    this.locationList,
    this.currentLocation,
  );
  final List<Location> locationList;
  final Location currentLocation;

  @override
  List<Object?> get props => <Object?>[locationList, currentLocation];
}

class ConfirmOffersPopUpEvent extends PopUpEvent {
  const ConfirmOffersPopUpEvent(
    super.label,
    super.context,
    this.gradeGroupMap,
    this.currentLocation,
  );

  final Map<String, Gradegroup> gradeGroupMap;
  final Location currentLocation;

  @override
  List<Object?> get props =>
      <Object?>[gradeGroupMap, label, context, currentLocation];
}

class ConfirmUpdateAgainPopUpEvent extends PopUpEvent {
  const ConfirmUpdateAgainPopUpEvent(
    super.label,
    super.context,
    this.gradeGroupMap,
    this.currentLocation,
    this.message,
    this.isActivate,
  );

  final Map<String, Gradegroup> gradeGroupMap;
  final Location currentLocation;
  final String message;
  final bool isActivate;

  @override
  List<Object?> get props =>
      <Object?>[gradeGroupMap, label, context, currentLocation, isActivate];
}

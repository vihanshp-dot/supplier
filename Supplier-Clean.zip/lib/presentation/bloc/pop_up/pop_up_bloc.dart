import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:supplier/data/models/grade_group.dart';
import 'package:supplier/data/models/location.dart';

part 'pop_up_event.dart';
part 'pop_up_state.dart';

class PopUpBloc extends Bloc<PopUpEvent, PopUpState> {
  PopUpBloc() : super(const PopUpStateInitial()) {
    on<DismissPopUpEvent>((DismissPopUpEvent event, Emitter<PopUpState> emit) {
      emit(const PopUpStateInitial());
    });

    on<SelectLocationPopUpEvent>(
        (SelectLocationPopUpEvent event, Emitter<PopUpState> emit) {
      emit(
        SelectLocationScreenState(
          event.label,
          event.context,
          event.locationList,
          event.currentLocation,
        ),
      );
    });
    on<ConfirmOffersPopUpEvent>(
      (ConfirmOffersPopUpEvent event, Emitter<PopUpState> emit) {
        emit(
          ConfirmOffersPopUpState(
            event.label,
            event.context,
            event.gradeGroupMap,
            event.currentLocation,
          ),
        );
      },
    );
    on<ConfirmUpdateAgainPopUpEvent>(
        (ConfirmUpdateAgainPopUpEvent event, Emitter<PopUpState> emit) {
      emit(
        ConfirmUpdateAgainPopUpState(
          event.label,
          event.context,
          event.gradeGroupMap,
          event.currentLocation,
          event.message,
          event.isActivate,
        ),
      );
    });
  }
}

part of 'pop_up_bloc.dart';

sealed class PopUpState extends Equatable {
  const PopUpState(this.label, [this.context]);

  final BuildContext? context;
  final String label;

  @override
  List<Object?> get props => <Object?>[context, label];
}

final class PopUpStateInitial extends PopUpState {
  const PopUpStateInitial() : super('');
}

final class SelectLocationScreenState extends PopUpState {
  final List<Location> locations;
  final Location currentLocation;
  const SelectLocationScreenState(
    super.label,
    super.context,
    this.locations,
    this.currentLocation,
  );
}

final class ConfirmOffersPopUpState extends PopUpState {
  const ConfirmOffersPopUpState(
    super.label,
    super.context,
    this.gradeGroupMap,
    this.currentLocation,
  );

  final Map<String, Gradegroup> gradeGroupMap;
  final Location currentLocation;

  @override
  List<Object?> get props =>
      <Object?>[gradeGroupMap, label, context, currentLocation];
}

final class ConfirmUpdateAgainPopUpState extends PopUpState {
  const ConfirmUpdateAgainPopUpState(
    super.label,
    super.context,
    this.gradeGroupMap,
    this.currentLocation,
    this.message,
    this.isActivate,
  );

  final Map<String, Gradegroup> gradeGroupMap;
  final Location currentLocation;
  final String message;
  final bool isActivate;

  @override
  List<Object?> get props => <Object?>[
        gradeGroupMap,
        label,
        context,
        currentLocation,
        isActivate,
        message
      ];
}

import 'package:flutter/material.dart';
import 'package:supplier/presentation/pages/supplier_offers_screen.dart';

class SupplierScreen extends StatelessWidget {
  const SupplierScreen({super.key});
  @override
  
  Widget build(BuildContext context) {
    return OfferScreen();
  }
}

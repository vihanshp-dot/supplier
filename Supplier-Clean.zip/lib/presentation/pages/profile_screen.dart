import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:supplier/injection_container.dart';

import 'package:supplier/presentation/bloc/profile_bloc/profile_bloc_bloc.dart';
import 'package:supplier/presentation/pages/profile_screen_widget.dart';

class ProfileScreen extends StatelessWidget {
  final String accountManager;
  const ProfileScreen({super.key, required this.accountManager});

  @override
  Widget build(BuildContext context) {
    return BlocProvider<ProfileBloc>(
      create: (_) => locator<ProfileBloc>()
        ..add(
          const FetchUserDataEvent(),
        ),
      child: ProfileScreenWidget(accountManager: accountManager),
    );
  }
}

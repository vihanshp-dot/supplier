import 'package:flutter/material.dart';
import 'package:supplier/config/theme/app_colors.dart';
import 'package:supplier/core/constants/app_constants.dart';
import 'package:supplier/presentation/pages/login_screen.dart';
import 'package:supplier/presentation/widgets/background_pattern.dart';
import 'package:supplier/presentation/widgets/bottom_text.dart';
import 'package:supplier/presentation/widgets/opt_form.dart';

class OtpScreen extends StatelessWidget {
  final String whatsappNumber;
  const OtpScreen({super.key, required this.whatsappNumber});

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        if (constraints.maxWidth < 750) {
          return _otpScreen(context);
        } else {
          return _otpScreenWeb(context);
        }
      },
    );
  }

  Widget _otpScreen(BuildContext context) {
    return Scaffold(
      key: const Key('otpScreen'),
      backgroundColor: AppColors.uiBackground,
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(30.0),
          child: Stack(
            children: [
              Transform.translate(
                offset: const Offset(50, 450),
                child: const BackgroundPattern(),
              ),
              Column(
                children: [
                  Container(
                    margin: const EdgeInsets.only(top: 100.0, bottom: 50.0),
                    child: Column(
                      children: [
                        Image.asset(
                          'assets/LOGO@4x.png',
                          height: 65,
                        ),
                        const SizedBox(
                          height: 5,
                        ),
                        const Text(
                          'Seller App',
                          style: TextStyle(fontWeight: FontWeight.w900),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    key: const Key('otpContainer'),
                    constraints: const BoxConstraints(maxWidth: 450),
                    child: Column(
                      children: [
                        _infoText(context),
                        OtpForm(
                          whatsappNumber: whatsappNumber,
                        ),
                      ],
                    ),
                  ),
                  BottomText(),
                  const SizedBox(
                    height: 24,
                  ),
                ],
              ),
            ],
          ),
        ),
        // ),
      ),
    );
  }

  Widget _otpScreenWeb(BuildContext context) {
    return Scaffold(
      key: const Key('otpScreenWeb'),
      backgroundColor: AppColors.uiBackground,
      body: SingleChildScrollView(
        child: Stack(
          children: [
            Transform.translate(
              offset: const Offset(-300, -50),
              child: Transform.rotate(
                angle: 3.14159,
                child: const BackgroundPattern(),
              ),
            ),
            Transform.translate(
              offset: const Offset(300, 350),
              child: const BackgroundPattern(),
            ),
            Center(
              child: Padding(
                padding: const EdgeInsets.all(30.0),
                child: Column(
                  children: [
                    Container(
                      margin: const EdgeInsets.only(top: 100.0, bottom: 50.0),
                      child: Column(
                        children: [
                          Image.asset(
                            'assets/LOGO@4x.png',
                            height: 65,
                          ),
                          const SizedBox(
                            height: 5,
                          ),
                          const Text(
                            'Seller App',
                            style: TextStyle(fontWeight: FontWeight.w900),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      key: const Key('otpContainerWeb'),
                      constraints: const BoxConstraints(maxWidth: 500),
                      decoration: BoxDecoration(
                        color: AppColors.uiBlack3,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: AppColors.uiBlack25),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(0.5),
                            blurRadius: 15,
                            offset: const Offset(5, 5),
                          ),
                        ],
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(30.0),
                        child: Column(
                          children: [
                            _infoText(context),
                            OtpForm(
                              whatsappNumber: whatsappNumber,
                            ),
                          ],
                        ),
                      ),
                    ),
                    ConstrainedBox(
                      constraints: const BoxConstraints(maxHeight: 200),
                      child: Align(
                        alignment: Alignment.bottomCenter,
                        child: Container(
                          constraints: const BoxConstraints(maxWidth: 500),
                          decoration: BoxDecoration(
                            color: const Color.fromARGB(125, 235, 235, 235),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: AppColors.uiStroke10),
                            boxShadow: const [
                              BoxShadow(
                                color: Color.fromARGB(255, 233, 230, 230),
                                blurRadius: 5,
                                offset: Offset(5, 5),
                              ),
                            ],
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(10.0),
                            child: RichText(
                              text: const TextSpan(
                                children: [
                                  TextSpan(
                                    text:
                                        'If you are unable to login, call your Account Manager or Call on ',
                                    style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 17,
                                    ),
                                  ),
                                  TextSpan(
                                    text: loginIssuePhoneNumber,
                                    style: TextStyle(
                                      color: AppColors.primary100,
                                      fontSize: 17,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 24,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _infoText(BuildContext context) {
    return Column(
      children: [
        const Align(
          alignment: Alignment.centerLeft,
          child: Text(
            'Please enter OTP',
            textAlign: TextAlign.left,
            style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900),
          ),
        ),
        Align(
          alignment: Alignment.centerLeft,
          child: Column(
            children: [
              const SizedBox(
                height: 10,
              ),
              _phoneNumberDisplay(context, whatsappNumber),
            ],
          ),
        ),
      ],
    );
  }

  Widget _phoneNumberDisplay(BuildContext context, String phoneNumber) {
    return RichText(
      text: TextSpan(
        children: [
          const TextSpan(
            text: "We've sent an OTP to ",
            style: TextStyle(
              color: Colors.black,
              fontSize: 15,
              fontWeight: FontWeight.w500,
            ),
          ),
          TextSpan(
            text: "$phoneNumber ",
            style: const TextStyle(
              color: Colors.black,
              fontSize: 15,
              fontWeight: FontWeight.w900,
            ),
          ),
          WidgetSpan(
            alignment: PlaceholderAlignment.baseline,
            baseline: TextBaseline.alphabetic,
            child: GestureDetector(
              child: const Text(
                'Edit',
                style: TextStyle(
                  color: AppColors.primary100,
                  fontSize: 15,
                  fontWeight: FontWeight.w900,
                ),
              ),
              onTap: () {
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const SupplierAppLogin(),
                  ),
                  (Route<dynamic> route) => false,
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

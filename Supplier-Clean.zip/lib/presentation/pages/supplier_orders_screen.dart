import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:supplier/config/theme/app_colors.dart';
import 'package:supplier/injection_container.dart';
import 'package:supplier/presentation/bloc/supplier_order/supplier_order_bloc.dart';
import 'package:supplier/presentation/pages/supplier_orders_widget.dart';

class SupplierOrdersScreen extends StatelessWidget {
  final String accountManager;
  const SupplierOrdersScreen({super.key, required this.accountManager});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      height: double.infinity,
      alignment: Alignment.center,
      color: AppColors.uiBackground,
      child: BlocProvider(
        create: (_) => locator<SupplierOrderBloc>()
          ..add(
            const TabChangeEvent(
              activeIndex: 0,
              filterVal: 'Last 30 days',
            ),
          ),
        child: SupplierOrdersWidget(accountManager: accountManager),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:supplier/config/theme/app_colors.dart';
import 'package:supplier/data/models/order.dart';
import 'package:supplier/presentation/bloc/supplier_order/supplier_order_bloc.dart';
import 'package:supplier/presentation/widgets/app_bar.dart';
import 'package:supplier/presentation/widgets/no_order.dart';
import 'package:supplier/presentation/widgets/no_wifi.dart';
import 'package:supplier/presentation/widgets/order_filter.dart';
import 'package:supplier/presentation/widgets/order_list.dart';
import 'package:supplier/presentation/widgets/tab_container.dart';

class SupplierOrdersWidget extends StatelessWidget {
  final String accountManager;
  const SupplierOrdersWidget({super.key, required this.accountManager});

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;

    void setFilterValue(String val) {
      context.read<SupplierOrderBloc>().add(
            FilterChangeEvent(filterVal: val, activeIndex: 1),
          );
    }

    void onTabChange(int activeIndex, String filterVal) {
      context.read<SupplierOrderBloc>().add(
            TabChangeEvent(
              activeIndex: activeIndex,
              filterVal: filterVal,
            ),
          );
    }

    return Scaffold(
      backgroundColor:
          Colors.grey[50], // Lighter background to match screenshot
      appBar: AppBarWidget(accountManager: accountManager),
      body: Center(
        // Center the content
        child: Container(
          constraints: const BoxConstraints(maxWidth: 1200),
          child: BlocBuilder<SupplierOrderBloc, SupplierOrderState>(
            builder: (context, state) {
              final String filterVal = state.filterVal;
              final int activeIndex = state.activeIndex;

              if (state is OrderScreenLoadedErrorState) {
                return const NoWifi();
              }

              final List<Order> orders =
                  state is LoadedOrdersState ? state.orders : [];

              return Column(
                children: [
                  Container(
                    color: Colors.white,
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Row(
                      mainAxisAlignment: screenWidth < 600
                          ? MainAxisAlignment.center
                          : MainAxisAlignment.start,
                      children: [
                        // In Transit Tab
                        TabContainer(
                          activeIndex: 0,
                          currentActiveIndex: activeIndex,
                          filterVal: filterVal,
                          onTabChange: onTabChange,
                          label: 'In Transit',
                        ),
                        // Delivered Tab
                        TabContainer(
                          activeIndex: 1,
                          currentActiveIndex: activeIndex,
                          filterVal: filterVal,
                          onTabChange: onTabChange,
                          label: 'Delivered',
                        ),
                        // Filter (only shown on desktop for delivered tab)
                        if (screenWidth > 640 && activeIndex == 1)
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.symmetric(
                                vertical: 16,
                                horizontal: 16,
                              ),
                              child: Row(
                                children: [
                                  const Spacer(),
                                  OrderFilter(
                                    setFiltervalue: setFilterValue,
                                    filterVal: filterVal,
                                  ),
                                ],
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: Container(
                      color: Colors.grey[50],
                      child: SingleChildScrollView(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 8,
                        ),
                        child: Column(
                          children: [
                            // Mobile filter for delivered tab
                            if (screenWidth < 600 && activeIndex == 1)
                              Padding(
                                padding:
                                    const EdgeInsets.symmetric(vertical: 16),
                                child: Row(
                                  children: [
                                    const Spacer(),
                                    OrderFilter(
                                      setFiltervalue: setFilterValue,
                                      filterVal: filterVal,
                                    ),
                                  ],
                                ),
                              ),

                            // Loading indicator
                            if (state is OrderScreenLoadingDataState)
                              const Center(
                                child: CircularProgressIndicator(
                                  color: AppColors.primary100,
                                ),
                              )
                            // No orders message
                            else if (orders.isEmpty)
                              const NoOrder()
                            // Order list
                            else
                              OrderCardList(
                                orders: orders,
                              ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }
}

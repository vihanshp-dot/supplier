import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:supplier/config/theme/app_colors.dart';
import 'package:supplier/core/constants/constants.dart';
import 'package:supplier/core/utils/utils.dart';
import 'package:supplier/injection_container.dart';
import 'package:supplier/presentation/bloc/bottom_navigation_bar/bottom_navigation_bar_bloc.dart';

import 'package:supplier/presentation/bloc/supplier_page_bloc/supplier_page_bloc_bloc.dart';
import 'package:supplier/presentation/pages/profile_screen.dart';
import 'package:supplier/presentation/pages/supplier_orders_screen.dart';
import 'package:supplier/presentation/pages/supplier_screen.dart';

class HomeScreen extends StatelessWidget {
  final String accountManager;
  const HomeScreen({required this.accountManager});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) =>
          locator<SupplierPageBlocBloc>()..add(const SupplierPageOffersEvent()),
      child: Scaffold(
        body: BlocBuilder<BottomNavigationBarBloc, BottomNavigationBarState>(
          builder: (context, state) {
            if (state is InitialBottomNavigationBarState) {
              if (state.currentTab.index == 0) {
                return const SupplierScreen();
              } else if (state.currentTab.index == 1) {
                return SupplierOrdersScreen(accountManager: accountManager);
              }
              return ProfileScreen(accountManager: accountManager);
            }

            return const CircularProgressIndicator();
          },
        ),
        bottomNavigationBar:
            BlocBuilder<BottomNavigationBarBloc, BottomNavigationBarState>(
          builder: (context, state) {
            if (state is InitialBottomNavigationBarState) {
              return BottomNavigationBar(
                backgroundColor: Colors.white,
                currentIndex: state.currentTab.index,
                selectedItemColor: AppColors.primary100,
                onTap: (index) {
                  final selectedTab = TabItem.values[index];
                  final int previousIndex = state.currentTab.index;
                  if (previousIndex == 0) {
                    final supplierBloc = context.read<SupplierPageBlocBloc>();
                    final currState = supplierBloc.state;
                    if (currState is SupplierPageOffersBlocState) {
                      if (checkValidityOfOffers(
                            currState.gradeGroupMap,
                            currState.supplierAppInfo.minimumBulkQuantity,
                          ) &&
                          currState.isEdited) {
                        showDialog(
                          context: context,
                          builder: (BuildContext alertContext) {
                            return AlertDialog(
                              title: const Text('Confirm'),
                              content: const Text(
                                'You have unsaved offers. Do you wish to proceed?',
                              ),
                              actions: <Widget>[
                                TextButton(
                                  onPressed: () {
                                    Navigator.of(alertContext).pop();
                                    context.read<BottomNavigationBarBloc>().add(
                                          BottomNavigationBarChangeEvent(
                                            selectedTab,
                                          ),
                                        );
                                    onTabChangeAppEvent(index);
                                  },
                                  style: ButtonStyle(
                                    backgroundColor: WidgetStateProperty.all(
                                      AppColors.uiRed100,
                                    ),
                                    foregroundColor: WidgetStateProperty.all(
                                      AppColors.uiWhite100,
                                    ),
                                  ),
                                  child: Container(
                                    margin: const EdgeInsets.symmetric(
                                      horizontal: 5,
                                    ),
                                    child: const Text(
                                      'Discard Changes',
                                      style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                ),
                                TextButton(
                                  onPressed: () {
                                    Navigator.of(alertContext).pop();
                                  },
                                  style: ButtonStyle(
                                    backgroundColor: WidgetStateProperty.all(
                                      AppColors.primary100,
                                    ),
                                    foregroundColor: WidgetStateProperty.all(
                                      AppColors.uiWhite100,
                                    ),
                                  ),
                                  child: Container(
                                    margin: const EdgeInsets.symmetric(
                                      horizontal: 5,
                                    ),
                                    child: const Text(
                                      'Yes',
                                      style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            );
                          },
                        );
                      } else if (!currState.isEdited) {
                        context.read<BottomNavigationBarBloc>().add(
                              BottomNavigationBarChangeEvent(
                                selectedTab,
                              ),
                            );
                        onTabChangeAppEvent(index);
                      }
                    } else {
                      context.read<BottomNavigationBarBloc>().add(
                            BottomNavigationBarChangeEvent(
                              selectedTab,
                            ),
                          );
                      onTabChangeAppEvent(index);
                    }
                  } else {
                    if (index == 0) {
                      context
                          .read<SupplierPageBlocBloc>()
                          .add(const SupplierPageOffersEvent());
                    }
                    context
                        .read<BottomNavigationBarBloc>()
                        .add(BottomNavigationBarChangeEvent(selectedTab));
                    onTabChangeAppEvent(index);
                  }
                },
                items: [
                  BottomNavigationBarItem(
                    icon: SvgPicture.asset(
                      'assets/ICON_SOURCE.ONE.svg',
                      height: 20,
                      width: 20,
                      colorFilter: const ColorFilter.mode(
                        AppColors.primary100,
                        BlendMode.srcIn,
                      ),
                    ),
                    label: 'My Offers',
                  ),
                  BottomNavigationBarItem(
                    icon: SvgPicture.asset(
                      'assets/ICON_DELIVERY.svg',
                      height: 20,
                      width: 20,
                      colorFilter: const ColorFilter.mode(
                        AppColors.primary100,
                        BlendMode.srcIn,
                      ),
                    ),
                    label: 'My Orders',
                  ),
                  BottomNavigationBarItem(
                    icon: SvgPicture.asset(
                      'assets/ICON_PROFILE.svg',
                      height: 20,
                      width: 20,
                      colorFilter: const ColorFilter.mode(
                        AppColors.primary100,
                        BlendMode.srcIn,
                      ),
                    ),
                    label: 'My Profile',
                  ),
                ],
              );
            }
            return const CircularProgressIndicator();
          },
        ),
      ),
    );
  }
}

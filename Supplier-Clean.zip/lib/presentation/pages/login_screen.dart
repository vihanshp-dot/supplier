import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:supplier/config/theme/app_colors.dart';
import 'package:supplier/core/constants/app_constants.dart';
import 'package:supplier/injection_container.dart';
import 'package:supplier/presentation/bloc/login/login_bloc.dart';
import 'package:supplier/presentation/pages/otp_screen.dart';
import 'package:supplier/presentation/widgets/app_icon.dart';
import 'package:supplier/presentation/widgets/background_pattern.dart';
import 'package:supplier/presentation/widgets/bottom_text.dart';
import 'package:supplier/presentation/widgets/login_form.dart';

class SupplierAppLogin extends StatelessWidget {
  const SupplierAppLogin({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => locator<LoginBloc>(),
      child: BlocBuilder<LoginBloc, LoginState>(
        buildWhen: (previous, current) =>
            current is PhoneNumberInitial || current is ReceivedReferenceToken,
        builder: (context, state) {
          return state is ReceivedReferenceToken
              ? OtpScreen(
                  whatsappNumber: state.whatsappNumber,
                )
              : const LoginScreen();
        },
      ),
    );
  }
}

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        if (constraints.maxWidth < 750) {
          return _loginScreen();
        } else {
          return _loginScreenWeb();
        }
      },
    );
  }

  Widget _loginScreen() {
    return Scaffold(
      key: const Key('loginScreen'),
      backgroundColor: AppColors.uiBackground,
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(30.0),
          child: Stack(
            children: [
              Transform.translate(
                offset: const Offset(50, 450),
                child: const BackgroundPattern(),
              ),
              Column(
                children: [
                  const AppIcon(),
                  _phoneContainer(),
                  BottomText(),
                  const SizedBox(
                    height: 24,
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _loginScreenWeb() {
    return Scaffold(
      key: const Key('loginScreenWeb'),
      backgroundColor: AppColors.uiBackground,
      body: SingleChildScrollView(
        child: Stack(
          children: [
            Transform.translate(
              offset: const Offset(-300, -50),
              child: Transform.rotate(
                angle: 3.14159,
                child: const BackgroundPattern(),
              ),
            ),
            Transform.translate(
              offset: const Offset(300, 350),
              child: const BackgroundPattern(),
            ),
            Center(
              child: Padding(
                padding: const EdgeInsets.all(30.0),
                child: Column(
                  children: [
                    const AppIcon(),
                    _phoneContainerWeb(),
                    ConstrainedBox(
                      constraints: const BoxConstraints(maxHeight: 200),
                      child: Align(
                        alignment: Alignment.bottomCenter,
                        child: Container(
                          constraints: const BoxConstraints(maxWidth: 500),
                          decoration: BoxDecoration(
                            color: const Color.fromARGB(125, 235, 235, 235),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: AppColors.uiStroke10),
                            boxShadow: const [
                              BoxShadow(
                                color: Color.fromARGB(255, 233, 230, 230),
                                blurRadius: 5,
                                offset: Offset(5, 5),
                              ),
                            ],
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(10.0),
                            child: RichText(
                              text: const TextSpan(
                                children: [
                                  TextSpan(
                                    text:
                                        'If you are unable to login, call your Account Manager or Call on ',
                                    style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 17,
                                    ),
                                  ),
                                  TextSpan(
                                    text: loginIssuePhoneNumber,
                                    style: TextStyle(
                                      color: AppColors.primary100,
                                      fontSize: 17,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 24,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _phoneContainer() {
    return Container(
      constraints: const BoxConstraints(maxWidth: 450),
      child: Column(
        children: [
          _infoText(),
          LoginForm(),
        ],
      ),
    );
  }

  Widget _phoneContainerWeb() {
    return Container(
      constraints: const BoxConstraints(maxWidth: 500),
      decoration: BoxDecoration(
        color: AppColors.uiBlack3,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppColors.uiBlack25),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.5),
            blurRadius: 15,
            offset: const Offset(5, 5),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(30.0),
        child: Column(
          children: [
            _infoText(),
            LoginForm(),
          ],
        ),
      ),
    );
  }

  Widget _infoText() {
    return const Align(
      alignment: Alignment.centerLeft,
      child: Text(
        'Login via Registered Whatsapp Number',
        textAlign: TextAlign.left,
        style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700),
      ),
    );
  }
}

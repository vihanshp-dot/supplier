import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:supplier/config/theme/app_colors.dart';
import 'package:supplier/presentation/bloc/auth/auth_bloc.dart';
import 'package:supplier/presentation/bloc/profile_bloc/profile_bloc_bloc.dart';
import 'package:supplier/presentation/pages/login_screen.dart';
import 'package:supplier/presentation/widgets/app_bar.dart';
import 'package:supplier/presentation/widgets/no_wifi.dart';
import 'package:supplier/presentation/widgets/profile_details_card.dart';

class ProfileScreenWidget extends StatelessWidget {
  final String accountManager;
  const ProfileScreenWidget({super.key, required this.accountManager});

  @override
  Widget build(BuildContext context) {
    final double screenWidth = MediaQuery.of(context).size.width;

    int calculateCrossAxisCount() {
      if (screenWidth >= 600 && screenWidth <= 900) {
        return 2;
      } else if (screenWidth > 900 && screenWidth <= 1200) {
        return 3;
      } else {
        return 4;
      }
    }

    return Scaffold(
      backgroundColor: AppColors.uiBackground,
      appBar: AppBarWidget(accountManager: accountManager),
      body: BlocBuilder<ProfileBloc, ProfileBlocState>(
        builder: (context, state) {
          if (state is ProfileScreenLoadingState) {
            return const Center(
              child: CircularProgressIndicator(
                color: AppColors.primary100,
              ),
            );
          } else if (state is ProfileScreenUserDataLoadedState) {
            return SingleChildScrollView(
              child: Center(
                child: Container(
                  constraints: const BoxConstraints(maxWidth: 1200),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  child: Column(
                    children: [
                      if (screenWidth < 610)
                        ...state.userData.map(
                          (section) => ProfileDetailsCard(
                            section: section,
                          ),
                        )
                      else
                        GridView.builder(
                          shrinkWrap: true,
                          gridDelegate:
                              SliverGridDelegateWithFixedCrossAxisCount(
                            mainAxisExtent: 180,
                            crossAxisCount: calculateCrossAxisCount(),
                            crossAxisSpacing: 5.0,
                            mainAxisSpacing: 5.0,
                          ),
                          itemCount: state.userData.length,
                          itemBuilder: (context, index) {
                            return ProfileDetailsCard(
                              section: state.userData[index],
                            );
                          },
                        ),
                      Container(
                        width: double.infinity,
                        margin: const EdgeInsets.only(top: 10),
                        decoration: BoxDecoration(
                          color: AppColors.uiRed10,
                          borderRadius: BorderRadius.circular(10.0),
                          border: Border.all(color: AppColors.uiRed100),
                        ),
                        child: TextButton(
                          onPressed: () async {
                            context.read<AuthBloc>().add(
                                  const AuthLogoutRequested(),
                                );
                            Navigator.pushAndRemoveUntil(
                              context,
                              MaterialPageRoute(
                                builder: (context) => const SupplierAppLogin(),
                              ),
                              (Route<dynamic> route) => false,
                            );
                          },
                          child: const Text(
                            'Logout',
                            style: TextStyle(
                              color: AppColors.uiRed100,
                              fontSize: 12,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          } else {
            return const NoWifi();
          }
        },
      ),
    );
  }
}

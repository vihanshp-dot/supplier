import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:supplier/config/theme/app_colors.dart';
import 'package:supplier/core/utils/utils.dart';
import 'package:supplier/presentation/bloc/auth/auth_bloc.dart';
import 'package:supplier/presentation/bloc/pop_up/pop_up_bloc.dart';
import 'package:supplier/presentation/bloc/snack_bar/snack_bar_bloc.dart';
import 'package:supplier/presentation/bloc/supplier_page_bloc/supplier_page_bloc_bloc.dart';
import 'package:supplier/presentation/pages/login_screen.dart';
import 'package:supplier/presentation/widgets/add_new_offer.dart';
import 'package:supplier/presentation/widgets/deactivate_pop_up.dart';
import 'package:supplier/presentation/widgets/empty_offers.dart';
import 'package:supplier/presentation/widgets/grade_chip.dart';
import 'package:supplier/presentation/widgets/listing_app_bar.dart';
import 'package:supplier/presentation/widgets/no_wifi.dart';

class OfferScreen extends StatelessWidget {
  OfferScreen({super.key});

  final GlobalKey targetKey = GlobalKey();
  final GlobalKey topKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    return Scaffold(
      backgroundColor: const Color.fromRGBO(248, 248, 248, 1),
      appBar: const ListingAppBar(),
      body: BlocConsumer<SupplierPageBlocBloc, SupplierPageBlocState>(
        listener: (context, state) {
          if (state is ActivateOffersSuccessState ||
              state is DeActivateOffersSuccessState) {
            final String locationId = state is ActivateOffersSuccessState
                ? state.locationId
                : (state as DeActivateOffersSuccessState).locationId;
            context.read<SupplierPageBlocBloc>().add(
                  SupplierPageOffersEvent(locationId: locationId),
                );
            BlocProvider.of<SnackBarBloc>(context).add(
              SnackBarDisplayed(
                state is ActivateOffersSuccessState
                    ? state.message
                    : state is DeActivateOffersSuccessState
                        ? state.message
                        : '',
              ),
            );
          } else if (state is ActivateOffersFailureState ||
              state is DeActivateOffersFailureState) {
            final String errorMessage = state is ActivateOffersFailureState
                ? state.errMessage
                : (state as DeActivateOffersFailureState).errMessage;

            BlocProvider.of<SnackBarBloc>(context).add(
              SnackBarDisplayed(
                'Error in ${state is ActivateOffersFailureState ? 'activation' : 'deactivation'} $errorMessage',
                type: SnackType.error,
              ),
            );
          } else if (state is NoOffersActivatedState) {
            const String message = 'No Offers Added';
            context.read<SupplierPageBlocBloc>().add(
                  SupplierPageOffersEvent(locationId: state.locationId),
                );
            BlocProvider.of<SnackBarBloc>(context).add(
              SnackBarDisplayed(
                message,
              ),
            );
          } else if (state is InvalidSupplierPersonState) {
            final String errorMessage = state.errMessage;
            BlocProvider.of<SnackBarBloc>(context).add(
              SnackBarDisplayed(
                errorMessage,
                type: SnackType.error,
              ),
            );
            context.read<AuthBloc>().add(
                  const AuthLogoutRequested(),
                );
            Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(
                builder: (context) => const SupplierAppLogin(),
              ),
              (Route<dynamic> route) => false,
            );
          } else if (state is RecentlyUpdatedState) {
            if (state.showPopUp) {
              context.read<PopUpBloc>().add(
                    ConfirmUpdateAgainPopUpEvent(
                      '',
                      context,
                      state.gradeMap,
                      state.location,
                      state.message!,
                      state.isActivate,
                    ),
                  );
            } else {
              if (state.isActivate) {
                context.read<PopUpBloc>().add(
                      ConfirmOffersPopUpEvent(
                        '',
                        context,
                        state.gradeMap,
                        state.location,
                      ),
                    );
              } else {
                showDialog(
                  context: context,
                  builder: (BuildContext alertContext) {
                    return DeactivatePopUp(
                      onCancel: () {
                        Navigator.of(alertContext).pop();
                      },
                      onDeactivate: () {
                        context.read<SupplierPageBlocBloc>().add(
                              DeactivateOffersEvent(
                                location: state.location,
                              ),
                            );
                        Navigator.of(alertContext).pop();
                      },
                      currentLocationName: state.location.name,
                    );
                  },
                );
              }
            }
          }
        },
        builder: (BuildContext context, SupplierPageBlocState state) {
          if (state is SupplierPageLoading) {
            return const Center(
              child: CircularProgressIndicator(),
            );
          } else if (state is SupplierPageOffersBlocState) {
            final bool validOffersScreen = checkValidityOfOffers(
              state.gradeGroupMap,
              state.supplierAppInfo.minimumBulkQuantity,
            );
            return Column(
              children: [
                Expanded(
                  child: SingleChildScrollView(
                    child: Center(
                      child: Container(
                        margin: const EdgeInsets.all(10),
                        width: screenWidth < 600 ? screenWidth : 1200,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              width: double.infinity,
                              padding: const EdgeInsets.all(10),
                              margin: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(8),
                                color: AppColors.primary15,
                              ),
                              child: Text.rich(
                                TextSpan(children: parseText(state.message)),
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.fromLTRB(
                                10,
                                6,
                                screenWidth > 680 ? 380 : 16,
                                0,
                              ),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  const Text(
                                    'Add new offer',
                                    style: TextStyle(
                                      fontSize: 14,
                                      fontWeight: FontWeight.bold,
                                      color: AppColors.uiBlack100,
                                    ),
                                  ),
                                  Text(
                                    '*18% GST Applicable',
                                    style: TextStyle(
                                      fontSize: 10,
                                      color: Colors.grey[600],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            AddNewOffer(
                              topKey: topKey,
                              supplierAppInfo: state.supplierAppInfo,
                            ),
                            const SizedBox(
                              height: 15,
                            ),
                            if (state.gradeGroupMap.isEmpty) const EmptyList(),
                            ...state.gradeGroupMap.entries.map((entry) {
                              final gradeGroup = entry.value;
                              return Container(
                                margin: const EdgeInsets.only(bottom: 5),
                                padding: const EdgeInsets.all(8),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      gradeGroup.gradeGroupName,
                                      style: const TextStyle(
                                        fontSize: 14,
                                        fontWeight: FontWeight.bold,
                                        color: AppColors.uiBlack100,
                                      ),
                                    ),
                                    const SizedBox(height: 2),
                                    Wrap(
                                      spacing: 8.0,
                                      runSpacing: 8.0,
                                      children: gradeGroup.grades.map((grade) {
                                        return GradeChip(
                                          key: ValueKey(grade.gradeId),
                                          gradeGroupId: entry.key,
                                          grade: grade,
                                          lowerPriceBand:
                                              gradeGroup.lowerPriceBand,
                                          upperPriceBand:
                                              gradeGroup.upperPriceBand,
                                          supplierAppInfo:
                                              state.supplierAppInfo,
                                        );
                                      }).toList(),
                                    ),
                                  ],
                                ),
                              );
                            }),
                            Container(
                              width: double.infinity,
                              margin: const EdgeInsets.only(top: 10),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                color: AppColors.primary100,
                              ),
                              child: TextButton(
                                onPressed: () {
                                  if (validOffersScreen) {
                                    context.read<SupplierPageBlocBloc>().add(
                                          CheckLastUpdateTimeEvent(
                                            location: state.selectedLocation,
                                            gradeMap: state.gradeGroupMap,
                                            lastUpdatedAt: state.lastUpdatedAt,
                                            isActivate: true,
                                          ),
                                        );
                                  } else {
                                    BlocProvider.of<SnackBarBloc>(context).add(
                                      SnackBarDisplayed(
                                        'Invalid Inputs',
                                        type: SnackType.error,
                                        message: 'Please check entered values',
                                      ),
                                    );
                                  }
                                },
                                style: ButtonStyle(
                                  backgroundColor: WidgetStateProperty.all(
                                    AppColors.primary100,
                                  ),
                                  foregroundColor: WidgetStateProperty.all(
                                    AppColors.uiWhite100,
                                  ),
                                ),
                                child: Container(
                                  margin: const EdgeInsets.symmetric(
                                    horizontal: 20,
                                  ),
                                  child: const Text(
                                    'Activate All Offers',
                                    style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Container(
                              key: targetKey,
                              width: double.infinity,
                              margin: const EdgeInsets.only(top: 10),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                color: AppColors.uiRed10,
                                border: Border.all(color: AppColors.uiRed100),
                              ),
                              child: TextButton(
                                onPressed: () {
                                  context.read<SupplierPageBlocBloc>().add(
                                        CheckLastUpdateTimeEvent(
                                          location: state.selectedLocation,
                                          gradeMap: state.gradeGroupMap,
                                          lastUpdatedAt: state.lastUpdatedAt,
                                          isActivate: false,
                                        ),
                                      );
                                },
                                style: ButtonStyle(
                                  backgroundColor: WidgetStateProperty.all(
                                    AppColors.uiRed10,
                                  ),
                                  foregroundColor: WidgetStateProperty.all(
                                    AppColors.uiRed100,
                                  ),
                                ),
                                child: Container(
                                  margin: const EdgeInsets.symmetric(
                                    horizontal: 20,
                                  ),
                                  child: const Text(
                                    'Deactivate All Offers',
                                    style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            );
          } else if (state is SupplierPageErrorState) {
            return const NoWifi();
          }
          return const NoWifi();
        },
      ),
      floatingActionButton:
          BlocBuilder<SupplierPageBlocBloc, SupplierPageBlocState>(
        builder: (BuildContext context, SupplierPageBlocState state) {
          if (state is SupplierPageLoading) {
            return const Center(
              child: SizedBox(
                height: 2,
              ),
            );
          } else if (state is SupplierPageOffersBlocState) {
            return Column(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                TextButton(
                  onPressed: () {
                    Scrollable.ensureVisible(
                      topKey.currentContext!,
                      duration: const Duration(milliseconds: 500),
                      curve: Curves.easeInOut,
                    );
                  },
                  style: ButtonStyle(
                    backgroundColor:
                        WidgetStateProperty.all(AppColors.uiWhite100),
                    shadowColor: WidgetStateProperty.all(AppColors.uiBlack100),
                    foregroundColor:
                        WidgetStateProperty.all(AppColors.uiBlack100),
                    elevation: WidgetStateProperty.all(10),
                  ),
                  child: const Text(
                    'Add New Grade',
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                TextButton(
                  onPressed: () {
                    Scrollable.ensureVisible(
                      targetKey.currentContext!,
                      duration: const Duration(milliseconds: 500),
                      curve: Curves.easeInOut,
                    );
                  },
                  style: ButtonStyle(
                    backgroundColor:
                        WidgetStateProperty.all(AppColors.primary100),
                    shadowColor: WidgetStateProperty.all(AppColors.uiBlack100),
                    foregroundColor:
                        WidgetStateProperty.all(AppColors.uiWhite100),
                    elevation: WidgetStateProperty.all(10),
                  ),
                  child: const Text(
                    'Activate Offers',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 12,
                    ),
                  ),
                ),
              ],
            );
          } else if (state is SupplierPageErrorState) {
            return const SizedBox(
              height: 2,
            );
          }
          return const SizedBox(
            height: 2,
          );
        },
      ),
    );
  }
}

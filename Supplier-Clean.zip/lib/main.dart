import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:supplier/config/dev_http_overrides.dart';
import 'package:supplier/config/theme/app_colors.dart';
import 'package:supplier/injection_container.dart';
import 'package:supplier/presentation/bloc/auth/auth_bloc.dart';
import 'package:supplier/presentation/bloc/bottom_navigation_bar/bottom_navigation_bar_bloc.dart';
import 'package:supplier/presentation/bloc/pop_up/pop_up_bloc.dart';
import 'package:supplier/presentation/bloc/snack_bar/snack_bar_bloc.dart';
import 'package:supplier/presentation/pages/home_screen.dart';
import 'package:supplier/presentation/pages/login_screen.dart';
import 'package:supplier/presentation/widgets/screen_pop_up.dart';
import 'package:supplier/presentation/widgets/snack_bar.dart';
import 'package:url_launcher/url_launcher.dart';

void main() async {
  HttpOverrides.global = DevHttpOverrides();
  await initialiseDependencies();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
        scaffoldBackgroundColor: Colors.white,
      ),
      home: MultiBlocProvider(
        providers: [
          BlocProvider<AuthBloc>(
            create: (_) =>
                locator<AuthBloc>()..add(const AuthSubscriptionRequested()),
          ),
          BlocProvider<BottomNavigationBarBloc>(
            create: (_) => locator<BottomNavigationBarBloc>(),
          ),
          BlocProvider<SnackBarBloc>(create: (_) => locator<SnackBarBloc>()),
          BlocProvider<PopUpBloc>(create: (_) => locator<PopUpBloc>()),
        ],
        child: MultiBlocListener(
          listeners: [
            initialisePopUpListener(context),
            initialiseSnackBarListener(context),
          ],
          child: const SupplierApp(),
        ),
      ),
    );
  }
}

class SupplierApp extends StatelessWidget {
  const SupplierApp({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocListener<AuthBloc, AuthState>(
      listener: (context, state) {
        if (state is Authenticated &&
            state.appVersion?.isUpdateRequired == true) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            showDialog(
              context: context,
              builder: (BuildContext alertContext) {
                return AlertDialog(
                  title: const Text('Warning'),
                  content: Text(state.appVersion!.messageForUser),
                  actions: <Widget>[
                    TextButton(
                      onPressed: () async {
                        final url =
                            Uri.parse(state.appVersion!.supplierAppLink);
                        if (await canLaunchUrl(url)) {
                          await launchUrl(url);
                        } else {
                          throw 'Could not launch $url';
                        }
                        Navigator.of(alertContext).pop();
                      },
                      style: const ButtonStyle(
                        backgroundColor: WidgetStatePropertyAll(
                          AppColors.primary100,
                        ),
                        foregroundColor: WidgetStatePropertyAll(
                          AppColors.uiWhite100,
                        ),
                      ),
                      child: Container(
                        margin: const EdgeInsets.symmetric(
                          horizontal: 5,
                        ),
                        child: const Text(
                          'Ok',
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ],
                );
              },
            );
          });
        }
      },
      child: BlocBuilder<AuthBloc, AuthState>(
        builder: (context, state) {
          if (state is Authenticated) {
            return HomeScreen(accountManager: state.accountManager ?? '');
          } else {
            return const SupplierAppLogin();
          }
        },
      ),
    );
  }
}

package com.sourceone.supplier

import android.provider.Settings
import android.util.Log
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.lang.reflect.Method
import java.net.NetworkInterface
import java.util.*

class MainActivity: FlutterActivity() {
    private val CHANNEL = "com.analytics.getID";
    private lateinit var channel: MethodChannel

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        channel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger,CHANNEL)
        channel.setMethodCallHandler { call, result ->
            if(call.method == "getDeviceId"){
                var dID: String? = Settings.Secure.getString(applicationContext.contentResolver,Settings.Secure.ANDROID_ID);
                result.success(dID);
            }
        }
    }
}
